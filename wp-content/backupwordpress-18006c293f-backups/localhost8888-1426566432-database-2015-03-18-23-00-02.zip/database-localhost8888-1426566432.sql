# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 18. March 2015 14:00 UTC
# Hostname: localhost
# Database: `wordplus`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 18. March 2015 14:00 UTC
# Hostname: localhost
# Database: `wordplus`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (0 records)
#

#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 18. March 2015 14:00 UTC
# Hostname: localhost
# Database: `wordplus`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 18. March 2015 14:00 UTC
# Hostname: localhost
# Database: `wordplus`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=565 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (146 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost:8888', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'home', 'http://localhost:8888', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogname', 'WORDPLUS', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'blogdescription', '워드플러스 입니다.', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'admin_email', 'sonar511@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'date_format', 'Y년 F j일', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_updated_date_format', 'Y년 F j일 g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (33, 'active_plugins', 'a:6:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:27:"dubu_notice/dubu_notice.php";i:2;s:25:"dubu_power/dubu_power.php";i:3;s:23:"statpress/statpress.php";i:4;s:41:"wordpress-importer/wordpress-importer.php";i:5;s:32:"wp-google-fonts/google-fonts.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'gmt_offset', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'recently_edited', 'a:2:{i:0;s:72:"/Applications/MAMP/htdocs/wp-content/themes/arcade-basic-child/style.css";i:2;s:0:"";}', 'no') ; 
INSERT INTO `wp_options` VALUES (41, 'template', 'arcade-basic', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'stylesheet', 'arcade-basic-child', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'db_version', '30133', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'show_on_front', 'page', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:12:"카테고리";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (83, 'timezone_string', 'Asia/Seoul', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'page_on_front', '8', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'initial_db_version', '30133', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'WPLANG', 'ko_KR', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'theme_mods_arcade-basic-child', 'a:1:{s:18:"nav_menu_locations";a:1:{s:7:"primary";i:7;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:6:"검색";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:10:"최근 글";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (100, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:13:"최근 댓글";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (101, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:9:"저장소";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (102, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:13:"그밖의 기";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, 'sidebars_widgets', 'a:6:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}s:13:"array_version";i:3;s:18:"home-page-top-area";a:5:{s:12:"_multiwidget";i:1;i:0;s:30:"bavotasan_custom_text_widget-1";i:1;s:30:"bavotasan_custom_text_widget-2";i:2;s:30:"bavotasan_custom_text_widget-3";i:3;s:30:"bavotasan_custom_text_widget-4";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (104, 'cron', 'a:7:{i:1426700533;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1426718400;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1426743747;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1426746703;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1426773600;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"30ea0ffc86075d1541bcf7bab2bde80c";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:10:"1426566432";}s:8:"interval";i:86400;}}}i:1426960800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"80e8bd3066b0410d5f2d868e9f28caad";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:10:"1426566433";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, 'widget_bavotasan_custom_text_widget', 'a:5:{i:1;a:7:{s:5:"title";s:8:"COMPANY1";s:4:"icon";s:13:"fa-hospital-o";s:3:"url";s:1:"/";s:12:"button_color";s:4:"info";s:4:"text";s:12:"GOOD COMPANY";s:11:"button_text";s:12:"GOOD COMPANY";s:6:"filter";s:0:"";}i:2;a:7:{s:5:"title";s:8:"COMPANY2";s:4:"icon";s:13:"fa-hospital-o";s:3:"url";s:1:"/";s:12:"button_color";s:4:"info";s:4:"text";s:12:"GOOD COMPANY";s:11:"button_text";s:12:"GOOD COMPANY";s:6:"filter";s:0:"";}i:3;a:7:{s:5:"title";s:8:"COMPANY3";s:4:"icon";s:13:"fa-hospital-o";s:3:"url";s:1:"/";s:12:"button_color";s:4:"info";s:4:"text";s:12:"GOOD COMPANY";s:11:"button_text";s:12:"GOOD COMPANY";s:6:"filter";s:0:"";}i:4;a:7:{s:5:"title";s:8:"COMPANY4";s:4:"icon";s:13:"fa-hospital-o";s:3:"url";s:1:"/";s:12:"button_color";s:4:"info";s:4:"text";s:12:"GOOD COMPANY";s:11:"button_text";s:12:"GOOD COMPANY";s:6:"filter";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, 'arcade_basic_theme_options', 'a:11:{s:3:"arc";i:400;s:9:"arc_inner";i:400;s:7:"fittext";s:0:"";s:11:"header_icon";s:8:"fa-heart";s:5:"width";s:4:"1170";s:6:"layout";s:5:"right";s:7:"primary";s:8:"col-md-8";s:14:"display_author";s:2:"on";s:12:"display_date";s:2:"on";s:21:"display_comment_count";s:2:"on";s:18:"display_categories";s:2:"on";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (114, '_transient_random_seed', '01de07ed7ef9e34c86a8b1d3f3c41e9a', 'yes') ; 
INSERT INTO `wp_options` VALUES (116, '_site_transient_timeout_browser_1b101cd1514933ad635f1d8ae80c315a', '1426743738', 'yes') ; 
INSERT INTO `wp_options` VALUES (117, '_site_transient_browser_1b101cd1514933ad635f1d8ae80c315a', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:7:"Firefox";s:7:"version";s:4:"36.0";s:10:"update_url";s:23:"http://www.firefox.com/";s:7:"img_src";s:50:"http://s.wordpress.org/images/browsers/firefox.png";s:11:"img_src_ssl";s:49:"https://wordpress.org/images/browsers/firefox.png";s:15:"current_version";s:2:"16";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (118, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (131, '_transient_timeout_plugin_slugs', '1426770521', 'no') ; 
INSERT INTO `wp_options` VALUES (132, '_transient_plugin_slugs', 'a:15:{i:0;s:19:"akismet/akismet.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:2;s:37:"login-customizer/login-customizer.php";i:3;s:47:"dubu_dashboard_widget/dubu_dashboard_widget.php";i:4;s:23:"dubu_feed/dubu_feed.php";i:5;s:27:"dubu_filter/dubu_filter.php";i:6;s:27:"dubu_notice/dubu_notice.php";i:7;s:25:"dubu_power/dubu_power.php";i:8;s:27:"dubu_tester/dubu_tester.php";i:9;s:29:"dubu_tweeter/dubu_tweeter.php";i:10;s:27:"dubu_widget/dubu_widget.php";i:11;s:33:"tweet-old-post/tweet-old-post.php";i:12;s:23:"statpress/statpress.php";i:13;s:41:"wordpress-importer/wordpress-importer.php";i:14;s:32:"wp-google-fonts/google-fonts.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (138, 'recently_activated', 'a:3:{s:47:"dubu_dashboard_widget/dubu_dashboard_widget.php";i:1426565349;s:23:"dubu_feed/dubu_feed.php";i:1426565326;s:35:"backupwordpress/backupwordpress.php";i:1426564756;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (199, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (239, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1426575474', 'yes') ; 
INSERT INTO `wp_options` VALUES (240, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"4916";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"3078";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"3022";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"2529";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"2346";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1892";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1729";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1680";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1678";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1676";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1612";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1609";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1505";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:4:"1322";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:4:"1276";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:4:"1175";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:4:"1171";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:4:"1083";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:4:"1079";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"918";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"905";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"874";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"843";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"837";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"794";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"758";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"748";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"709";}s:11:"woocommerce";a:3:{s:4:"name";s:11:"woocommerce";s:4:"slug";s:11:"woocommerce";s:5:"count";s:3:"700";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"692";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"682";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"657";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"649";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"642";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"642";}s:9:"ecommerce";a:3:{s:4:"name";s:9:"ecommerce";s:4:"slug";s:9:"ecommerce";s:5:"count";s:3:"623";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"620";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"605";}s:5:"share";a:3:{s:4:"name";s:5:"Share";s:4:"slug";s:5:"share";s:5:"count";s:3:"600";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"593";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (259, 'hmbkp_schedule_1426566432', 'a:4:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:19:"schedule_start_time";d:1426600800;s:11:"max_backups";i:7;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (260, 'hmbkp_schedule_1426566433', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";d:1426960800;s:11:"max_backups";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (261, 'hmbkp_plugin_version', '3.2.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (267, 'googlefonts_options', 'a:75:{s:17:"googlefonts_font1";s:0:"";s:17:"googlefonts_font2";s:0:"";s:17:"googlefonts_font3";s:0:"";s:17:"googlefonts_font4";s:0:"";s:17:"googlefonts_font5";s:0:"";s:17:"googlefonts_font6";s:0:"";s:15:"googlefont1_css";s:1:" ";s:20:"googlefont1_heading1";s:9:"unchecked";s:20:"googlefont1_heading2";s:9:"unchecked";s:20:"googlefont1_heading3";s:9:"unchecked";s:20:"googlefont1_heading4";s:9:"unchecked";s:20:"googlefont1_heading5";s:9:"unchecked";s:20:"googlefont1_heading6";s:9:"unchecked";s:16:"googlefont1_body";s:9:"unchecked";s:22:"googlefont1_blockquote";s:9:"unchecked";s:13:"googlefont1_p";s:9:"unchecked";s:14:"googlefont1_li";s:9:"unchecked";s:15:"googlefont2_css";s:1:" ";s:20:"googlefont2_heading1";s:9:"unchecked";s:20:"googlefont2_heading2";s:9:"unchecked";s:20:"googlefont2_heading3";s:9:"unchecked";s:20:"googlefont2_heading4";s:9:"unchecked";s:20:"googlefont2_heading5";s:9:"unchecked";s:20:"googlefont2_heading6";s:9:"unchecked";s:16:"googlefont2_body";s:9:"unchecked";s:22:"googlefont2_blockquote";s:9:"unchecked";s:13:"googlefont2_p";s:9:"unchecked";s:14:"googlefont2_li";s:9:"unchecked";s:15:"googlefont3_css";s:1:" ";s:20:"googlefont3_heading1";s:9:"unchecked";s:20:"googlefont3_heading2";s:9:"unchecked";s:20:"googlefont3_heading3";s:9:"unchecked";s:20:"googlefont3_heading4";s:9:"unchecked";s:20:"googlefont3_heading5";s:9:"unchecked";s:20:"googlefont3_heading6";s:9:"unchecked";s:16:"googlefont3_body";s:9:"unchecked";s:22:"googlefont3_blockquote";s:9:"unchecked";s:13:"googlefont3_p";s:9:"unchecked";s:14:"googlefont3_li";s:9:"unchecked";s:15:"googlefont4_css";s:1:" ";s:20:"googlefont4_heading1";s:9:"unchecked";s:20:"googlefont4_heading2";s:9:"unchecked";s:20:"googlefont4_heading3";s:9:"unchecked";s:20:"googlefont4_heading4";s:9:"unchecked";s:20:"googlefont4_heading5";s:9:"unchecked";s:20:"googlefont4_heading6";s:9:"unchecked";s:16:"googlefont4_body";s:9:"unchecked";s:22:"googlefont4_blockquote";s:9:"unchecked";s:13:"googlefont4_p";s:9:"unchecked";s:14:"googlefont4_li";s:9:"unchecked";s:15:"googlefont5_css";s:1:" ";s:20:"googlefont5_heading1";s:9:"unchecked";s:20:"googlefont5_heading2";s:9:"unchecked";s:20:"googlefont5_heading3";s:9:"unchecked";s:20:"googlefont5_heading4";s:9:"unchecked";s:20:"googlefont5_heading5";s:9:"unchecked";s:20:"googlefont5_heading6";s:9:"unchecked";s:16:"googlefont5_body";s:9:"unchecked";s:22:"googlefont5_blockquote";s:9:"unchecked";s:13:"googlefont5_p";s:9:"unchecked";s:14:"googlefont5_li";s:9:"unchecked";s:15:"googlefont6_css";s:1:" ";s:20:"googlefont6_heading1";s:9:"unchecked";s:20:"googlefont6_heading2";s:9:"unchecked";s:20:"googlefont6_heading3";s:9:"unchecked";s:20:"googlefont6_heading4";s:9:"unchecked";s:20:"googlefont6_heading5";s:9:"unchecked";s:20:"googlefont6_heading6";s:9:"unchecked";s:16:"googlefont6_body";s:9:"unchecked";s:22:"googlefont6_blockquote";s:9:"unchecked";s:13:"googlefont6_p";s:9:"unchecked";s:14:"googlefont6_li";s:9:"unchecked";s:20:"googlefont_data_time";i:0;s:21:"googlefont_selections";a:6:{s:11:"googlefont1";a:3:{s:6:"family";N;s:8:"variants";a:0:{}s:7:"subsets";a:0:{}}s:11:"googlefont2";a:3:{s:6:"family";N;s:8:"variants";a:0:{}s:7:"subsets";a:0:{}}s:11:"googlefont3";a:3:{s:6:"family";N;s:8:"variants";a:0:{}s:7:"subsets";a:0:{}}s:11:"googlefont4";a:3:{s:6:"family";N;s:8:"variants";a:0:{}s:7:"subsets";a:0:{}}s:11:"googlefont5";a:3:{s:6:"family";N;s:8:"variants";a:0:{}s:7:"subsets";a:0:{}}s:11:"googlefont6";a:3:{s:6:"family";N;s:8:"variants";a:0:{}s:7:"subsets";a:0:{}}}s:25:"googlefont_data_converted";b:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (285, '_transient_timeout_feed_c2db44a3253628b65d50017148a6c134', '1426687351', 'no') ; 
INSERT INTO `wp_options` VALUES (286, '_transient_feed_c2db44a3253628b65d50017148a6c134', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:22:"
	
	
	
	
	
	
	
	
	
	
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"WORDPLUS » 대쉬보드뉴스";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordplus.yoopd.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:49:"워드플러스에 오신 것을 환영합니다.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Mar 2015 03:45:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"ko-KR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=4.1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:1:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"안녕하세요. 워드플러스입니다.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:156:"http://wordplus.yoopd.com/2015/03/17/%ec%95%88%eb%85%95%ed%95%98%ec%84%b8%ec%9a%94-%ec%9b%8c%eb%93%9c%ed%94%8c%eb%9f%ac%ec%8a%a4%ec%9e%85%eb%8b%88%eb%8b%a4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:165:"http://wordplus.yoopd.com/2015/03/17/%ec%95%88%eb%85%95%ed%95%98%ec%84%b8%ec%9a%94-%ec%9b%8c%eb%93%9c%ed%94%8c%eb%9f%ac%ec%8a%a4%ec%9e%85%eb%8b%88%eb%8b%a4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Mar 2015 03:44:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:18:"대쉬보드뉴스";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://wordplus.yoopd.com/?p=773";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:306:"<p class="excerpt">반갑습니다. 워드플러스는 여러분의 워드프레스에 힘을 싣어드립니다. <a href="http://wordplus.yoopd.com/2015/03/17/%ec%95%88%eb%85%95%ed%95%98%ec%84%b8%ec%9a%94-%ec%9b%8c%eb%93%9c%ed%94%8c%eb%9f%ac%ec%8a%a4%ec%9e%85%eb%8b%88%eb%8b%a4/">Read more &#8594;</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"wordplus";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:102:"<p>반갑습니다. 워드플러스는 여러분의 워드프레스에 힘을 싣어드립니다.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:161:"http://wordplus.yoopd.com/2015/03/17/%ec%95%88%eb%85%95%ed%95%98%ec%84%b8%ec%9a%94-%ec%9b%8c%eb%93%9c%ed%94%8c%eb%9f%ac%ec%8a%a4%ec%9e%85%eb%8b%88%eb%8b%a4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:55:"http://wordplus.yoopd.com/category/dashboard_news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:4:"date";s:29:"Wed, 18 Mar 2015 02:02:31 GMT";s:6:"server";s:6:"Apache";s:12:"x-powered-by";s:20:"PHP/5.5.9-1ubuntu4.6";s:10:"x-pingback";s:36:"http://wordplus.yoopd.com/xmlrpc.php";s:13:"last-modified";s:29:"Tue, 17 Mar 2015 03:45:23 GMT";s:4:"etag";s:39:""dd15bdf80e2e9cc988abe10c1b220ed8-gzip"";s:4:"vary";s:15:"Accept-Encoding";s:16:"content-encoding";s:4:"gzip";s:14:"content-length";s:3:"944";s:10:"connection";s:5:"close";s:12:"content-type";s:23:"text/xml; charset=UTF-8";}s:5:"build";s:14:"20150226012146";}', 'no') ; 
INSERT INTO `wp_options` VALUES (287, '_transient_timeout_feed_mod_c2db44a3253628b65d50017148a6c134', '1426687351', 'no') ; 
INSERT INTO `wp_options` VALUES (288, '_transient_feed_mod_c2db44a3253628b65d50017148a6c134', '1426644151', 'no') ; 
INSERT INTO `wp_options` VALUES (291, '_transient_timeout_feed_fcdf5a81c101fa77ea3451896601765b', '1426687567', 'no') ; 
INSERT INTO `wp_options` VALUES (292, '_transient_feed_fcdf5a81c101fa77ea3451896601765b', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:34:"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WORDPLUS » 뉴스";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordplus.yoopd.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:49:"워드플러스에 오신 것을 환영합니다.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 18 Mar 2015 02:04:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"ko-KR";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=4.1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:5:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"최신 업데이트 뉴스!!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:112:"http://wordplus.yoopd.com/2015/03/13/%ec%b5%9c%ec%8b%a0-%ec%97%85%eb%8d%b0%ec%9d%b4%ed%8a%b8-%eb%89%b4%ec%8a%a4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:121:"http://wordplus.yoopd.com/2015/03/13/%ec%b5%9c%ec%8b%a0-%ec%97%85%eb%8d%b0%ec%9d%b4%ed%8a%b8-%eb%89%b4%ec%8a%a4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 13 Mar 2015 02:17:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:6:"뉴스";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://wordplus.yoopd.com/?p=735";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:328:"<p class="excerpt">ㄹㄴㅇㄹㅇㄴㄹㅇㄹ ㄹㅇㄴㄹㅇㄴㄹㅇㄴㄹㅇㄴㄹ ㄹㅇㄴㄹㄴㅇㄹㅇㄴㄹ ㄹㅇㄴㄹ ㄹㅇㄴ ㄹㅇㅇㄹ ㄹㅇㄴㅇㄹㅇ &#160; <a href="http://wordplus.yoopd.com/2015/03/13/%ec%b5%9c%ec%8b%a0-%ec%97%85%eb%8d%b0%ec%9d%b4%ed%8a%b8-%eb%89%b4%ec%8a%a4/">Read more &#8594;</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"wordplus";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:217:"<p>ㄹㄴㅇㄹㅇㄴㄹㅇㄹ</p>
<p>ㄹㅇㄴㄹㅇㄴㄹㅇㄴㄹㅇㄴㄹ</p>
<p>ㄹㅇㄴㄹㄴㅇㄹㅇㄴㄹ</p>
<p>ㄹㅇㄴㄹ</p>
<p>ㄹㅇㄴ</p>
<p>ㄹㅇㅇㄹ</p>
<p>ㄹㅇㄴㅇㄹㅇ</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:117:"http://wordplus.yoopd.com/2015/03/13/%ec%b5%9c%ec%8b%a0-%ec%97%85%eb%8d%b0%ec%9d%b4%ed%8a%b8-%eb%89%b4%ec%8a%a4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:37:"어떤일이 벌어지고 있나요??";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:139:"http://wordplus.yoopd.com/2015/03/13/%ec%96%b4%eb%96%a4%ec%9d%bc%ec%9d%b4-%eb%b2%8c%ec%96%b4%ec%a7%80%ea%b3%a0-%ec%9e%88%eb%82%98%ec%9a%94/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:148:"http://wordplus.yoopd.com/2015/03/13/%ec%96%b4%eb%96%a4%ec%9d%bc%ec%9d%b4-%eb%b2%8c%ec%96%b4%ec%a7%80%ea%b3%a0-%ec%9e%88%eb%82%98%ec%9a%94/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 13 Mar 2015 02:16:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:6:"뉴스";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://wordplus.yoopd.com/?p=733";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:302:"<p class="excerpt">ㄹㅇㄴㄹㅇㄴㅇㄹ ㄹㅇㄴㅇㄹㅇㄴㅇㄹㄹㄴㅇㄹㅇ ㄹㅇㄴㄹㄴㅇㄹㄴㅇㄹㅇㄴㄹ <a href="http://wordplus.yoopd.com/2015/03/13/%ec%96%b4%eb%96%a4%ec%9d%bc%ec%9d%b4-%eb%b2%8c%ec%96%b4%ec%a7%80%ea%b3%a0-%ec%9e%88%eb%82%98%ec%9a%94/">Read more &#8594;</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"wordplus";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:129:"<p>ㄹㅇㄴㄹㅇㄴㅇㄹ</p>
<p>ㄹㅇㄴㅇㄹㅇㄴㅇㄹㄹㄴㅇㄹㅇ</p>
<p>ㄹㅇㄴㄹㄴㅇㄹㄴㅇㄹㅇㄴㄹ</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:144:"http://wordplus.yoopd.com/2015/03/13/%ec%96%b4%eb%96%a4%ec%9d%bc%ec%9d%b4-%eb%b2%8c%ec%96%b4%ec%a7%80%ea%b3%a0-%ec%9e%88%eb%82%98%ec%9a%94/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"워드+아케이드팩 V1.0 오픈베타.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:143:"http://wordplus.yoopd.com/2015/03/03/%ec%9b%8c%eb%93%9c%ec%95%84%ec%bc%80%ec%9d%b4%eb%93%9c%ed%8c%a9-v1-0-%ec%98%a4%ed%94%88%eb%b2%a0%ed%83%80/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:152:"http://wordplus.yoopd.com/2015/03/03/%ec%9b%8c%eb%93%9c%ec%95%84%ec%bc%80%ec%9d%b4%eb%93%9c%ed%8c%a9-v1-0-%ec%98%a4%ed%94%88%eb%b2%a0%ed%83%80/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Mar 2015 06:21:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:6:"뉴스";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"블로그";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"https://wordpress-ofstriker.c9.io/?p=91";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:859:"<p class="excerpt">워드+아케이드팩 V1.0 오픈베타. &#160; &#160; 세상의 20% 사이트가 워드프레스로 만들어졌습니다. &#160; 많은 사람들에게 사랑받는 이유가 있습니다. &#160; 그리고, 우리가 보기에도 쉽고 예뻐보입니다. &#160; 그러나, &#160; 어렵습니다. 로고 하나 달기에도 쉽지 않습니다. &#160; 이러한 어려움을 알기에 &#160; 저희가 여러분을 도와드리기 위하여 &#160; 작은 사다리를 준비하였습니다. &#160; 이 사다리를 밟고 쉽게 워드프레스를 정복하세요. &#160; 설치와 동시에 데모사이트와 같은 퀄리티를 &#160; 보실 수&#8230; <a href="http://wordplus.yoopd.com/2015/03/03/%ec%9b%8c%eb%93%9c%ec%95%84%ec%bc%80%ec%9d%b4%eb%93%9c%ed%8c%a9-v1-0-%ec%98%a4%ed%94%88%eb%b2%a0%ed%83%80/">Read more &#8594;</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"wordplus";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1347:"<p>워드+아케이드팩 V1.0 오픈베타.</p>
<p>&nbsp;</p>
<p><a href="http://wordplus.yoopd.com/wp-content/uploads/2015/03/screenshot-2015-03-03-14.15.05.png"><img class="alignnone size-medium wp-image-71" src="http://wordplus.yoopd.com/wp-content/uploads/2015/03/screenshot-2015-03-03-14.15.05-300x139.png" alt="screenshot 2015-03-03 14.15.05" width="300" height="139" /></a></p>
<p>&nbsp;</p>
<p>세상의 20% 사이트가 워드프레스로 만들어졌습니다.</p>
<p>&nbsp;</p>
<p>많은 사람들에게 사랑받는 이유가 있습니다.</p>
<p>&nbsp;</p>
<p>그리고, 우리가 보기에도 쉽고 예뻐보입니다.</p>
<p>&nbsp;</p>
<p>그러나,</p>
<p>&nbsp;</p>
<p>어렵습니다. 로고 하나 달기에도 쉽지 않습니다.</p>
<p>&nbsp;</p>
<p>이러한 어려움을 알기에</p>
<p>&nbsp;</p>
<p>저희가 여러분을 도와드리기 위하여</p>
<p>&nbsp;</p>
<p>작은 사다리를 준비하였습니다.</p>
<p>&nbsp;</p>
<p>이 사다리를 밟고 쉽게 워드프레스를 정복하세요.</p>
<p>&nbsp;</p>
<p>설치와 동시에 데모사이트와 같은 퀄리티를</p>
<p>&nbsp;</p>
<p>보실 수 있게 만들었습니다.</p>
<p>&nbsp;</p>
<p>비지니스에만 전념하세요.</p>
<p>&nbsp;</p>
<p>여러분의 시스템은 워드+ 가 맡겠습니다.</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:148:"http://wordplus.yoopd.com/2015/03/03/%ec%9b%8c%eb%93%9c%ec%95%84%ec%bc%80%ec%9d%b4%eb%93%9c%ed%8c%a9-v1-0-%ec%98%a4%ed%94%88%eb%b2%a0%ed%83%80/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"Hashtag polaroid pop-up Pitchfork dreamcatcher, migas butcher PBR paleo before they sold out.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:129:"http://wordplus.yoopd.com/2015/02/23/hashtag-polaroid-pop-up-pitchfork-dreamcatcher-migas-butcher-pbr-paleo-before-they-sold-out/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:138:"http://wordplus.yoopd.com/2015/02/23/hashtag-polaroid-pop-up-pitchfork-dreamcatcher-migas-butcher-pbr-paleo-before-they-sold-out/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Feb 2015 07:14:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:6:"뉴스";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"https://wordpress-ofstriker.c9.io/?p=17";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:654:"<p class="excerpt">Hashtag polaroid pop-up Pitchfork dreamcatcher, migas butcher PBR paleo before they sold out. Retro meh deep v pop-up, Brooklyn keffiyeh iPhone Williamsburg. Asymmetrical wolf crucifix, semiotics beard leggings fap Thundercats 90&#8217;s gastropub keffiyeh. Messenger bag pour-over lumbersexual distillery, put a bird on it DIY farm-to-table American Apparel brunch YOLO. Occupy 8-bit normcore chia, tousled mumblecore fingerstache selfies sartorial quinoa. Kale&#8230; <a href="http://wordplus.yoopd.com/2015/02/23/hashtag-polaroid-pop-up-pitchfork-dreamcatcher-migas-butcher-pbr-paleo-before-they-sold-out/">Read more &#8594;</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"wordplus";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1042:"<p>Hashtag polaroid pop-up Pitchfork dreamcatcher, migas butcher PBR paleo before they sold out. Retro meh deep v pop-up, Brooklyn keffiyeh iPhone Williamsburg. Asymmetrical wolf crucifix, semiotics beard leggings fap Thundercats 90&#8217;s gastropub keffiyeh. Messenger bag pour-over lumbersexual distillery, put a bird on it DIY farm-to-table American Apparel brunch YOLO. Occupy 8-bit normcore chia, tousled mumblecore fingerstache selfies sartorial quinoa. Kale chips food truck stumptown, bicycle rights mumblecore butcher mustache. Single-origin coffee fixie whatever, McSweeney&#8217;s pour-over taxidermy Neutra sartorial sriracha Helvetica wolf hella VHS Carles.</p>
<p><a href="https://wordpress-ofstriker.c9.io/wp-content/uploads/2015/02/스크린샷-2015-02-08-오전-11.38.59.png"><img class="alignnone size-medium wp-image-19" src="https://wordpress-ofstriker.c9.io/wp-content/uploads/2015/02/스크린샷-2015-02-08-오전-11.38.59-300x138.png" alt="스크린샷 2015-02-08 오전 11.38.59" width="300" height="138" /></a></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:134:"http://wordplus.yoopd.com/2015/02/23/hashtag-polaroid-pop-up-pitchfork-dreamcatcher-migas-butcher-pbr-paleo-before-they-sold-out/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"Salvia pickled tofu tilde Banksy, DIY artisan single-origin coffee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:103:"http://wordplus.yoopd.com/2015/02/23/salvia-pickled-tofu-tilde-banksy-diy-artisan-single-origin-coffee/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:112:"http://wordplus.yoopd.com/2015/02/23/salvia-pickled-tofu-tilde-banksy-diy-artisan-single-origin-coffee/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Feb 2015 07:09:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:6:"뉴스";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:39:"https://wordpress-ofstriker.c9.io/?p=10";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:621:"<p class="excerpt">Salvia pickled tofu tilde Banksy, DIY artisan single-origin coffee Godard sartorial bespoke taxidermy hella wolf McSweeney&#8217;s. Mlkshk iPhone Odd Future Tumblr cardigan wolf. Banh mi ugh Schlitz cardigan, typewriter migas heirloom lomo Vice. Farm-to-table retro cred, Odd Future typewriter Austin fashion axe. Fixie organic 3 wolf moon, umami dreamcatcher post-ironic PBR&#38;B swag asymmetrical sustainable VHS keytar taxidermy fashion axe. Helvetica&#8230; <a href="http://wordplus.yoopd.com/2015/02/23/salvia-pickled-tofu-tilde-banksy-diy-artisan-single-origin-coffee/">Read more &#8594;</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"wordplus";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:703:"<p>Salvia pickled tofu tilde Banksy, DIY artisan single-origin coffee Godard sartorial bespoke taxidermy hella wolf McSweeney&#8217;s. Mlkshk iPhone Odd Future Tumblr cardigan wolf. Banh mi ugh Schlitz cardigan, typewriter migas heirloom lomo Vice. Farm-to-table retro cred, Odd Future typewriter Austin fashion axe. Fixie organic 3 wolf moon, umami dreamcatcher post-ironic PBR&amp;B swag asymmetrical sustainable VHS keytar taxidermy fashion axe. Helvetica DIY dreamcatcher master cleanse, you probably haven&#8217;t heard of them sustainable scenester artisan. Shoreditch chillwave cornhole, you probably haven&#8217;t heard of them hoodie tofu Wes Anderson mixtape PBR fanny pack.</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:108:"http://wordplus.yoopd.com/2015/02/23/salvia-pickled-tofu-tilde-banksy-diy-artisan-single-origin-coffee/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:46:"http://wordplus.yoopd.com/category/_news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:4:"date";s:29:"Wed, 18 Mar 2015 02:06:07 GMT";s:6:"server";s:6:"Apache";s:12:"x-powered-by";s:20:"PHP/5.5.9-1ubuntu4.6";s:10:"x-pingback";s:36:"http://wordplus.yoopd.com/xmlrpc.php";s:13:"last-modified";s:29:"Wed, 18 Mar 2015 02:04:54 GMT";s:4:"etag";s:39:""2a3685099ea142233056c4fbd4f4a23f-gzip"";s:4:"vary";s:15:"Accept-Encoding";s:16:"content-encoding";s:4:"gzip";s:14:"content-length";s:4:"2877";s:10:"connection";s:5:"close";s:12:"content-type";s:23:"text/xml; charset=UTF-8";}s:5:"build";s:14:"20150226012146";}', 'no') ; 
INSERT INTO `wp_options` VALUES (293, '_transient_timeout_feed_mod_fcdf5a81c101fa77ea3451896601765b', '1426687567', 'no') ; 
INSERT INTO `wp_options` VALUES (294, '_transient_feed_mod_fcdf5a81c101fa77ea3451896601765b', '1426644367', 'no') ; 
INSERT INTO `wp_options` VALUES (323, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1426696858', 'no') ; 
INSERT INTO `wp_options` VALUES (324, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:49:"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:26:"https://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Mar 2015 23:22:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:39:"http://wordpress.org/?v=4.2-beta1-31804";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.2 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Mar 2015 23:22:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3446";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"WordPress 4.2 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.2, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Drew Jaynes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4259:"<p>WordPress 4.2 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.2, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.2-beta1.zip">download the beta here</a> (zip).</p>
<p>4.2 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Press This</strong> has been completely revamped to make sharing content from around the web easier than ever. The new workflow is mobile friendly, and we&#8217;d love for you to try it out on all of your devices. Navigate to the Tools screen in your WordPress backend to get started (<a href="https://core.trac.wordpress.org/ticket/31373">#31373</a>). </li>
<li><strong>Browsing and switching installed themes</strong> has been added to the Customizer to make switching faster and more convenient. We&#8217;re especially interested to know if this helps streamline the process of setting up your site (<a href="https://core.trac.wordpress.org/ticket/31303">#31303</a>).</li>
<li>The workflow for <strong>updating and installing plugins</strong> just got more intuitive with the ability to install or update in-place from the Plugins screens. Try it out and let us know what you think! (<a href="https://core.trac.wordpress.org/ticket/29820">#29820</a>)</li>
<li>If you felt like <strong>emoji</strong> were starkly missing from your content toolbox, worry no more. We&#8217;ve added emoji support nearly everywhere, even post slugs <img src="https://s0.wp.com/wp-content/mu-plugins/emoji/twemoji/72x72/1f44d.png" class="wp-smiley" style="height: 1em;" /> (<a href="https://core.trac.wordpress.org/ticket/31242">#31242</a>).</li>
</ul>
<p><strong>Developers</strong>: There have been a lot of changes for you to test as well, including:</p>
<ul>
<li><strong>Taxonomy Roadmap:</strong> Terms shared across multiple taxonomies will <a href="https://make.wordpress.org/core/2015/02/16/taxonomy-term-splitting-in-4-2-a-developer-guide/">now be split</a> into separate terms when one of them is updated. Please let us know if you hit any snags (<a href="https://core.trac.wordpress.org/ticket/5809/">#5809</a>).</li>
<li>New <code>wp.a11y.speak()</code> functionality helps your JavaScript talk to screen readers to better inform impaired users what&#8217;s happening on-screen. Try it out in your plugin or theme and let us know if you notice any adverse affects (<a href="https://core.trac.wordpress.org/ticket/31368/">#31368</a>).</li>
<li>Named clause support has been added to <code>WP_Query</code>, <code>WP_Comment_Query</code>, and <code>WP_User_Query</code>, allowing specific <code>meta_query</code> clauses to be used with <code>orderby</code>. If you have any complex queries, please test them (<a href="https://core.trac.wordpress.org/ticket/31045/">#31045</a>, <a href="https://core.trac.wordpress.org/ticket/31265/">#31265</a>).</li>
</ul>
<p>If you want a more in-depth view of what changes have made it into 4.2, <a href="https://make.wordpress.org/core/tag/week-in-core/">check out the weekly review posts</a> on the main development blog.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.2">everything we’ve fixed</a> so far.</p>
<p>Happy testing!</p>
<p><em>Press This: switch a theme</em><br />
<em>Save time installing plugins</em><br />
<em>Testing makes us</em> <img src="https://s0.wp.com/wp-content/mu-plugins/emoji/twemoji/72x72/1f603.png" class="wp-smiley" style="height: 1em;" /></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 4.1.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2015/02/wordpress-4-1-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2015/02/wordpress-4-1-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 18 Feb 2015 23:40:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3436";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:345:"WordPress 4.1.1 is now available. This maintenance release fixes 21 bugs in version 4.1. Some of you may have been waiting to update to the latest version until now, but there just wasn&#8217;t much to address. WordPress 4.1 was a smooth-sailing release and has seen more than 14 million downloads in the last two months. For a full [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3086:"<p>WordPress 4.1.1 is now available. This maintenance release fixes 21 bugs in version 4.1.</p>
<p>Some of you may have been waiting to update to the latest version until now, but there just wasn&#8217;t much to address. WordPress 4.1 was a smooth-sailing release and has seen more than 14 million downloads in the last two months.</p>
<p class="p1"><span class="s1">For a full list of changes, consult the <a href="https://core.trac.wordpress.org/query?milestone=4.1.1&amp;group=severity&amp;order=component">list of tickets</a> and the <a href="https://core.trac.wordpress.org/log/branches/4.1?stop_rev=30974&amp;rev=31474">changelog</a>. We fixed one annoying issue where a tag and a category with the same name could get muddled and prevent each other from being updated.</span></p>
<p>If you are one of the millions already running WordPress 4.1 and your site, we’ve started rolling out automatic background updates for 4.1.1 for sites <a href="https://wordpress.org/plugins/background-update-tester/">that support them</a>. Otherwise, <a href="https://wordpress.org/download/">download WordPress 4.1.1</a> or visit <strong>Dashboard → Updates</strong> and simply click “Update Now.”</p>
<p>Thanks to everyone who contributed to 4.1.1: <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/chrico">ChriCo</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/dlh">David Herrera</a>, <a href="https://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/hissy">Takuro Hishikawa</a>, <a href="https://profiles.wordpress.org/ipm-frommen">Thorsten Frommen</a>, <a href="https://profiles.wordpress.org/iseulde">Iseulde</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/sippis">sippis</a>, <a href="https://profiles.wordpress.org/tmatsuur">tmatsuur</a>, <a href="https://profiles.wordpress.org/tyxla">Marin Atanasov</a>, <a href="https://profiles.wordpress.org/valendesigns">Derek Herman</a>, and <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
<p>It is with both great honor and sadness we also recognize Kim Parsell as a contributor to this release and a <a href="https://make.wordpress.org/docs/2015/01/05/rip-kim-parsell/">truly beloved member of the community</a> until her untimely passing in December. The project is working to establish a conference travel <a href="https://make.wordpress.org/community/2015/01/15/remembering-kim-parsell/">scholarship</a> in her memory. We miss you, Kim.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2015/02/wordpress-4-1-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 4.1 “Dinah”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"https://wordpress.org/news/2014/12/dinah/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"https://wordpress.org/news/2014/12/dinah/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 18 Dec 2014 18:35:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3386";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:360:"Version 4.1 of WordPress, named &#8220;Dinah&#8221; in honor of jazz singer Dinah Washington, is available for download or update in your WordPress dashboard. New features in WordPress 4.1 help you focus on your writing, and the new default theme lets you show it off in style. Introducing Twenty Fifteen Our newest default theme, Twenty Fifteen, is [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:24562:"<p>Version 4.1 of WordPress, named &#8220;Dinah&#8221; in honor of jazz singer <a href="http://wikipedia.org/wiki/Dinah_Washington">Dinah Washington</a>, is available for download or update in your WordPress dashboard. New features in WordPress 4.1 help you focus on your writing, and the new default theme lets you show it off in style.</p>
<hr />
<h2 style="text-align: center">Introducing Twenty Fifteen</h2>
<p><img class="aligncenter size-large wp-image-3389" src="https://wordpress.org/news/files/2014/12/2015-laptop-1024x533.png" alt="2015-laptop" width="692" height="360" /></p>
<h3>Our newest default theme, Twenty Fifteen, is a blog-focused theme designed for clarity.</h3>
<p><img class="alignright wp-image-3426 size-medium" src="https://wordpress.org/news/files/2014/12/2015-phones-languages-small-300x250.png" alt="" width="300" height="250" />Twenty Fifteen has flawless language support, with help from <a href="https://www.google.com/get/noto/">Google’s Noto font family</a>.</p>
<p>The straightforward typography is readable on any screen size.</p>
<p>Your content always takes center stage, whether viewed on a phone, tablet, laptop, or desktop computer.</p>
<hr />
<h2 style="text-align: center">Distraction-free writing</h2>
<p><img class="aligncenter size-large wp-image-3392" src="https://wordpress.org/news/files/2014/12/dfw-screen-1024x614.png" alt="dfw-screen" width="692" height="415" /></p>
<h3 style="text-align: center"><em>Just write.</em></h3>
<p>Sometimes, you just need to concentrate on putting your thoughts into words. Try turning on <strong>distraction-free writing mode</strong>. When you start typing, all the distractions will fade away, letting you focus solely on your writing. All your editing tools instantly return when you need them.</p>
<hr />
<h2 style="text-align: center">The Finer Points</h2>
<h5><strong><img class="alignleft wp-image-3405" src="https://wordpress.org/news/files/2014/12/icon-language2.png" alt="" width="80" height="80" /></strong>Choose a language</h5>
<p>Right now, WordPress 4.1 is already translated into over forty languages, with more always in progress. You can switch to any translation on the General Settings screen.</p>
<h5><strong><img class="alignleft wp-image-3406" src="https://wordpress.org/news/files/2014/12/icon-logout1.png" alt="" width="80" height="80" /></strong>Log out everywhere</h5>
<p>If you’ve ever worried you forgot to sign out from a shared computer, you can now go to your profile and log out everywhere.</p>
<h5><strong><img class="alignleft wp-image-3407" src="https://wordpress.org/news/files/2014/12/icon-vine1.png" alt="" width="80" height="80" /></strong>Vine embeds</h5>
<p>Embedding videos from Vine is as simple as pasting a URL onto its own line in a post. See the <a href="https://codex.wordpress.org/Embeds">full list</a> of supported embeds.</p>
<h5><strong><img class="alignleft wp-image-3408" src="https://wordpress.org/news/files/2014/12/icon-recommended1.png" alt="" width="80" height="80" /></strong>Plugin recommendations</h5>
<p>The plugin installer suggests plugins for you to try. Recommendations are based on the plugins you and other users have installed.</p>
<hr />
<h2 style="text-align: center">Under the Hood</h2>
<h5>Complex Queries</h5>
<p>Metadata, date, and term queries now support advanced conditional logic, like nested clauses and multiple operators — <code>A AND ( B OR C )</code>.</p>
<h5>Customizer API</h5>
<p>The customizer now supports conditionally showing panels and sections based on the page being previewed.</p>
<h5><code>&lt;title&gt;</code> tags in themes</h5>
<p><code>add_theme_support( \'title-tag\' )</code> tells WordPress to handle the complexities of document titles.</p>
<h5>Developer Reference</h5>
<p>Continued improvements to inline code documentation have made the <a href="https://developer.wordpress.org/reference/">developer reference</a> more complete than ever.</p>
<hr />
<h2 style="text-align: center">The Choir</h2>
<p>This release was led by <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, with the help of these awesome folks. Check out some of their profiles while listening to Dinah Washington on the music service of your choice:</p>
<a href="https://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/akumria">akumria</a>, <a href="https://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="https://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="https://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="https://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="https://profiles.wordpress.org/momo360modena">Amaury Balmer</a>, <a href="https://profiles.wordpress.org/amruta123b">Amruta Bhosale</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/andg">Andrea Gandino</a>, <a href="https://profiles.wordpress.org/sumobi">Andrew Munro (sumobi)</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/andrewryno">Andrew Ryno</a>, <a href="https://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="https://profiles.wordpress.org/ankitgadertcampcom">Ankit Gade</a>, <a href="https://profiles.wordpress.org/ankit-k-gupta">Ankit K Gupta</a>, <a href="https://profiles.wordpress.org/antpb">Anthony Burchell</a>, <a href="https://profiles.wordpress.org/arippberger">arippberger</a>, <a href="https://profiles.wordpress.org/filosofo">Austin Matzko</a>, <a href="https://profiles.wordpress.org/bainternet">Bainternet</a>, <a href="https://profiles.wordpress.org/barrykooij">Barry Kooij</a>, <a href="https://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="https://profiles.wordpress.org/benjmay">Ben May</a>, <a href="https://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="https://profiles.wordpress.org/birgire">Birgir Erlendsson (birgire)</a>, <a href="https://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone B. Gorges</a>, <a href="https://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="https://profiles.wordpress.org/bramd">Bram Duvigneau</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/briandichiara">Brian DiChiara</a>, <a href="https://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="https://profiles.wordpress.org/bswatson">Brian Watson</a>, <a href="https://profiles.wordpress.org/camdensegal">Camden Segal</a>, <a href="https://profiles.wordpress.org/captaintheme">Captain Theme</a>, <a href="https://profiles.wordpress.org/hiwhatsup">Carlos</a>, <a href="https://profiles.wordpress.org/caspie">Caspie</a>, <a href="https://profiles.wordpress.org/ccprice">ccprice</a>, <a href="https://profiles.wordpress.org/mackensen">Charles Fulton</a>, <a href="https://profiles.wordpress.org/chrico">ChriCo</a>, <a href="https://profiles.wordpress.org/aprea">Chris Aprea</a>, <a href="https://profiles.wordpress.org/chrisbliss18">Chris Jean</a>, <a href="https://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="https://profiles.wordpress.org/jazzs3quence">Chris Reynolds</a>, <a href="https://profiles.wordpress.org/chriscct7">chriscct7</a>, <a href="https://profiles.wordpress.org/chrisl27">chrisl27</a>, <a href="https://profiles.wordpress.org/cfoellmann">Christian Foellmann</a>, <a href="https://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="https://profiles.wordpress.org/cyclometh">Corey Snow</a>, <a href="https://profiles.wordpress.org/corphi">Corphi</a>, <a href="https://profiles.wordpress.org/curtjen">curtjen</a>, <a href="https://profiles.wordpress.org/colorful-tones">Damon Cook</a>, <a href="https://profiles.wordpress.org/dancameron">Dan Cameron</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/convissor">Daniel Convissor</a>, <a href="https://profiles.wordpress.org/nerrad">Darren Ethier (nerrad)</a>, <a href="https://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="https://profiles.wordpress.org/dmchale">Dave McHale</a>, <a href="https://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="https://profiles.wordpress.org/dlh">David Herrera</a>, <a href="https://profiles.wordpress.org/davidjlaietta">David Laietta</a>, <a href="https://profiles.wordpress.org/technical_mastermind">David Wood</a>, <a href="https://profiles.wordpress.org/davidthemachine">DavidTheMachine</a>, <a href="https://profiles.wordpress.org/dcavins">dcavins</a>, <a href="https://profiles.wordpress.org/realloc">Dennis Ploetner</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/wedi">Dirk Weise</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/dominikschwind-1">Dominik Schwind</a>, <a href="https://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="https://profiles.wordpress.org/dustinhartzler">Dustin Hartzler</a>, <a href="https://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="https://profiles.wordpress.org/ebinnion">Eric Binnion</a>, <a href="https://profiles.wordpress.org/ew_holmes">Eric Holmes</a>, <a href="https://profiles.wordpress.org/ericlewis">Eric Lewis</a>, <a href="https://profiles.wordpress.org/fab1en">Fabien Quatravaux</a>, <a href="https://profiles.wordpress.org/florianziegler">florianziegler</a>, <a href="https://profiles.wordpress.org/hereswhatidid">Gabe Shackle</a>, <a href="https://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="https://profiles.wordpress.org/babbardel">George Olaru</a>, <a href="https://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="https://profiles.wordpress.org/gregrickaby">Greg Rickaby</a>, <a href="https://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="https://profiles.wordpress.org/tivnet">Gregory Karpinsky (@tivnet)</a>, <a href="https://profiles.wordpress.org/bordoni">Gustavo Bordoni</a>, <a href="https://profiles.wordpress.org/hardy101">hardy101</a>, <a href="https://profiles.wordpress.org/hauvong">hauvong</a>, <a href="https://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="https://profiles.wordpress.org/heshiming">heshiming</a>, <a href="https://profiles.wordpress.org/honeysilvas">honeysilvas</a>, <a href="https://profiles.wordpress.org/hugodelgado">hugodelgado</a>, <a href="https://profiles.wordpress.org/iandstewart">Ian Stewart</a>, <a href="https://profiles.wordpress.org/ianmjones">ianmjones</a>, <a href="https://profiles.wordpress.org/igmoweb">Ignacio Cruz Moreno</a>, <a href="https://profiles.wordpress.org/imath">imath</a>, <a href="https://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="https://profiles.wordpress.org/ivankristianto">Ivan Kristianto</a>, <a href="https://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="https://profiles.wordpress.org/jaimieolmstead">jaimieolmstead</a>, <a href="https://profiles.wordpress.org/jakubtyrcha">jakub.tyrcha</a>, <a href="https://profiles.wordpress.org/janhenckens">janhenckens</a>, <a href="https://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="https://profiles.wordpress.org/japh">Japh</a>, <a href="https://profiles.wordpress.org/jwenerd">Jared Wenerd</a>, <a href="https://profiles.wordpress.org/jarednova">jarednova</a>, <a href="https://profiles.wordpress.org/jeanyoungkim">jeanyoungkim</a>, <a href="https://profiles.wordpress.org/jfarthing84">Jeff Farthing</a>, <a href="https://profiles.wordpress.org/jeffstieler">Jeff Stieler</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jeherve">Jeremy Herve</a>, <a href="https://profiles.wordpress.org/jesin">Jesin A</a>, <a href="https://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="https://profiles.wordpress.org/engelen">Jesper van Engelen</a>, <a href="https://profiles.wordpress.org/jessepollak">Jesse Pollak</a>, <a href="https://profiles.wordpress.org/jipmoors">jipmoors</a>, <a href="https://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="https://profiles.wordpress.org/joemcgill">Joe McGill</a>, <a href="https://profiles.wordpress.org/johneckman">John Eckman</a>, <a href="https://profiles.wordpress.org/johnrom">johnrom</a>, <a href="https://profiles.wordpress.org/johnstonphilip">johnstonphilip</a>, <a href="https://profiles.wordpress.org/jb510">Jon Brown</a>, <a href="https://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="https://profiles.wordpress.org/jbrinley">Jonathan Brinley</a>, <a href="https://profiles.wordpress.org/desrosj">Jonathan Desrosiers</a>, <a href="https://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="https://profiles.wordpress.org/softmodeling">Jordi Cabot</a>, <a href="https://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="https://profiles.wordpress.org/tai">JOTAKI Taisuke</a>, <a href="https://profiles.wordpress.org/jrf">jrf</a>, <a href="https://profiles.wordpress.org/julien731">Julien Liabeuf</a>, <a href="https://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="https://profiles.wordpress.org/jtsternberg">Justin Sternberg</a>, <a href="https://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="https://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="https://profiles.wordpress.org/kamelkev">kamelkev</a>, <a href="https://profiles.wordpress.org/karpstrucking">karpstrucking</a>, <a href="https://profiles.wordpress.org/keesiemeijer">keesiemeijer</a>, <a href="https://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="https://profiles.wordpress.org/kevinlangleyjr">Kevin Langley</a>, <a href="https://profiles.wordpress.org/kdoran">Kiko Doran</a>, <a href="https://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="https://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="https://profiles.wordpress.org/kitchin">kitchin</a>, <a href="https://profiles.wordpress.org/ixkaito">Kite</a>, <a href="https://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="https://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/kosvrouvas">Kostas Vrouvas</a>, <a href="https://profiles.wordpress.org/kristastevens">kristastevens</a>, <a href="https://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/offereins">Laurens Offereins</a>, <a href="https://profiles.wordpress.org/linuxologos">linuxologos</a>, <a href="https://profiles.wordpress.org/ideag">Liuiza Arunas</a>, <a href="https://profiles.wordpress.org/loushou">loushou</a>, <a href="https://profiles.wordpress.org/latz">Lutz Schroer</a>, <a href="https://profiles.wordpress.org/manoz69">Manoz69</a>, <a href="https://profiles.wordpress.org/mantismamita">mantismamita</a>, <a href="https://profiles.wordpress.org/marcosf">Marco Schmoecker</a>, <a href="https://profiles.wordpress.org/nofearinc">Mario Peshev</a>, <a href="https://profiles.wordpress.org/clorith">Marius (Clorith)</a>, <a href="https://profiles.wordpress.org/landakram">Mark Hudnall</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/senff">Mark Senff</a>, <a href="https://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="https://profiles.wordpress.org/marsjaninzmarsa">marsjaninzmarsa</a>, <a href="https://profiles.wordpress.org/matveb">Matias Ventura</a>, <a href="https://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="https://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="https://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="https://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="https://profiles.wordpress.org/mattkeys">mattkeys</a>, <a href="https://profiles.wordpress.org/mlteal">Maura Teal</a>, <a href="https://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="https://profiles.wordpress.org/merty">Mert Yazicioglu</a>, <a href="https://profiles.wordpress.org/mdawaffe">Michael Adams (mdawaffe)</a>, <a href="https://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="https://profiles.wordpress.org/tw2113">Michael Beckwith</a>, <a href="https://profiles.wordpress.org/cainm">Michael Cain</a>, <a href="https://profiles.wordpress.org/smashcut">Michael Pick</a>, <a href="https://profiles.wordpress.org/michalzuber">michalzuber</a>, <a href="https://profiles.wordpress.org/chellycat">Michelle Langston</a>, <a href="https://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="https://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="https://profiles.wordpress.org/mikejolley">Mike Jolley</a>, <a href="https://profiles.wordpress.org/mnelson4">Mike Nelson</a>, <a href="https://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="https://profiles.wordpress.org/mikeyarce">Mikey Arce</a>, <a href="https://profiles.wordpress.org/studionashvegas">Mitch Canter (studionashvegas)</a>, <a href="https://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="https://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="https://profiles.wordpress.org/mvd7793">mvd7793</a>, <a href="https://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="https://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nikv">Nikhil Vimal</a>, <a href="https://profiles.wordpress.org/nikolovtmw">Nikola Nikolov</a>, <a href="https://profiles.wordpress.org/nobleclem">nobleclem</a>, <a href="https://profiles.wordpress.org/noplanman">noplanman</a>, <a href="https://profiles.wordpress.org/nvwd">Nowell VanHoesen</a>, <a href="https://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="https://profiles.wordpress.org/p_enrique">p_enrique</a>, <a href="https://profiles.wordpress.org/pushplaybang">Paul</a>, <a href="https://profiles.wordpress.org/pauldewouters">Paul de Wouters</a>, <a href="https://profiles.wordpress.org/paulschreiber">Paul Schreiber</a>, <a href="https://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/peterchester">Peter Chester</a>, <a href="https://profiles.wordpress.org/donutz">Peter J. Herrel</a>, <a href="https://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="https://profiles.wordpress.org/peterwilsoncc">Peter Wilson</a>, <a href="https://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="https://profiles.wordpress.org/phpmypython">phpmypython</a>, <a href="https://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="https://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="https://profiles.wordpress.org/psycleuk">psycleuk</a>, <a href="https://profiles.wordpress.org/ptahdunbar">Ptah Dunbar</a>, <a href="https://profiles.wordpress.org/quietnic">quietnic</a>, <a href="https://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="https://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="https://profiles.wordpress.org/ramiabraham">ramiabraham</a>, <a href="https://profiles.wordpress.org/greuben">Reuben Gunday</a>, <a href="https://profiles.wordpress.org/rianrietveld">Rian Rietveld</a>, <a href="https://profiles.wordpress.org/richardmtl">Richard Archambault</a>, <a href="https://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="https://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="https://profiles.wordpress.org/ryankienstra">Ryan Kienstra</a>, <a href="https://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="https://profiles.wordpress.org/sakinshrestha">Sakin Shrestha</a>, <a href="https://profiles.wordpress.org/samhotchkiss">Sam Hotchkiss</a>, <a href="https://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="https://profiles.wordpress.org/sc0ttkclark">Scott Kingsley Clark</a>, <a href="https://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/shooper">Shawn Hooper</a>, <a href="https://profiles.wordpress.org/simonp303">Simon Pollard</a>, <a href="https://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="https://profiles.wordpress.org/skaeser">skaeser</a>, <a href="https://profiles.wordpress.org/slobodanmanic">Slobodan Manic</a>, <a href="https://profiles.wordpress.org/socki03">socki03</a>, <a href="https://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="https://profiles.wordpress.org/stephdau">Stephane Daury</a>, <a href="https://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="https://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="https://profiles.wordpress.org/stevegrunwell">Steve Grunwell</a>, <a href="https://profiles.wordpress.org/5um17">Sumit Singh</a>, <a href="https://profiles.wordpress.org/tacoverdo">TacoVerdo</a>, <a href="https://profiles.wordpress.org/iamtakashi">Takashi Irie</a>, <a href="https://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="https://profiles.wordpress.org/karmatosed">Tammie</a>, <a href="https://profiles.wordpress.org/tareq1988">Tareq Hasan</a>, <a href="https://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="https://profiles.wordpress.org/kraftner">Thomas Kraftner</a>, <a href="https://profiles.wordpress.org/ipm-frommen">Thorsten Frommen</a>, <a href="https://profiles.wordpress.org/tillkruess">Till Kruss</a>, <a href="https://profiles.wordpress.org/tschutter">Tobias Schutter</a>, <a href="https://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="https://profiles.wordpress.org/tmtrademark">Toby McKes</a>, <a href="https://profiles.wordpress.org/tjnowell">Tom J Nowell</a>, <a href="https://profiles.wordpress.org/tomasm">Tomas Mackevicius</a>, <a href="https://profiles.wordpress.org/tomharrigan">TomHarrigan</a>, <a href="https://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="https://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="https://profiles.wordpress.org/liljimmi">Tracy Levesque</a>, <a href="https://profiles.wordpress.org/transom">transom</a>, <a href="https://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="https://profiles.wordpress.org/tywayne">Ty Carlson</a>, <a href="https://profiles.wordpress.org/desaiuditd">Udit Desai</a>, <a href="https://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="https://profiles.wordpress.org/vinod-dalvi">Vinod Dalvi</a>, <a href="https://profiles.wordpress.org/vlajos">vlajos</a>, <a href="https://profiles.wordpress.org/voldemortensen">voldemortensen</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="https://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="https://profiles.wordpress.org/nobinobi">Yuta Sekine</a>, <a href="https://profiles.wordpress.org/zrothauser">Zack Rothauser</a>, and <a href="https://profiles.wordpress.org/tollmanz">Zack Tollman</a>.
<p>There were 283 contributors to this release, again a new high.</p>
<p>If you want to help out or follow along, check out <a href="https://make.wordpress.org/">Make WordPress</a> and our <a href="https://make.wordpress.org/core/">core development blog</a>.</p>
<p>Thanks for choosing WordPress. Happy holidays and see you next year for version 4.2!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/news/2014/12/dinah/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 4.1 Release Candidate 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"https://wordpress.org/news/2014/12/wordpress-4-1-release-candidate-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"https://wordpress.org/news/2014/12/wordpress-4-1-release-candidate-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 18 Dec 2014 02:22:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3411";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:429:"The next release candidate for WordPress 4.1 is now available for testing. Seventy changes have gone in since the first release candidate. With no known issues left, we plan to release 4.1 tomorrow, December 18. To test, try the WordPress Beta Tester plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can download the release candidate here (zip). If you&#8217;d like to learn more about [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"John Blackbourn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1465:"<p>The next release candidate for WordPress 4.1 is now available for testing.</p>
<p><a href="https://core.trac.wordpress.org/log/trunk?rev=30961&amp;stop_rev=30827">Seventy changes</a> have gone in since the <a href="https://wordpress.org/news/2014/12/wordpress-4-1-release-candidate/">first release candidate</a>. With no known issues left, we plan to release 4.1 tomorrow, December 18.</p>
<p>To test, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="https://wordpress.org/wordpress-4.1-RC3.zip">download the release candidate here</a> (zip). If you&#8217;d like to learn more about what&#8217;s new in WordPress 4.1, visit the updated About screen in your dashboard (<strong><img src="https://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a href="https://wordpress.org/news/2014/11/wordpress-4-1-beta-1/">the Beta 1 post</a>.</p>
<p><strong>Plugin authors:</strong> Remember to test your plugins against 4.1, and if they&#8217;re compatible, make sure they are marked as tested up to 4.1. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="https://make.wordpress.org/core/tag/4-1-dev-notes/">notes for developers for 4.1</a> as always.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:74:"https://wordpress.org/news/2014/12/wordpress-4-1-release-candidate-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 4.1 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"https://wordpress.org/news/2014/12/wordpress-4-1-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:76:"https://wordpress.org/news/2014/12/wordpress-4-1-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 11 Dec 2014 11:52:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:3:"4.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3375";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:341:"The release candidate for WordPress 4.1 is now available. We&#8217;ve made a lot of refinements over the last few weeks. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.1 on Tuesday, December 16, but we need your [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"John Blackbourn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2301:"<p>The release candidate for WordPress 4.1 is now available.</p>
<p>We&#8217;ve made a lot of refinements over the last few weeks. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.1 on Tuesday, December 16, but we need your help to get there. If you haven’t tested 4.1 yet, now is the time! (Please though, not on your live site unless you’re adventurous.)</p>
<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href="https://wordpress.org/support/forum/alphabeta/">Alpha/Beta support forum</a>. If any known issues come up, you&#8217;ll be able to <a href="https://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>To test WordPress 4.1 RC1, you can use the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin or you can <a href="https://wordpress.org/wordpress-4.1-RC1.zip">download the release candidate here</a> (zip). If you&#8217;d like to learn more about what&#8217;s new in WordPress 4.1, visit the About screen in your dashboard (<strong><img src="https://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png" alt="" width="16" height="16" /> → About</strong> in the toolbar) or check out the <a href="https://wordpress.org/news/2014/11/wordpress-4-1-beta-1/">beta announcement</a>.</p>
<p><strong>Developers</strong>, please test your plugins and themes against WordPress 4.1 and update your plugin&#8217;s <em>Tested up to</em> version in the readme to 4.1 before next week. If you find compatibility problems, we never want to break things, so please be sure to post to the support forums so we can figure those out before the final release.</p>
<p>Be sure to <a href="https://make.wordpress.org/core/">follow along the core development blog</a>, where we&#8217;ll continue to post <a href="https://make.wordpress.org/core/tag/4-1-dev-notes/">notes for developers</a> for 4.1. (For example: if you&#8217;ve written a child theme for Twenty Fifteen, some of the new pagination functions have been renamed for clarity.)</p>
<p><em>Testing four point one</em><br />
<em>Why are we up at this hour?</em><br />
<em>Code is poetry</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:72:"https://wordpress.org/news/2014/12/wordpress-4-1-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 4.0.1 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2014/11/wordpress-4-0-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2014/11/wordpress-4-0-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Nov 2014 18:55:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3363";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:345:"WordPress 4.0.1 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. Sites that support automatic background updates will be updated to WordPress 4.0.1 within the next few hours. If you are still on WordPress 3.9.2, 3.8.4, or 3.7.4, you will be [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3395:"<p>WordPress 4.0.1 is now available. This is a <strong>critical security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>Sites that support automatic background updates will be updated to WordPress 4.0.1 within the next few hours. If you are still on WordPress 3.9.2, 3.8.4, or 3.7.4, you will be updated to 3.9.3, 3.8.5, or 3.7.5 to keep everything secure. (We don’t support older versions, so please update to 4.0.1 for the latest and greatest.)</p>
<p>WordPress versions 3.9.2 and earlier are affected by a critical cross-site scripting vulnerability, which could enable anonymous users to compromise a site. This was reported by <a href="http://klikki.fi/">Jouko Pynnonen</a>. This issue does not affect version 4.0, but version 4.0.1 does address these eight security issues:</p>
<ul>
<li>Three cross-site scripting issues that a contributor or author could use to compromise a site. Discovered by <a href="http://joncave.co.uk/">Jon Cave</a>, <a href="http://www.miqrogroove.com/">Robert Chapin</a>, and <a href="https://johnblackbourn.com/">John Blackbourn</a> of the WordPress security team.</li>
<li>A cross-site request forgery that could be used to trick a user into changing their password.</li>
<li>An issue that could lead to a denial of service when passwords are checked. Reported by <a href="http://www.behindthefirewalls.com/">Javier Nieto Arevalo</a> and <a href="http://www.devconsole.info/">Andres Rojas Guerrero</a>.</li>
<li>Additional protections for server-side request forgery attacks when WordPress makes HTTP requests. Reported by Ben Bidner (vortfu).</li>
<li>An extremely unlikely hash collision could allow a user&#8217;s account to be compromised, that also required that they haven&#8217;t logged in since 2008 (I wish I were kidding). Reported by <a href="http://david.dw-perspective.org.uk">David Anderson</a>.</li>
<li>WordPress now invalidates the links in a password reset email if the user remembers their password, logs in, and changes their email address. Reported separately by <a href="https://twitter.com/MomenBassel">Momen Bassel</a>, <a href="http://c0dehouse.blogspot.in/">Tanoy Bose</a>, and <a href="https://managewp.com/">Bojan Slavković of ManageWP</a>.</li>
</ul>
<p>Version 4.0.1 also fixes 23 bugs with 4.0, and we&#8217;ve made two hardening changes, including better validation of EXIF data we are extracting from uploaded photos. Reported by <a href="http://www.securesolutions.no/">Chris Andrè Dale</a>.</p>
<p>We appreciated the <a href="https://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these issues directly to our security team. For more information, see the <a href="https://codex.wordpress.org/Version_4.0.1">release notes</a> or consult the <a href="https://core.trac.wordpress.org/log/branches/4.0?rev=30475&amp;stop_rev=29710">list of changes</a>.</p>
<p><a href="https://wordpress.org/download/">Download WordPress 4.0.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click “Update Now”.</p>
<p><em>Already testing WordPress 4.1? The second beta is now available (<a href="https://wordpress.org/wordpress-4.1-beta2.zip">zip</a>) and it contains these security fixes. For more on 4.1, see <a href="https://wordpress.org/news/2014/11/wordpress-4-1-beta-1/">the beta 1 announcement post</a>.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/11/wordpress-4-0-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.1 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/11/wordpress-4-1-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://wordpress.org/news/2014/11/wordpress-4-1-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Nov 2014 22:35:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"beta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3352";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:346:"Welcome, everyone, to WordPress 4.1 Beta 1! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.1, try the WordPress Beta Tester plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"John Blackbourn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3409:"<p>Welcome, everyone, to WordPress 4.1 Beta 1!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.1, try the <a href="https://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="//wordpress.org/wordpress-4.1-beta1.zip">download the beta here</a> (zip).</p>
<p>WordPress 4.1 is due for release next month, so we need your help with testing. Here are some highlights of what to test:</p>
<ul>
<li>Our beautiful new default theme, <a href="https://make.wordpress.org/core/2014/09/09/twenty-fifteen/">Twenty Fifteen</a>. It&#8217;s a clean, mobile-first, blog-focused theme designed through simplicity.</li>
<li>A new <a href="https://make.wordpress.org/core/2014/11/11/focus-v2-demo-video/">distraction-free writing mode for the editor</a>. It&#8217;s enabled by default for beta, and we&#8217;d love feedback on it.</li>
<li>The ability to automatically install new language packs right from the General Settings screen (available as long as your site&#8217;s filesystem is writable).</li>
<li>A new inline formatting toolbar for images embedded into posts.</li>
</ul>
<p>There have been a lot of changes for developers to test as well:</p>
<ul>
<li><a href="https://make.wordpress.org/core/2014/10/20/update-on-query-improvements-in-4-1/">Improvements to meta, date, comment, and taxonomy queries</a>, including complex (nested, multiple relation) queries; and querying comment types (<a href="https://core.trac.wordpress.org/ticket/12668">#12668</a>).</li>
<li>A single term shared across multiple taxonomies is now split into two when updated. For more, <a href="https://make.wordpress.org/core/2014/11/12/an-update-on-the-taxonomy-roadmap/">see this post</a>, <a href="https://core.trac.wordpress.org/ticket/5809">#5809</a>, and <a href="https://core.trac.wordpress.org/ticket/30335">#30335</a>.</li>
<li>A new and better way for <a href="https://make.wordpress.org/core/2014/10/29/title-tags-in-4-1/">themes to handle title tags</a>.</li>
<li>Several <a href="https://make.wordpress.org/core/2014/10/27/toward-a-complete-javascript-api-for-the-customizer/">improvements to the Customizer API</a>, including contextual panels and sections, and JavaScript templates for controls.</li>
</ul>
<p>If you want a more in-depth view of what changes have made it into 4.1, <a href="https://make.wordpress.org/core/tag/week-in-core/">check out the weekly review posts</a> on the main development blog.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="https://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.1">everything we’ve fixed</a> so far.</p>
<p>Happy testing!</p>
<p><em>Twenty Fifteen theme</em><br />
<em> The beautiful face which hides</em><br />
<em> Many improvements</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/news/2014/11/wordpress-4-1-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"Watch WordCamp San Francisco Livestream";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/news/2014/10/wcsf-livestream/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/news/2014/10/wcsf-livestream/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 24 Oct 2014 20:18:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3341";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:381:"WordCamp San Francisco is the official annual WordPress conference, gathering the community every year since 2006. This is the time when Matt Mullenweg addresses the community in his annual State of the Word presentation – a recap of  the year in WordPress and giving us a glimpse into its future. This year the speaker lineup is stellar. There will be talks by [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Nikolay Bachiyski";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1975:"<p><a title="2014 edition" href="http://2014.sf.wordcamp.org">WordCamp San Francisco</a> is the official annual WordPress conference, gathering the community every year <a title="An old website for a WordPress long time ago" href="http://2006.sf.wordcamp.org">since 2006</a>. This is the time when Matt Mullenweg addresses the community in his annual <a href="http://wordpress.tv/?s=state+of+the+word">State of the Word</a> presentation – a recap of  the year in WordPress and giving us a glimpse into its future.</p>
<p>This year the speaker lineup is stellar. There will be talks by three of the lead WordPress developers: <a href="http://2014.sf.wordcamp.org/speakers/#wcorg-speaker-andrew-nacin">Andrew Nacin</a>, <a href="http://2014.sf.wordcamp.org/speakers/#wcorg-speaker-helen-hou-sandi">Helen Hou-Sandí</a>, and <a href="http://2014.sf.wordcamp.org/speakers/#wcorg-speaker-mark-jaquith">Mark Jaquith</a>. We’re also looking forward to speakers like <a href="http://2014.sf.wordcamp.org/speakers/#wcorg-speaker-jenny-lawson">Jenny Lawson</a>, also known as The Bloggess, and <a href="http://2014.sf.wordcamp.org/speaker/chris-lema/">Chris Lema</a>. If you’re at all interested in the web, you will appreciate the appearance of <a href="http://2014.sf.wordcamp.org/speakers/#wcorg-speaker-jeff-veen">Jeff Veen</a> – one of the creators of Google Analytics and co-founder of Typekit.</p>
<p>Even though San Francisco is far far away for most of you, you can still be part of the fun and watch all presentations in real-time via livestream:</p>
<p><a href="http://2014.sf.wordcamp.org/tickets/">Get a livestream ticket and watch all talks from WordCamp San Francisco live</a></p>
<p>If you hurry, you can get one of the special livestream tickets, including a WordCamp San Francisco 2104 t-shirt. You can find all the technical details and start times <a href="http://2014.sf.wordcamp.org/live-stream/">at the WordCamp San Francisco website</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/news/2014/10/wcsf-livestream/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 4.0 “Benny”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"https://wordpress.org/news/2014/09/benny/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"https://wordpress.org/news/2014/09/benny/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 04 Sep 2014 17:05:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3296";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:370:"Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleader Benny Goodman, is available for download or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we&#8217;ve put a little extra polish into it. This release brings you a smoother writing and management experience [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23575:"<p>Version 4.0 of WordPress, named “Benny” in honor of jazz clarinetist and bandleader <a href="http://en.wikipedia.org/wiki/Benny_Goodman">Benny Goodman</a>, is available <a href="https://wordpress.org/download/">for download</a> or update in your WordPress dashboard. While 4.0 is just another number for us after 3.9 and before 4.1, we feel we&#8217;ve put a little extra polish into it. This release brings you a smoother writing and management experience we think you&#8217;ll enjoy.</p>
<div id="v-bUdzKMro-1" class="video-player"><embed id="v-bUdzKMro-1-video" src="https://v0.wordpress.com/player.swf?v=1.04&amp;guid=bUdzKMro&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" title="Introducing WordPress 4.0 &quot;Benny&quot;" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<hr />
<h2 style="text-align: center">Manage your media with style</h2>
<p><img class="alignnone size-full wp-image-3316" src="https://wordpress.org/news/files/2014/09/media.jpg" alt="Media Library" width="1000" height="586" />Explore your uploads in a beautiful, endless grid. A new details preview makes viewing and editing any amount of media in sequence a snap.</p>
<hr />
<h2 style="text-align: center">Working with embeds has never been easier</h2>
<div style="width: 632px; " class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3296-1" width="632" height="445" autoplay="1" preload="metadata" controls="controls"><source type="video/mp4" src="//s.w.org/images/core/4.0/embed.mp4?_=1" /><source type="video/webm" src="//s.w.org/images/core/4.0/embed.webm?_=1" /><source type="video/ogg" src="//s.w.org/images/core/4.0/embed.ogv?_=1" /><a href="//s.w.org/images/core/4.0/embed.mp4">//s.w.org/images/core/4.0/embed.mp4</a></video></div>
<p>Paste in a YouTube URL on a new line, and watch it magically become an embedded video. Now try it with a tweet. Oh yeah — embedding has become a visual experience. The editor shows a true preview of your embedded content, saving you time and giving you confidence.</p>
<p>We’ve expanded the services supported by default, too — you can embed videos from CollegeHumor, playlists from YouTube, and talks from TED. <a href="https://codex.wordpress.org/Embeds">Check out all of the embeds</a> that WordPress supports.</p>
<hr />
<h2 style="text-align: center">Focus on your content</h2>
<div style="width: 632px; " class="wp-video"><video class="wp-video-shortcode" id="video-3296-2" width="632" height="356" autoplay="1" preload="metadata" controls="controls"><source type="video/mp4" src="//s.w.org/images/core/4.0/focus.mp4?_=2" /><source type="video/webm" src="//s.w.org/images/core/4.0/focus.webm?_=2" /><source type="video/ogg" src="//s.w.org/images/core/4.0/focus.ogv?_=2" /><a href="//s.w.org/images/core/4.0/focus.mp4">//s.w.org/images/core/4.0/focus.mp4</a></video></div>
<p>Writing and editing is smoother and more immersive with an editor that expands to fit your content as you write, and keeps the formatting tools available at all times.</p>
<hr />
<h2 style="text-align: center">Finding the right plugin</h2>
<p><img class="aligncenter size-large wp-image-3309" src="https://wordpress.org/news/files/2014/09/add-plugin1-1024x600.png" alt="Add plugins" width="692" height="405" /></p>
<p>There are more than 30,000 free and open source plugins in the WordPress plugin directory. WordPress 4.0 makes it easier to find the right one for your needs, with new metrics, improved search, and a more visual browsing experience.</p>
<hr />
<h2 style="text-align: center">The Ensemble</h2>
<p>This release was led by <a href="http://helenhousandi.com">Helen Hou-Sandí</a>, with the help of these fine individuals. There are 275 contributors with props in this release, a new high. Pull up some Benny Goodman on your music service of choice, as a bandleader or in one of his turns as a classical clarinetist, and check out some of their profiles:</p>
<p><a href="https://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="https://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="https://profiles.wordpress.org/alexanderrohmann">Alexander Rohmann</a>, <a href="https://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="https://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="https://profiles.wordpress.org/amit">Amit Gupta</a>, <a href="https://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/andrezrv">Andres Villarreal</a>, <a href="https://profiles.wordpress.org/zamfeer">Andrew Mowe</a>, <a href="https://profiles.wordpress.org/sumobi">Andrew Munro (sumobi)</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="https://profiles.wordpress.org/ankit-k-gupta">Ankit K Gupta</a>, <a href="https://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="https://profiles.wordpress.org/arnee">Arne Brachhold</a>, <a href="https://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="https://profiles.wordpress.org/filosofo">Austin Matzko</a>, <a href="https://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="https://profiles.wordpress.org/kau-boy">Bernhard Kau</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="https://profiles.wordpress.org/bramd">Bram Duvigneau</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/krogsgard">Brian Krogsgard</a>, <a href="https://profiles.wordpress.org/brianlayman">Brian Layman</a>, <a href="https://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="https://profiles.wordpress.org/camdensegal">Camden Segal</a>, <a href="https://profiles.wordpress.org/sixhours">Caroline Moore</a>, <a href="https://profiles.wordpress.org/mackensen">Charles Fulton</a>, <a href="https://profiles.wordpress.org/chouby">Chouby</a>, <a href="https://profiles.wordpress.org/chrico">ChriCo</a>, <a href="https://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="https://profiles.wordpress.org/chrisl27">chrisl27</a>, <a href="https://profiles.wordpress.org/caxelsson">Christian Axelsson</a>, <a href="https://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="https://profiles.wordpress.org/boda1982">Christopher Spires</a>, <a href="https://profiles.wordpress.org/clifgriffin">Clifton Griffin</a>, <a href="https://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="https://profiles.wordpress.org/corphi">Corphi</a>, <a href="https://profiles.wordpress.org/extendwings">Daisuke Takahashi</a>, <a href="https://profiles.wordpress.org/ghost1227">Dan Griffiths</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/danielhuesken">Daniel Husken</a>, <a href="https://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="https://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="https://profiles.wordpress.org/dkotter">Darin Kotter</a>, <a href="https://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="https://profiles.wordpress.org/dllh">Daryl L. L. Houston (dllh)</a>, <a href="https://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="https://profiles.wordpress.org/dlh">David Herrera</a>, <a href="https://profiles.wordpress.org/dnaber-de">David Naber</a>, <a href="https://profiles.wordpress.org/davidthemachine">DavidTheMachine</a>, <a href="https://profiles.wordpress.org/debaat">DeBAAT</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/donncha">Donncha O Caoimh</a>, <a href="https://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/dustyn">Dustyn Doyle</a>, <a href="https://profiles.wordpress.org/eddiemoya">Eddie Moya</a>, <a href="https://profiles.wordpress.org/oso96_2000">Eduardo Reveles</a>, <a href="https://profiles.wordpress.org/edwin-at-studiojoyocom">Edwin Siebel</a>, <a href="https://profiles.wordpress.org/ehg">ehg</a>, <a href="https://profiles.wordpress.org/erayalakese">erayalakese</a>, <a href="https://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="https://profiles.wordpress.org/ebinnion">Eric Binnion</a>, <a href="https://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="https://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="https://profiles.wordpress.org/eherman24">Evan Herman</a>, <a href="https://profiles.wordpress.org/fab1en">Fabien Quatravaux</a>, <a href="https://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="https://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="https://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="https://profiles.wordpress.org/garhdez">garhdez</a>, <a href="https://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="https://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/garza">garza</a>, <a href="https://profiles.wordpress.org/gauravmittal1995">gauravmittal1995</a>, <a href="https://profiles.wordpress.org/gavra">Gavrisimo</a>, <a href="https://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="https://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="https://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="https://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="https://profiles.wordpress.org/bordoni">Gustavo Bordoni</a>, <a href="https://profiles.wordpress.org/harrym">harrym</a>, <a href="https://profiles.wordpress.org/hebbet">hebbet</a>, <a href="https://profiles.wordpress.org/hinnerk">Hinnerk Altenburg</a>, <a href="https://profiles.wordpress.org/hlashbrooke">Hugh Lashbrooke</a>, <a href="https://profiles.wordpress.org/iljoja">iljoja</a>, <a href="https://profiles.wordpress.org/imath">imath</a>, <a href="https://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="https://profiles.wordpress.org/issuu">issuu</a>, <a href="https://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="https://profiles.wordpress.org/jacklenox">Jack Lenox</a>, <a href="https://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="https://profiles.wordpress.org/jacobdubail">Jacob Dubail</a>, <a href="https://profiles.wordpress.org/janhenkg">JanHenkG</a>, <a href="https://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="https://profiles.wordpress.org/jwenerd">Jared Wenerd</a>, <a href="https://profiles.wordpress.org/strangerstudios">Jason Coleman</a>, <a href="https://profiles.wordpress.org/jaza613">Jaza613</a>, <a href="https://profiles.wordpress.org/jeffstieler">Jeff Stieler</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jpry">Jeremy Pry</a>, <a href="https://profiles.wordpress.org/slimndap">Jeroen Schmit</a>, <a href="https://profiles.wordpress.org/jerrysarcastic">Jerry Bates (jerrysarcastic)</a>, <a href="https://profiles.wordpress.org/jesin">Jesin A</a>, <a href="https://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="https://profiles.wordpress.org/engelen">Jesper van Engelen</a>, <a href="https://profiles.wordpress.org/jesper800">Jesper van Engelen</a>, <a href="https://profiles.wordpress.org/jessepollak">Jesse Pollak</a>, <a href="https://profiles.wordpress.org/jgadbois">jgadbois</a>, <a href="https://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="https://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="https://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="https://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="https://profiles.wordpress.org/johnzanussi">John Zanussi</a>, <a href="https://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="https://profiles.wordpress.org/jonnyauk">jonnyauk</a>, <a href="https://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="https://profiles.wordpress.org/softmodeling">Jordi Cabot</a>, <a href="https://profiles.wordpress.org/jjeaton">Josh Eaton</a>, <a href="https://profiles.wordpress.org/tai">JOTAKI Taisuke</a>, <a href="https://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="https://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="https://profiles.wordpress.org/jtsternberg">Justin Sternberg</a>, <a href="https://profiles.wordpress.org/greenshady">Justin Tadlock</a>, <a href="https://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="https://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="https://profiles.wordpress.org/kapeels">kapeels</a>, <a href="https://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="https://profiles.wordpress.org/kevinlangleyjr">Kevin Langley</a>, <a href="https://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="https://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="https://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="https://profiles.wordpress.org/kitchin">kitchin</a>, <a href="https://profiles.wordpress.org/ixkaito">Kite</a>, <a href="https://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="https://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="https://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="https://profiles.wordpress.org/lessbloat">lessbloat</a>, <a href="https://profiles.wordpress.org/layotte">Lew Ayotte</a>, <a href="https://profiles.wordpress.org/lritter">lritter</a>, <a href="https://profiles.wordpress.org/lukecarbis">Luke Carbis</a>, <a href="https://profiles.wordpress.org/lgedeon">Luke Gedeon</a>, <a href="https://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="https://profiles.wordpress.org/funkatronic">Manny Fleurmond</a>, <a href="https://profiles.wordpress.org/targz-1">Manuel Schmalstieg</a>, <a href="https://profiles.wordpress.org/clorith">Marius (Clorith)</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="https://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="https://profiles.wordpress.org/sivel">Matt Martz</a>, <a href="https://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="https://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="https://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="https://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="https://profiles.wordpress.org/mattheweppelsheimer">Matthew Eppelsheimer</a>, <a href="https://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="https://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="https://profiles.wordpress.org/meekyhwang">meekyhwang</a>, <a href="https://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="https://profiles.wordpress.org/mdawaffe">Michael Adams (mdawaffe)</a>, <a href="https://profiles.wordpress.org/michalzuber">michalzuber</a>, <a href="https://profiles.wordpress.org/midxcat">midxcat</a>, <a href="https://profiles.wordpress.org/mauteri">Mike Auteri</a>, <a href="https://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="https://profiles.wordpress.org/mikejolley">Mike Jolley</a>, <a href="https://profiles.wordpress.org/mikelittle">Mike Little</a>, <a href="https://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="https://profiles.wordpress.org/mnelson4">Mike Nelson</a>, <a href="https://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="https://profiles.wordpress.org/mikeyarce">Mikey Arce</a>, <a href="https://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="https://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="https://profiles.wordpress.org/usermrpapa">Mr Papa</a>, <a href="https://profiles.wordpress.org/mrmist">mrmist</a>, <a href="https://profiles.wordpress.org/m_uysl">Mustafa Uysal</a>, <a href="https://profiles.wordpress.org/muvimotv">MuViMoTV</a>, <a href="https://profiles.wordpress.org/nabil_kadimi">nabil_kadimi</a>, <a href="https://profiles.wordpress.org/namibia">Namibia</a>, <a href="https://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="https://profiles.wordpress.org/nd987">nd987</a>, <a href="https://profiles.wordpress.org/neil_pie">Neil Pie</a>, <a href="https://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/schoenwaldnils">Nils Schonwald</a>, <a href="https://profiles.wordpress.org/ninos-ego">Ninos</a>, <a href="https://profiles.wordpress.org/nvwd">Nowell VanHoesen</a>, <a href="https://profiles.wordpress.org/compute">Patrick Hesselberg</a>, <a href="https://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="https://profiles.wordpress.org/pdclark">Paul Clark</a>, <a href="https://profiles.wordpress.org/paulschreiber">Paul Schreiber</a>, <a href="https://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="https://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="https://profiles.wordpress.org/philipjohn">Philip John</a>, <a href="https://profiles.wordpress.org/senlin">Piet Bos</a>, <a href="https://profiles.wordpress.org/psoluch">Piotr Soluch</a>, <a href="https://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="https://profiles.wordpress.org/purzlbaum">purzlbaum</a>, <a href="https://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="https://profiles.wordpress.org/rclations">RC Lations</a>, <a href="https://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="https://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="https://profiles.wordpress.org/rob1n">rob1n</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="https://profiles.wordpress.org/harmr">RobertHarm</a>, <a href="https://profiles.wordpress.org/rohan013">Rohan Rawat</a>, <a href="https://profiles.wordpress.org/rhurling">Rouven Hurling</a>, <a href="https://profiles.wordpress.org/ruudjoyo">Ruud Laan</a>, <a href="https://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="https://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="https://profiles.wordpress.org/sammybeats">Sam Brodie</a>, <a href="https://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="https://profiles.wordpress.org/sathishn">Sathish Nagarajan</a>, <a href="https://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="https://profiles.wordpress.org/scribu">scribu</a>, <a href="https://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="https://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="https://profiles.wordpress.org/sergejmueller">Sergej Muller</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/shanebp">shanebp</a>, <a href="https://profiles.wordpress.org/sharonaustin">Sharon Austin</a>, <a href="https://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="https://profiles.wordpress.org/simonp303">Simon Pollard</a>, <a href="https://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="https://profiles.wordpress.org/slobodanmanic">Slobodan Manic</a>, <a href="https://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="https://profiles.wordpress.org/sphoid">sphoid</a>, <a href="https://profiles.wordpress.org/stephdau">Stephane Daury</a>, <a href="https://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="https://profiles.wordpress.org/stompweb">Steven Jones</a>, <a href="https://profiles.wordpress.org/5um17">Sumit Singh</a>, <a href="https://profiles.wordpress.org/t4k1s">t4k1s</a>, <a href="https://profiles.wordpress.org/iamtakashi">Takashi Irie</a>, <a href="https://profiles.wordpress.org/taylorde">Taylor Dewey</a>, <a href="https://profiles.wordpress.org/thomasvanderbeek">Thomas van der Beek</a>, <a href="https://profiles.wordpress.org/tillkruess">Till Kruss</a>, <a href="https://profiles.wordpress.org/codenameeli">Tim &#039;Eli&#039; Dalbey</a>, <a href="https://profiles.wordpress.org/tmeister">tmeister</a>, <a href="https://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="https://profiles.wordpress.org/tjnowell">Tom J Nowell</a>, <a href="https://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="https://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="https://profiles.wordpress.org/torresga">torresga</a>, <a href="https://profiles.wordpress.org/liljimmi">Tracy Levesque</a>, <a href="https://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="https://profiles.wordpress.org/treyhunner">treyhunner</a>, <a href="https://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="https://profiles.wordpress.org/vinod-dalvi">Vinod Dalvi</a>, <a href="https://profiles.wordpress.org/vlajos">vlajos</a>, <a href="https://profiles.wordpress.org/voldemortensen">voldemortensen</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="https://profiles.wordpress.org/winterdev">winterDev</a>, <a href="https://profiles.wordpress.org/wojtekszkutnik">Wojtek Szkutnik</a>, <a href="https://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="https://profiles.wordpress.org/katzwebdesign">Zack Katz</a>, <a href="https://profiles.wordpress.org/tollmanz">Zack Tollman</a>, and <a href="https://profiles.wordpress.org/zoerooney">Zoe Rooney</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video, and Helen with <a href="http://adriansandi.com">Adrián Sandí</a> for the music.</p>
<p>If you want to follow along or help out, check out <a href="https://make.wordpress.org/">Make WordPress</a> and our <a href="https://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.1!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/news/2014/09/benny/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 4.0 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"https://wordpress.org/news/2014/08/wordpress-4-0-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:76:"https://wordpress.org/news/2014/08/wordpress-4-0-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Aug 2014 12:20:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3287";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:321:"The first release candidate for WordPress 4.0 is now available! In RC 1, we’ve made refinements to what we&#8217;ve been working on for this release. Check out the Beta 1 announcement post for more details on those features. We hope to ship WordPress 4.0 next week, but we need your help to get there. If you [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Helen Hou-Sandi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2134:"<p>The first release candidate for WordPress 4.0 is now available!</p>
<p>In RC 1, we’ve made refinements to what we&#8217;ve been working on for this release. Check out the <a href="https://wordpress.org/news/2014/07/wordpress-4-0-beta-1/">Beta 1 announcement post</a> for more details on those features. We hope to ship WordPress 4.0 <em>next week</em>, but we need your help to get there. If you haven’t tested 4.0 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="https://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="https://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>To test WordPress 4.0 RC1, try the <a href="https://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="https://wordpress.org/wordpress-4.0-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 4.0, visit the awesome About screen in your dashboard (<strong><img src="https://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar).</p>
<p><strong>Developers,</strong> please test your plugins and themes against WordPress 4.0 and update your plugin&#8217;s <em>Tested up to</em> version in the readme to 4.0 before next week. If you find compatibility problems, please be sure to post any issues to the support forums so we can figure those out before the final release. You also may want to <a href="https://make.wordpress.org/core/2014/08/21/introducing-plugin-icons-in-the-plugin-installer/">give your plugin an icon</a>, which we launched last week and will appear in the dashboard along with banners.</p>
<p><em>It is almost time</em><br />
<em> For the 4.0 release</em><br />
<em> And its awesomeness</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:72:"https://wordpress.org/news/2014/08/wordpress-4-0-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:32:"https://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Wed, 18 Mar 2015 04:40:57 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:25:"strict-transport-security";s:11:"max-age=360";s:10:"x-pingback";s:37:"https://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 12 Mar 2015 23:22:52 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20150226012146";}', 'no') ; 
INSERT INTO `wp_options` VALUES (325, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1426696858', 'no') ; 
INSERT INTO `wp_options` VALUES (326, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1426653658', 'no') ; 
INSERT INTO `wp_options` VALUES (327, '_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9', '1426696859', 'no') ; 
INSERT INTO `wp_options` VALUES (328, '_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: An Inside Look at VersionPress’ Crowdfunding Campaign";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40758";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wptavern.com/an-inside-look-at-versionpress-crowdfunding-campaign";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4416:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/06/VersionPressFeaturedImage.png" rel="prettyphoto[40758]"><img class="size-full wp-image-24643" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/06/VersionPressFeaturedImage.png?resize=650%2C200" alt="Version Control Featured Image" /></a>Version Control Featured Image
<p>When <a title="http://wptavern.com/versionpress-misses-crowdfunding-goal-by-14-5k" href="http://wptavern.com/versionpress-misses-crowdfunding-goal-by-14-5k">VersionPress missed its crowdfunding goal</a> by raising only 45% of $30K, I cited several contributing factors, including lack of trust, licensing confusion, and the campaign&#8217;s short length. The lead developer of VersionPress, Borek Bernard, shared the <a title="http://blog.versionpress.net/2015/03/crowdfunding-campaign-lessons-learned/" href="http://blog.versionpress.net/2015/03/crowdfunding-campaign-lessons-learned/">lessons he learned</a> from running the campaign on the company&#8217;s blog.</p>
<p>Bernard explains that despite the campaign being a single page site, a lot of work went into it:</p>
<blockquote><p>In our case, the website took over 250 commits and hundreds of hours to get prepared. And it was a seemingly simple, single-page site! This was partly related to the fact that the campaign was self-hosted, but still, some tasks just can’t be skipped. For example, writing copy alone is a huge task should it be any good and easily takes weeks of effort. There are more things like that so be prepared to spend considerable amount of time and effort on the campaign page.</p></blockquote>
<p>After I <a title="http://wptavern.com/versionpress-hopes-to-bring-version-control-to-the-masses" href="http://wptavern.com/versionpress-hopes-to-bring-version-control-to-the-masses">introduced readers to the VersionPress project,</a> several people <a title="http://wptavern.com/versionpress-hopes-to-bring-version-control-to-the-masses#comments" href="http://wptavern.com/versionpress-hopes-to-bring-version-control-to-the-masses#comments">voiced their concern</a> over the lack of licensing details. I got in touch with Bernard and explained why so many people were concerned. I explained what the GPL means to the project and the WordPress community in general. I cited examples of successful WordPress product businesses that use the license. I also told him that he&#8217;s likely receive more financial support by being 100% GPL.</p>
<p>Although it took a few days, <a title="http://wptavern.com/versionpress-adopts-the-gpl-software-license" href="http://wptavern.com/versionpress-adopts-the-gpl-software-license">Bernard announced</a> VersionPress would be 100% GPL licensed. According to Bernard, the announcement didn&#8217;t translate into more backers.</p>
<blockquote><p>By the way, it was interesting to see what the GPL announcement did to the actual contributions. We were told how the GPL was important and that it would bring us many more supporters, but in actuality, it didn’t have any measurable effect. During the whole campaign, the only factor that strongly correlated with the contributed sum was the number of visitors on the versionpress.net website.</p></blockquote>
<p>It&#8217;s not clear why adopting the GPL license didn&#8217;t have an effect on the number of backers. However, I think that being licensed 100% GPL eliminates potential roadblocks that may have resulted in using a license not compatible with the GPL.</p>
<p>One of the lessons I learned from VersionsPress&#8217; campaign is that despite not reaching its goal, the amount of feedback from media coverage and backers was enough to verify the idea. The team continues to move forward with development and is <a title="http://blog.versionpress.net/2015/02/1-0-rc2-released/" href="http://blog.versionpress.net/2015/02/1-0-rc2-released/">nearing a 1.0 release</a>.</p>
<p>If you&#8217;re thinking about launching a crowdfunding campaign, I highly recommend listening to <a title="http://wptavern.com/wpweekly-episode-156-a-crowdfunding-roundtable" href="http://wptavern.com/wpweekly-episode-156-a-crowdfunding-roundtable">episode 156 of WordPress Weekly</a> where Marcus Couch and I interview Scott Kingsley Clark, John Saddington, and Nick Haskins. All three describe their experience managing a crowdfunding campaign and share important tips and lessons to help reach funding goals.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Mar 2015 21:56:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: Tidy Repo Launches WordPress Plugin Recommendation Service";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40715";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://wptavern.com/tidy-repo-launches-wordpress-plugin-recommendation-service";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4633:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/coffee-laptop.jpg" rel="prettyphoto[40715]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/coffee-laptop.jpg?resize=1025%2C505" alt="coffee-laptop" class="aligncenter size-full wp-image-40753" /></a></p>
<p><a href="http://tidyrepo.com/" target="_blank">Tidy Repo</a> has been pumping out WordPress plugin reviews since 2013. Today co-owners <a href="https://twitter.com/jay_hoffmann" target="_blank">Jay Hoffman</a> and and <a href="https://twitter.com/jackmcconnell" target="_blank">Jack McConnell</a> are branching out to launch a new service that helps customers find a plugin for a $35 fee.</p>
<p>The Tidy Repo <a href="http://tidyrepo.com/find-plugin-service/" target="_blank">plugin recommendation service</a> is the first of its kind. With more than 36,000 plugins listed in the WordPress.org directory, and thousands more hosted elsewhere, WordPress users can get overwhelmed when trying to pinpoint the right plugin to solve a problem. Without experience or WordPress development knowledge, the process boils down to trial and error.</p>
<p>Tidy Repo is aiming to eliminate the need for exhaustive research. After testing thousands of plugins, with 250+ published reviews, Hoffman and McConnell believe they can save customers quite a bit of time in selecting the perfect plugin. Both are developers who have written plugins and worked with WordPress for years.</p>
<p>&#8220;I have a good sense of where conflicts can come up and what is potentially harmful,&#8221; Hoffman said. &#8220;It does become a lot of intuition too. Anyone on the WP Plugin Review team, or the great plugin developers I know, can kind of feel through things and you start being able to spot the weak points very quickly- be that with a conflict in the code, or just a problem with its general user experience.&#8221;</p>
<p>Hoffman has a range of criteria that he measures a plugin&#8217;s code against before recommending it to a customer:</p>
<blockquote><p>The most important thing to me is that a plugin makes proper use of the WordPress API. If a plugin sticks to WordPress functions and hooks, that can get us a lot of the way there. It at least goes a long way in ensuring that a plugin won’t bump up against other plugins or themes. </p>
<p>I’m also looking to make sure that if a plugin is adding something to the front-end, it is doing so in a performant way. Is it minifying CSS / JS files? Taking steps to only include external files on pages where they are necessary? You sometimes hear people complain that WordPress is slow, and I think poor front-end performance in a plugin is often the culprit. </p>
<p>Code structure also comes into play a bit, but only as it relates to actual function. What I mean is that I don’t necessarily have a preference for structure, as long as it remains consistent. That’s just a sign of a good developer.</p></blockquote>
<p>The basic plugin recommendation package comes with a full report, including the environment it was tested in, and a few secondary recommendations (if warranted). Additional services, such as multiple recommendations, installation, and video walkthroughs can be added to the basic package.</p>
<p>Hoffman and McConnell hope to grow the database of Tidy Repo reviews alongside the new plugin recommendation service, but neither constitute a full-time endeavor at the moment.</p>
<p>&#8220;It’s been a labor of love from the beginning, and this is the first time that we’re offering a premium service to our readers,&#8221; Hoffman said. &#8220;Jack and I have a ton of ideas for making the plugin discovery process a lot easier, like more elegant faceted search, in-depth guides, and a ton more, but it’s incredibly difficult to do on top of everything else that life demands.</p>
<p>&#8220;To be frank, this is a total experiment for me. There are times when it is incredibly difficult to keep Tidy Repo going, but enough people appear to find it useful that I want to keep it around. Maybe that’s just a long way of saying Tidy Repo would be a dream full-time gig for me, if I ever had the opportunity to do so,&#8221; he said.</p>
<p>It&#8217;s not uncommon for those who have created a helpful tool or community resource, such as <a href="http://tidyrepo.com/" target="_blank">Tidy Repo</a> or <a href="http://generatewp.com/" target="_blank">GenerateWP</a>, to try to find a way to monetize their efforts. Is there a market for the Tidy Repo co-owners&#8217; experiment? Or will WordPress users continue to stumble on the best plugins through trial and error?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Mar 2015 21:25:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Matt: Remote Work Popularity";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44796";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://ma.tt/2015/03/remote-work-popularity/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:145:"<p>Scott Berkun asks <cite><a href="http://scottberkun.com/2015/why-isnt-remote-work-more-popular/">Why Isn’t Remote Work More Popular?</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Mar 2015 21:17:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"Akismet: Akismet WordPress Plugin 3.1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1797";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://blog.akismet.com/2015/03/17/akismet-3-1-1-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:938:"<p>Version 3.1.1 of <a href="http://wordpress.org/plugins/akismet/">the Akismet plugin for WordPress</a> is now available.</p>
<p>This update includes an improvement to the &#8220;Remove comment author URL&#8221; feature and merges the pingback DDOS protection from Akismet 2.x into the 3.x plugin line.</p>
<p>To upgrade, visit the Updates page of your WordPress dashboard and follow the instructions. If you need to download the plugin zip file directly, links to all versions are available in <a href="http://wordpress.org/plugins/akismet/">the WordPress plugins directory</a>.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1797/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1797/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.akismet.com&blog=116920&post=1797&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Mar 2015 20:00:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Christopher Finke";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"WPTavern: Hackers Hijack Fancybox Plugin to Deface WordPress Sites with ISIS Propaganda";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40719";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wptavern.com/hackers-hijack-fancybox-plugin-to-deface-wordpress-sites-with-isis-propaganda";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3494:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/isis-hack.png" rel="prettyphoto[40719]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/isis-hack.png?resize=945%2C552" alt="isis-hack" class="aligncenter size-full wp-image-40730" /></a></p>
<p>Last month a vulnerability was discovered in the <a href="http://wptavern.com/zero-day-vulnerability-discovered-in-fancybox-for-wordpress-plugin" target="_blank">Fancybox for WordPress</a> plugin, making it possible for a hacker to inject an iframe into the website without needing administrator access. Although the issue was promptly patched, a string of seemingly random WordPress websites were recently compromised using this vulnerability.</p>
<p>Hackers claiming to be acting on behalf of ISIS exploited Fancybox to deface the websites with propaganda for the terrorist group. <a href="http://www.cujournal.com/news/isis-update-hacking-of-montana-cu-provides-vital-lesson-to-community-1024100-1.html" target="_blank">Credit Union Journal</a> reports that a Montana credit union website was attacked using the Fancybox plugin as the entry point.</p>
<p><a href="http://area43.net/2015/03/isis-vs-nascar-the-tech-behind-the-hacking-of-eldoraspeedway-com/" target="_blank">Area43.net</a> examined the cached Google source code for several other hacked sites and reported that both <a href="http://Eldoraspeedway.com" target="_blank">Eldoraspeedway.com</a> and <a href="http://Montgomeryinn.com" target="_blank">Montgomeryinn.com</a> have since removed the Fancybox for WordPress plugin.</p>
<p>In order to deface the websites, the suspected ISIS hackers likely scanned for sites that have not updated the Fancybox for WordPress plugin, as the sites bear no other commonalities apart from using WordPress. Many <a href="http://www.independent.ie/irish-news/dublin-rape-crisis-center-website-hacked-by-isis-31051435.html" target="_blank">major</a> <a href="http://www.newsweek.com/isis-hacker-targets-websites-folk-singer-hotels-nascar-driver-312636" target="_blank">news</a> <a href="http://www.nbcnews.com/news/us-news/isis-hackers-almost-certainly-not-isis-hackers-n320296" target="_blank">outlets</a> with no understanding of WordPress&#8217; plugin system have wrongly attributed the security flaw to WordPress itself.</p>
<p><a href="https://wordpress.org/plugins/fancybox-for-wordpress/" target="_blank">Fancybox for WordPress</a> is currently active on more than 100,000 sites, but stats on WordPress.org do not break down how many of those are using a version older than the patched update issued in February. According to Samuel &#8220;Otto&#8221; Wood, WordPress.org pushed out a forced update for the Fancybox plugin vulnerability, although it wasn&#8217;t widely reported.</p>
<p>What is it going to take for WordPress site administrators to keep their plugins updated? If you&#8217;re not comfortable updating WordPress plugins yourself, then you need to be on a maintenance plan with a development company to keep your software updated and secure.</p>
<p>While many developers are not too keen on the possibility of WordPress someday <a href="http://wptavern.com/its-time-for-wordpress-to-automatically-update-themes-plugins-and-core-by-default" target="_blank">adopting automatic updates for core, plugins, and themes by default</a>, your average website owner would probably probably prefer it over would-be ISIS hackers exploiting the simplest of vulnerabilities to deface their websites.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Mar 2015 17:02:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Matt: Meetups Around the World";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44783";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://ma.tt/2015/03/meetups-around-the-world/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:337:"<p><a href="https://kinsta.com/learn/wordpress-communities-around-the-world/">Here&#8217;s a great article about WordPress meetup communities around the world</a>, including Singapore, Argentina, France, Croatia, India, Serbia, Malta, Norway, South Africa, Canada, Switzerland, Ireland, Estonia, Egypt, Poland, Belgium, and Slovakia.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Mar 2015 05:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WPTavern: Ultimate Member: A New Free Community and User Profile Plugin for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40639";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:94:"http://wptavern.com/ultimate-member-a-new-free-community-and-user-profile-plugin-for-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5310:"<p><a href="https://ultimatemember.com/" target="_blank">Ultimate Member</a> is the newest plugin to join the ranks of WordPress membership solutions after seven months in development. One month after landing in the WordPress.org directory, the <a href="https://wordpress.org/plugins/ultimate-member/" target="_blank">plugin</a> is already active on more than 2,000 WordPress sites and has received a 5-star rating from 73/75 reviewers.</p>
<p>The WordPress ecosystem is flush with both free and commercial membership plugins, but Ultimate Member takes a unique approach with its heavy emphasis on frontend community features. The plugin goes beyond content restriction to provide beautifully-designed user profiles and directories out of the box.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/ultimate-member.png" rel="prettyphoto[40639]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/ultimate-member.png?resize=949%2C457" alt="ultimate-member" class="aligncenter size-full wp-image-40641" /></a></p>
<p>It includes searchable member directories and frontend user registration, login, and profiles. Administrators can create custom form fields with conditional logic. The membership features include custom user roles, content restriction, conditional menus, and more. Ultimate Member is compatible with multisite and Mandrill. It was also designed to be developer friendly with dozens of actions and filters for further customization.</p>
<p><a href="http://ultimatememberdemo.com/" target="_blank">Live demos</a> are available for the user profiles, member directory, and user account pages.</p>
<h3>Ultimate Member Extensions Sales Hit $1500 in the First 5 Days</h3>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/ultimate-member-extensions.jpg" rel="prettyphoto[40639]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/ultimate-member-extensions.jpg?resize=1019%2C174" alt="ultimate-member-extensions" class="aligncenter size-full wp-image-40701" /></a></p>
<p>Co-founders <a href="https://twitter.com/calumallison" target="_blank">Calum Allison</a> and Ahmed Elmahd opted to keep the base plugin free and offer additional commercial <a href="https://ultimatemember.com/extensions/" target="_blank">extensions</a>.</p>
<p>&#8220;We decided to use the free core + paid extensions model as we&#8217;ve seen how successful plugins such as WooCommerce, Ninja Forms, and Easy Digital Downloads have been with this model,&#8221; Allison said. &#8220;We want to try replicate this success in the community/user space.&#8221;</p>
<p>Initial extension sales indicate that the team has identified a competitive niche. &#8220;We&#8217;ve had sales of just under $1,500 from our first five days and we hope this will grow as more extensions are built and more people learn about the plugin,&#8221; Allison told the Tavern.</p>
<p>Ultimate Member is not quite a BuddyPress alternative, but its founding duo entered the market to provide basic social features on top of membership functionality.</p>
<p>&#8220;The plugin is useful for people looking to build a site where users can sign up and become members but are not necessarily looking to create a full-blown social network which is offered by plugins such as BuddyPress or WP Symposium,&#8221; Allison said.</p>
<p>Currently, the most popular extensions in terms of sales are the bbPress integration and Social Login extensions. More modular social features, such as private messaging and paid membership upgrades, are currently in the works.</p>
<p>&#8220;Longer term we are considering building themes which are designed specifically for the community niche,&#8221; Allison said.</p>
<p>In the meantime, the duo is focusing on providing support for all users and have answered more than 400 topics on their community forum and the WordPress.org plugin support forum.</p>
<p>&#8220;We made a decision from the beginning that we would provide support for all users of the plugin, regardless of whether they purchased an extension or not,&#8221; Allison said. &#8220;We feel that providing at least some support to free users means they are more likely to want to purchase an extension or two.&#8221;</p>
<p>Ultimate Member is open source and available on <a href="https://github.com/ultimatemember/ultimatemember" target="_blank">GitHub</a> for contribution from developers. Co-founders Allison and Elmahd also maintain a <a href="https://trello.com/b/30quaczv/ultimate-member" target="_blank">Trello board</a> for mapping the future of the plugin and managing current issues.</p>
<p>With a strong set of <a href="https://ultimatemember.com/features/" target="_blank">core features</a> and solid extensions sales numbers right out of the gate, <a href="https://ultimatemember.com/" target="_blank">Ultimate Member</a> is already demonstrating success with the free core plus commercial extensions business model. Even in a seemingly saturated WordPress membership plugin market, a quality product that can zero in on a specific niche has a decent chance of becoming competitive within a short time after launching. The challenge will be keeping up with the level of support they intend to offer for both commercial and free users, while growing the library of extensions.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 16 Mar 2015 22:55:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: Pods Framework Security Release Fixes Severe Vulnerability";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40651";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://wptavern.com/pods-framework-security-release-fixes-severe-vulnerability";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3704:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/pods.jpg" rel="prettyphoto[40651]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/pods.jpg?resize=628%2C290" alt="pods" class="aligncenter size-full wp-image-40653" /></a></p>
<p>Last week <a href="http://wptavern.com/blind-sql-injection-vulnerability-discovered-in-wordpress-seo-plugin-by-yoast-immediate-update-recommended">a blind SQL injection vulnerability</a> was discovered in Yoast&#8217;s popular WordPress SEO plugin. Given the severity of the vulnerability and the fact that the plugin is installed on more than one million WordPress sites, the security team at WordPress.org pushed <a href="http://wptavern.com/how-to-stay-in-the-loop-if-you-turn-off-wordpress-automatic-updates" target="_blank">a forced update</a> to mitigate the possibility of mass exploitation.</p>
<p>Following this incident, the <a href="http://pods.io/" target="_blank">Pods framework</a> team proactively performed a security review of their <a href="https://wordpress.org/plugins/pods/" target="_blank">plugin</a> and found an issue similar to the one discovered and disclosed last week in the WordPress SEO plugin. Contributor Josh Pollock describes the issue in the <a href="http://pods.io/2015/03/16/important-security-disclosure/" target="_blank">release announcement</a>:</p>
<blockquote><p>We believe this is an especially severe issue as this issue occurred in the PodsUI class, which is not only used for the Pods admin, but is also employed by many end-users to create front-end and back-end content management interfaces for non-admin users.</p>
<p>The issue occurred in approximately Line 859 of the PodsUI class. The orderby parameter, which is passed from the browser in a GET variable was subsequently used in an SQL query without being properly sanitized.</p>
<p>As a result malicious or other unintended SQL queries could be sent to the database by manipulating the GET request.</p></blockquote>
<p>Pods 2.5.1.2, released today, is a security update that patches this vulnerability. If you require an earlier version of the plugin, patched versions of older versions are available the <a href="https://wordpress.org/plugins/pods/developers/" target="_blank">releases page</a>. All users are advised to update immediately.</p>
<p>The Pods framework is used for creating, managing, and deploying customized content types and fields. It&#8217;s active on more than 30,000 WordPress installations. Contributors on the project credit Yoast&#8217;s transparency on the recent security issue as having inspired their team to proactively examine Pods.</p>
<p>&#8220;Reading the details of their issue led us to search for similar security issues in Pods,&#8221; Pollock said. &#8220;We applaud their responsible disclosure to the community. Publishing the details helps other developers work to improve security in their own codebase.&#8221;</p>
<h3>More Security Updates on the Way for Popular WordPress Plugins</h3>
<p>All relatively complex plugins will have security issues pop up from time to time that will require immediate patching. Fortunately, the plugin authors in these scenarios have been quick to respond.</p>
<p>This particular vulnerability is not limited to Pods and the WordPress SEO plugin by Yoast. Pollock advises that WordPress users should be on the lookout for more security updates to follow for other popular plugins.</p>
<p>&#8220;Our team has done a search in several other plugins for similar issues and has reported our findings to their authors,&#8221; he said. &#8220;At this time we can not share specifics about theses issues, but will as soon as it is responsible to do so.&#8221;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 16 Mar 2015 18:17:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Alex King: In Praise of BackupBuddy";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=21405";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://alexking.org/blog/2015/03/15/backupbuddy";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1571:"<p>I&#8217;m thrilled with my <a href="https://alexking.org/blog/2015/02/25/hosted-on-webfaction">new hosting set-up</a> for this site, however WebFaction doesn&#8217;t offer daily backups. I knew could spend the time to write a little script to export my database and pass it along to another storage location, but then I thought of <a href="https://ithemes.com/purchase/backupbuddy/">BackupBuddy from iThemes</a>.</p>
<p>5 minutes later I had BackupBuddy installed, with a nightly job configured to do a full export of my database and store the last 10 days of backups in my Dropbox account.</p>
<p>Sure, I could have written the code to do this myself. It&#8217;s always tempting to do-it-yourself when you know you <em>can</em> do something. The key is to ask yourself if you <em>should</em> do something. It would have taken much more than 5 minutes to get even a simple backup script written and configured; and I definitely wouldn&#8217;t have had the storage and and automation options that BackupBuddy provides out of the box.</p>
<p>If you need hassle-free backups for your self-hosted WordPress site<sup id="fnref:1"><a href="http://alexking.org/blog/topic/wordpress/feed#fn:1" rel="footnote">1</a></sup>, give BackupBuddy a try.</p>
<div class="footnotes">
<hr />
<ol>
<li id="fn:1">
If you have a website, <em>please</em> make sure you have an automated backup system, and that you&#8217;ve tested your backups to make sure they actually work.&#160;<a href="http://alexking.org/blog/topic/wordpress/feed#fnref:1" rev="footnote">&#8617;</a>
</li>
</ol>
</div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 15 Mar 2015 20:05:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Matt: Live in the Moment";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44759";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://ma.tt/2015/03/live-in-the-moment/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:369:"<p>Jenna Wortham writes on <a href="http://bits.blogs.nytimes.com/2014/10/18/trying-to-live-in-the-moment-and-not-on-the-phone/">Trying to Live in the Moment (and Not on the Phone)</a>. I&#8217;ve been using the Moment app recently too, <a href="https://cloudup.com/cSfRDLJHDiv">here&#8217;s my past week of usage</a>. (I think it might count phone calls as usage.)</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 15 Mar 2015 18:45:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Matt: Series A Struggle";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44853";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://ma.tt/2015/03/raising-series-a/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:312:"<p><a href="http://firstround.com/review/what-the-seed-funding-boom-means-for-raising-a-series-a/">Josh Kopelman on why raising a Series A is harder than ever, and how startups can adapt to survive the changing investment landscape</a>. Fantastic essay, relevant for every company raising money at any stage.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 14 Mar 2015 20:45:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: BuddyPress Live Notification 2.0 Adds Real-Time Notifications for Users";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://wptavern.com/buddypress-live-notification-2-0-adds-real-time-notifications-for-users";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3787:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/megaphone.jpg" rel="prettyphoto[40500]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/megaphone.jpg?resize=1024%2C484" alt="photo credit: MACSwriter - cc" class="size-full wp-image-28480" /></a>photo credit: <a href="https://www.flickr.com/photos/88758069@N08/8445004895/">MACSwriter</a> &#8211; <a href="http://creativecommons.org/licenses/by-sa/2.0/">cc</a>
<p>The <a href="https://wordpress.org/plugins/bp-live-notification/">BuddyPress Live Notification</a> plugin was originally released in 2011. Brajesh Singh, prolific plugin author and founder of <a href="http://buddydev.com/" target="_blank">BuddyDev</a>, created the plugin to provide Facebook-style real-time notifications for users. Over the past four years, a number of significant changes in both WordPress and BuddyPress have necessitated a complete rewrite of the extension.</p>
<p>The <a href="http://buddydev.com/buddypress/introducing-buddypress-live-notification-2-0/" target="_blank">2.0 version</a> of the plugin adds support for BuddyPress&#8217; new <a href="http://wptavern.com/buddypress-1-9-sammy-released-with-new-notifications-component" target="_blank">notifications component</a>, as well as the <a href="http://codex.wordpress.org/Function_Reference/wp_heartbeat_settings" target="_blank">Heartbeat API</a>, which is now used to fetch the notifications.</p>
<p>The updated version includes the following:</p>
<ul>
<li>Complete rewrite of the code to include support for BP notifications component (introduced in BuddyPress 1.9.0)</li>
<li>Uses WordPress Heartbeat API instead of long AJAX polling for greatly improved performance</li>
<li>Allows theme authors to change the notifying mechanism by overriding the  notify  method of the  bpln object</li>
<li>Fires custom JavaScript event bpln:new_notifications when new notifications are received on the client side. A theme author can hook into it to make modifications.</li>
</ul>
<p>Because BP Live Notification was designed to be easy to theme and extend, Singh created an <a href="https://github.com/sbrajesh/bp-live-notification-example-module" target="_blank">example plugin</a> to demonstrate how to replace the notify window UI with your own customization.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/jquery-notice-style.png" rel="prettyphoto[40500]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/jquery-notice-style.png?resize=449%2C250" alt="jquery-notice-style" class="aligncenter size-full wp-image-40617" /></a></p>
<p>The sample plugin repackages the notification window with the <a href="https://github.com/sbrajesh/bp-live-notification-example-module/tree/master/assets/notify" target="_blank">jQuery notice plugin</a>. Check out a <a href="http://creativedream.net/plugins/jquery.notify/" target="_blank">live demo</a> to see how that style of notice is presented.</p>
<p>If you don&#8217;t like how BP Live Notification styles its alerts by default, you can easily integrate a different jQuery notice plugin using the example Singh posted on GitHub. Searching the web will turn up a <a href="http://jqueryhouse.com/best-jquery-notification-plugins/" target="_blank">wide variety</a> of beautiful notification styles that you can adapt for use with BuddyPress.</p>
<p>Both Twitter and Facebook use live notifications to keep users interacting on their social networks. When you receive a live notice, it confirms, in an almost tangible way, that you are at the center of where the social activity is happening. If you think this would benefit your BuddyPress network, download <a href="https://wordpress.org/plugins/bp-live-notification/">BP Live Notification</a> 2.0 for free from WordPress.org.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 14 Mar 2015 02:07:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:80:"WPTavern: How to Stay in the Loop if You Turn Off WordPress’ Automatic Updates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40498";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://wptavern.com/how-to-stay-in-the-loop-if-you-turn-off-wordpress-automatic-updates";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5514:"<p>When a critical <a href="http://wptavern.com/blind-sql-injection-vulnerability-discovered-in-wordpress-seo-plugin-by-yoast-immediate-update-recommended" target="_blank">security vulnerability was discovered in Yoast&#8217;s SEO plugin</a> this week, WordPress.org took the initiative to automatically update users&#8217; sites with the patched version of the plugin. Many users were taken by surprise, given that the WordPress codex clearly stated that automatic plugin and theme updates are disabled by default.</p>
<p>Shortly after the automatic update rolled out, the <a href="http://codex.wordpress.org/Configuring_Automatic_Background_Updates" target="_blank">codex page</a> was updated to reflect the fact that in rare instances WordPress.org will automatically update your plugins and themes unless you opt to turn this feature off entirely. Many users are not comfortable with forced automatic updates, but the good news is that there is a filter to turn them off, including the WordPress.org security updates for popular plugins:</p>
<pre class="brush: php; light: true; title: ; notranslate">add_filter( \'auto_update_plugin\', \'__return_false\' );</pre>
<p>Prior to this security issue, users were not aware that they had to opt out of these forced updates. On one side of the fence there are those who think it&#8217;s no big deal and are thankful that WordPress.org is proactive on behalf of user security.</p>
<p>On the other hand, there are those who are wary of forced updates from plugin authors who are notorious for pushing out problematic updates. The <a href="https://wordpress.org/support/plugin/wordpress-seo">support forum</a> for Yoast&#8217;s SEO plugin contains many threads regarding fatal errors following updates issued in the past.</p>
<p>In this particular case, Nick Haskins <a href="http://nickhaskins.com/2015/03/on-automatic-wordpress-updates/" target="_blank">summarizes</a> why he was not comfortable with WordPress.org&#8217;s forced update:</p>
<blockquote><p>The plugin in question is Yoast WordPress SEO. If you’re not familiar with his plugins, the history of updates is awful. In the last two weeks, I’ve updated twice, and both times have resulted in fatal PHP errors which require FTP’ing into the site, to manually remove the plugin. Both cases were due to not checking if a file exists before loading it.</p></blockquote>
<p>Those who are not comfortable with WordPress.org&#8217;s forced update policy have the option to turn updates off for particular plugins or for all plugins. If you opt to go the route of turning automatic updates off, there are alternative ways that you can stay up-to-date on plugin releases.</p>
<h3>Get Email Notices When Core, Plugin, and Theme Updates are Available</h3>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/air-mail.jpg" rel="prettyphoto[40498]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/air-mail.jpg?resize=1018%2C494" alt="photo credit: Par avion - (license)" class="size-full wp-image-40600" /></a>photo credit: <a href="http://www.flickr.com/photos/79016591@N07/13204207393">Par avion</a> &#8211; <a href="https://creativecommons.org/licenses/by-nd/2.0/">(license)</a>
<p>No site admin can realistically be expected to log into his site(s) and check for update every day, let alone follow all the news surrounding plugin and theme security issues. The <a href="https://wordpress.org/plugins/wp-updates-notifier/" target="_blank">WP Updates Notifier</a> plugin will monitor your WordPress installation for updates and will send you an email as they become available. It includes the following features:</p>
<ul>
<li>Set the interval of how often to check for updates; hourly, twice daily or daily.</li>
<li>Sets WordPress to check for updates more often meaning you get to know about updates sooner.</li>
<li>Get emailed about core, plugin and theme updates.</li>
<li>Chose if you want to be notified about active only themes and plugins updates.</li>
<li>Remove upgrade nag message to non-admin users.</li>
<li>For advanced users there are a number of filters and actions you can use.</li>
</ul>
<p>It would be truly awesome if WP Updates Notifier was also able to scan a plugin&#8217;s changelog for the word &#8220;Security&#8221; and tack it onto the email if it is applicable.</p>
<p>WP Updates Notifier can be useful even if you&#8217;re comfortable allowing WordPress.org to perform occasional forced updates to themes and plugins for security. You may be using a plugin that is not nearly popular enough meet the criteria for a forced automatic update. Regardless, it may be useful for you to know as soon as there is an update available.</p>
<p>The important thing is to stay in the loop about potential security issues and get patches as soon as they are available. <a href="https://wordpress.org/plugins/wp-updates-notifier/" target="_blank">WP Updates Notifier</a> lets you do that without having to allow any third party update core, plugins, or themes on your server. The plugin is most useful when you have only a handful of sites or fewer. Otherwise, it&#8217;s probably better to utilize a central dashboard service where you check in regularly to see updates across all of your sites at once.</p>
<p>Your other alternative is to ditch plugins created by authors who you cannot trust to issue clean updates. That will put you in a better position to leave automatic background updates on, which is recommended for the vast majority of WordPress users.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 13 Mar 2015 19:38:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:88:"Post Status: Running a successful membership site in real life, with Jonathan Williamson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:30:"https://poststatus.com/?p=7208";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"https://poststatus.com/running-a-wordpress-membership-website-jonathan-williamson/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:12427:"<p>Jonathan Williamson is the co-founder and COO of <a href="http://cgcookie.com/">CGCookie</a>, a membership website that provides as an educational resource for computer graphics and modeling. CGCookie has been around since 2008, and today is a network of five websites, has thousands of paying members, a team of six full time employees plus a number of contractors.</p>
<p>CGCookie is built completely on WordPress and has a built in membership component. Some astute readers may recognize both the site and Jonathan&#8217;s name; Jonathan is <a href="https://twitter.com/pippinsplugins">Pippin Williamson&#8217;s</a> identical twin brother, and Pippin has worked with Jonathan on CGCookie many times. So, in this interview, you&#8217;re not listening to me talk to Pippin &#8212; though it sounds like it &#8212; but I&#8217;m talking to Jonathan Williamson.</p>
<p>Jonathan is as passionate about CG, modeling, 3D printing, and the software that surrounds these disciplines as Pippin is about WordPress and programming. It was a pleasure to talk to Jonathan about what it&#8217;s like to run a membership site that runs on WordPress. I think this interview will be beneficial for those that want to run a membership site, and also those that work with clients who make their living off of their website.</p>
<p><!--[if lt IE 9]><script>document.createElement(\'audio\');</script><![endif]-->
<a href="http://audio.simplecast.fm/9023.mp3">http://audio.simplecast.fm/9023.mp3</a><br />
<a href="http://audio.simplecast.fm/9023.mp3">Direct Download</a></p>
<p><a href="https://itunes.apple.com/us/podcast/post-status-draft-wordpress/id976403008">Or subscribe to the Post Status Draft podcast on iTunes!</a></p>
<h3>How CGCookie evolved</h3>
<p>CGCookie started as a blog with news, tutorials, and resources for CG enthusiasts. The first form of its monetization was by selling the source files for the various tutorials. Within about two years, Jonathan and co-founder Wes Burke decided to add a membership component that ended up working far better than they anticipated.</p>
<p>Jonathan has been working full-time on CGCookie since around the summer of 2009. They originally launched on aMember, before eventually migrating to Pippin&#8217;s <a href="https://pippinsplugins.com/restrict-content-pro-premium-content-plugin/">Restrict Content Pro</a> plugin, along with <a href="https://easydigitaldownloads.com/">Easy Digital Downloads</a>.</p>
<p>Today, CGCookie has more than 120,000 free users, and they have around 4,800 paid members.</p>
<p>Since 2008, CGCookie have managed to not have a full time web developer until February of 2014, when they hired Nick Haskins. You may recognize Nick as the founder of <a title="Aesop, a Medium-esque “story engine” for WordPress" href="https://poststatus.com/aesop-medium-esque-story-engine-wordpress/">Aesop Stories</a> as well. Nick manages front-end development for the site, and they still don&#8217;t have a backend developer &#8212; though a backend developer and designer are on their roadmap.</p>
<h3>How CGCookie&#8217;s eCommerce setup runs</h3>
<p>Considering Jonathan is using his brother&#8217;s own plugins in the real world, it makes for a great avenue for feedback and insight for Pippin to improve those products.</p>
<p>CGCookie is using Restrict Content Pro for <a href="https://cgcookie.com/membership/">memberships</a> themselves, and EDD plus the <a href="https://easydigitaldownloads.com/extensions/frontend-submissions/">Front-End Submissions</a> add-on for their <a href="http://cgcookiemarkets.com/blender/">marketplace</a>. We talked about whether EDD could be used for both, or if there is room for improvement in the marriage between the two systems, and he believes there is and that it&#8217;s a goal for the two plugins. For instance, currently, reporting and user management and a number of other features are independent between each plugin even though often times the users that utilize the system may overlap.</p>
<p>I asked Jonathan about scaling WordPress and eCommerce for their large user base. He says that scaling for eCommerce has not been difficult, but with over a hundred thousand users, some default WordPress functionality has not scaled well; for instance, some admin areas create dropdowns for all users, which does not work well. Fortunately, there are some trac tickets in place currently to help solve some of these problems.</p>
<h3>Prioritizing goals for a membership site</h3>
<p>When discussing challenges running a membership site, Jonathan highlights the internal battles: balancing new features versus iterative improvements. Based on my short experience managing this membership site, I completely agree.</p>
<p>For an example, Jonathan told me about a potential question and answer system to help his members get answers for specific technical topics that may be beyond the scope of a specific course. They believe a Stack Exchange style setup that allows them to refer their courses to specific questions would allow them to better serve their customers with the same content they already have.</p>
<blockquote><p>How do you get people to find your content that answers their question, but you don&#8217;t have a way of just explicitly saying that these are the questions this course answers?</p></blockquote>
<p>They&#8217;re considering a method of post to post relationships that direct courses as question answers and vice versa. For this feature and others, they try to do things with a short return on investment, but they also don&#8217;t want to be a slave to it. They sometimes do things &#8220;that are important to the quality of CGCookie, that never make a dime.&#8221; They removed ads last year under that very premise, to make CGCookie a better learning experience.</p>
<h3>Not the only place to learn</h3>
<p>Jonathan knows CGCookie isn&#8217;t the only place to learn, so they focus on creating an excellent community and learning experience for their customers.</p>
<p>Realizing that our sites aren&#8217;t the only way to get certain information is an important thing to know to be able to better focus what we create for our users and why we create it.</p>
<h3>Pricing for CGCookie</h3>
<p>CGCookie has pricing for monthly, quarterly, or yearly pricing; all plans renew automatically unless explicitly cancelled. This is a feature they actively A/B test to see what&#8217;s working and what&#8217;s not.</p>
<p>Behavior of customers varies between the three levels. Jonathan says that the users are more invested in their purchases (and getting more out of it) when they sign up for longer. Quarterly members have 10% longer lifetime memberships and spend three times longer on the site.</p>
<p>However, they do have &#8220;a fair bit&#8221; of what I called &#8220;download and dash&#8221; members that sign up for a month, download a bunch of assets and cancel. Monthly memberships are also the most popular plan. They&#8217;ve considered locking down downloads for monthly signups but it&#8217;s not something they want to do unless it becomes a bigger problem; however they do lose money on those customers that download gigabytes of files and videos but only stay subscribed for one month.</p>
<h3>Testing</h3>
<p>During A/B tests, they have found that people will be just as likely to sign up for quarterly as monthly if monthly isn&#8217;t available, and quarterly members are more engaged. One thing they noted is that once people stick around for a few months, the average tenure of a user skyrockets; they have some users that have been a paying member as long as the site has been running.</p>
<p>One of my big takeaways talking to Jonathan was about how significant testing can be. Their tests help them decide on the optimal pricing and payment plans to maximize a lifetime value.</p>
<p>For testing, insights, and statistics they use <a href="https://www.optimizely.com/">Optimizely</a>, <a href="https://mixpanel.com/">Mixpanel</a>, and Google Analytics.</p>
<p>Mixpanel allows you to create custom events in your software, and does require some code knowledge, but it can deliver valuable insights if you use it correctly. Jonathan notes, &#8220;It&#8217;s basically as comprehensive as you make it.&#8221;</p>
<p>They can also mesh tools. They can track which A/B test from Optimizely a customer signed up with, and then use Mixpanel to track what they did and how they did it. They can get login metrics, renewal numbers, and more for each plan and signup flow.</p>
<p>Mixpanel requires PHP and JavaScript knowledge to utilize, but Optimizely has an extensive visual interface that doesn&#8217;t require code knowledge to utilize.</p>
<h3>What encourages membership signups</h3>
<p>&#8220;It varies day to day, week to week, month to month,&#8221; in regard to how their signups work. A bad month in the economy can make their signups go down. Sometimes quarterly users will spike while monthly users are steady.</p>
<p>Their biggest thing that affects signup rates is customer support. Some presale, but also support for new members to help answer questions and get people engaged. <span class="pullquote alignright">When we can help someone answer the question, &#8220;Where do I go next?&#8221;, we are able to keep them for a long time.</span></p>
<p>They have one or two courses that drive a ton of traffic to their site, and it is therefore their largest onboarding channel for new members. However, they don&#8217;t have a silver bullet for what it takes to get new users. They are always trying new things.</p>
<h3>On competing and the industry</h3>
<p>Jonathan doesn&#8217;t see themselves as a part of a singular industry. While many think of CG as a part of the film industry, it&#8217;s one of dozens of potential applications, and they don&#8217;t want to narrow themselves to a particular one.</p>
<p>They also poll users to get a feel for who they are and what industry actual users come from. Based on around a thousand responses, they had no real pattern at all. The results were all over the board.</p>
<p>So they don&#8217;t want to compete with a film tutorials site or any other industry site. They want to focus on the tool itself. They want to teach people how to use Blender and show them how it can be applied to various industries their users are a part of.</p>
<h3>Advice for those running membership sites</h3>
<blockquote><p>&#8220;Build your community would be the main one. It&#8217;s one thing to offer a really good product. It&#8217;s one thing to build a really good website. But if you don&#8217;t have the community behind you that&#8217;s going to be willing to trust in you with their wallet &#8230; it&#8217;s not going to go anywhere long term, sustainably.&#8221;</p></blockquote>
<p>Jonathan says it&#8217;s about building the community as well as the sense of trust within that community. He believes that customers will want to know that not only the content will be worth it, but that it will continue to be worth it &#8212; and that the communication and support from the team behind the site will be consistent as well.</p>
<p>He believes that subscriptions and products are very different. With a subscription, the interaction is just as or far more important than specific content itself.</p>
<p>When he refers to community, he doesn&#8217;t mean it has to be strictly through something like a forum. He considers it a broad term, and for them it evolved out of their Blender community user base. At the time we recorded this, they didn&#8217;t have forums, a dedicated chat system, or an actual community integration part &#8212; though <a href="http://community.cgcookie.com/">they have opened a forum</a> since we chatted. But the community exists and thrives within comments and their gallery functionality.</p>
<h3>Wrapping up</h3>
<p>Jonathan is full of great advice and I could listen to him talk about membership sites for a long time. I have no experience with CG but at the end of this interview he had me wanted to go build something with Blender.</p>
<p>You can (and should) keep up with <a href="https://twitter.com/carter2422">Jonathan on Twitter</a>, or perhaps you&#8217;ll see him at a conference near you &#8212; but you&#8217;ll probably think it&#8217;s Pippin at first. Also be sure to checkout <a href="http://cgcookie.com/">CGCookie&#8217;s website</a>; it&#8217;s really great.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 13 Mar 2015 17:01:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"Matt: Love is the light that sparked when only darkness existed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:79:"http://ma.tt/2015/03/love-is-the-light-that-sparked-when-only-darkness-existed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://ma.tt/2015/03/love-is-the-light-that-sparked-when-only-darkness-existed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:186:"<p>&nbsp;<img alt="" src="http://i1.wp.com/ma.tt/files/2015/03/IMG_5196.jpg?resize=604%2C466" title="" class="size-custom" /></p>
<p>Taken in Houston today. Happy birthday Mom!&nbsp;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 13 Mar 2015 15:49:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:37:"Matt: Government Taking Over Internet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44766";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ma.tt/2015/03/government-taking-over-internet/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:569:"<p>Since the Title II ruling from the FCC there&#8217;s been a lot of partisan rhetoric about the government taking over the internet, <a href="http://ma.tt/2015/02/net-neutrality-win/">even in the comments of this very blog</a>. I just came across Brad Feld&#8217;s post, <a href="http://feld.com/archives/2015/02/final-thoughts-fcc-title-ii-ahead-tomorrows-vote-net-neutrality.html">Some Final Thoughts on the FCC and Title II Ahead of Tomorrow&#8217;s Vote on Net Neutrality</a> and he does an awesome job breaking down and addressing each of the misconceptions.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 13 Mar 2015 02:06:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WPTavern: WordPress 4.2 Beta 1 Now Available for Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40568";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wptavern.com/wordpress-4-2-beta-1-now-available-for-testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3336:"<p><a href="https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/" target="_blank">WordPress 4.2 beta 1</a> is now available for early testers to download. It&#8217;s &#8220;pencils down&#8221; time for core contributors as far as new feature requests are concerned. This is the point in the release cycle where contributors are focusing their efforts on bug fixes and inline documentation.</p>
<p>Drew Jaynes, the 4.2 release lead, posted the <a href="https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/" target="_blank">beta release announcement</a> and summarized the main features that could use further testing. The <a href="http://wptavern.com/preview-the-press-this-bookmarklet-redesign-alpha-plugin-now-ready-for-testing" target="_blank">Press This bookmarklet feature has been totally redeigned</a> to be more intuitive and mobile-friendly. If you want to test it out, install the beta and then navigate to the Tools screen in the admin.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/press-this-featured.jpg" rel="prettyphoto[40568]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/press-this-featured.jpg?resize=898%2C408" alt="press-this-featured" class="aligncenter size-full wp-image-24221" /></a></p>
<p>Jaynes also encourages users to test drive the new theme browsing and switching capabilities that are now built into the customizer. &#8220;We’re especially interested to know if this helps streamline the process of setting up your site,&#8221; he said.</p>
<p>The customizer theme switcher is one of the more controversial additions to this release. The new feature was met with a significant amount of resistance from our commenters when it was <a href="http://wptavern.com/customizer-theme-switcher-approved-for-merge-into-wordpress-4-2" target="_blank">approved for merge into WordPress 4.2</a>.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/02/customizer-theme-switcher.jpg" rel="prettyphoto[40568]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/02/customizer-theme-switcher.jpg?resize=1025%2C473" alt="customizer-theme-switcher" class="aligncenter size-full wp-image-38931" /></a></p>
<p>The installation and update process for plugins has been beautifully re-tooled to provide a smoother, more convenient experience where users can perform these actions without leaving the Plugins screen. Feel free to leave any feedback on the corresponding <a href="https://core.trac.wordpress.org/ticket/29820" target="_blank">ticket</a> for this improvement.</p>
<p>WordPress 4.2 also <a href="http://wptavern.com/wordpress-4-2-on-track-to-expand-core-support-for-emoji" target="_blank">expands core support for emoji</a>. Jaynes suggested that users go to town on testing it everywhere.</p>
<p>&#8220;If you felt like emoji were starkly missing from your content toolbox, worry no more,&#8221; he said. &#8220;We’ve added emoji support nearly everywhere, even post slugs.&#8221;</p>
<p>According to the current <a href="https://make.wordpress.org/core/version-4-2-project-schedule/" target="_blank">4.2 project schedule</a>, the official release is targeted for the week of April 22nd. A series of betas and at least one release candidate are likely to precede the official release during the course of the next month.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 13 Mar 2015 00:01:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WPTavern: WPWeekly Episode 183 – Backing Up The Backup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=40559&preview_id=40559";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wptavern.com/wpweekly-episode-183-backing-up-the-backup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4337:"<p>In this episode of WordPress Weekly, <a title="http://onlinebizcoach.com/" href="http://onlinebizcoach.com/">Marcus Couch</a> and I discuss a lot of different stories. We share our opinions on the redesigned theme and plugin directories. We discuss CodeGuard&#8217;s survey results that indicate WordPress users need a lot more education on backup plugins, strategies, and services. Last but not least, we discuss the WordPress history book. Near the end of the show, Marcus describes a new venture he&#8217;s pursuing to help coach online businesses.</p>
<h2>Stories Discussed:</h2>
<p><a title="http://wptavern.com/wordpress-version-stats-updated-more-than-13-of-sites-are-running-wordpress-4-1" href="http://wptavern.com/wordpress-version-stats-updated-more-than-13-of-sites-are-running-wordpress-4-1">WordPress Version Stats Updated: More Than 1/3 of Sites are Running WordPress 4.1</a><br />
<a title="http://wptavern.com/wordpress-plugin-directory-launches-new-design" href="http://wptavern.com/wordpress-plugin-directory-launches-new-design">WordPress Plugin Directory Launches New Design</a><br />
<a title="http://wptavern.com/wordpress-theme-directory-launches-new-design" href="http://wptavern.com/wordpress-theme-directory-launches-new-design">WordPress Theme Directory Launches New Design</a><br />
<a title="http://wptavern.com/version-one-of-the-wordpress-history-book-is-ready-for-review" href="http://wptavern.com/version-one-of-the-wordpress-history-book-is-ready-for-review">Version One of The WordPress History Book is Ready For Review</a><br />
<a title="http://wptavern.com/wordpress-publishes-security-white-paper" href="http://wptavern.com/wordpress-publishes-security-white-paper">WordPress Publishes Security White Paper</a><br />
<a title="http://wptavern.com/codeguard-survey-shows-more-education-is-needed-on-backup-software-services-and-strategies-for-wordpress" href="http://wptavern.com/codeguard-survey-shows-more-education-is-needed-on-backup-software-services-and-strategies-for-wordpress">CodeGuard Survey Shows More Education is Needed on Backup Software, Services, and Strategies For WordPress</a><br />
<a title="http://wptavern.com/bbpress-2-5-5-released-patches-three-potential-security-vulnerabilities" href="http://wptavern.com/bbpress-2-5-5-released-patches-three-potential-security-vulnerabilities">bbPress 2.5.5 Released, Patches Three Potential Security Vulnerabilities</a><br />
<a title="http://wptavern.com/blind-sql-injection-vulnerability-discovered-in-wordpress-seo-plugin-by-yoast-immediate-update-recommended" href="http://wptavern.com/blind-sql-injection-vulnerability-discovered-in-wordpress-seo-plugin-by-yoast-immediate-update-recommended">Blind SQL Injection Vulnerability Discovered in WordPress SEO Plugin by Yoast: Immediate Update Recommended</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a title="https://wordpress.org/plugins/custom-upload-folders-plus/" href="https://wordpress.org/plugins/custom-upload-folders-plus/">Custom Upload Folders Plus</a> lets you organize file uploads by file type and logged in users.</p>
<p><a title="https://wordpress.org/plugins/scratchpad/" href="https://wordpress.org/plugins/scratchpad/">Scratchpad</a> lets you keep running notes when composing your posts. It can be used to keep an outline for the post, be visible next to the post, or to have a list of links or snippets to refer to.</p>
<p><a title="https://wordpress.org/plugins/gravity-buttons/" href="https://wordpress.org/plugins/gravity-buttons/">Gravity Buttons</a> is a powerful button creation plugin that allows anyone to create great-looking CSS3 buttons that can be used anywhere on your site.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, March 18th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #183:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Mar 2015 22:58:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"WPTavern: Is a WordPress Plugin a Startup?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40528";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wptavern.com/is-a-wordpress-plugin-a-startup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8949:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/petersuhm.jpeg" rel="prettyphoto[40528]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/petersuhm.jpeg?resize=150%2C150" alt="petersuhm" class="alignright size-thumbnail wp-image-40534" /></a>This post was contributed by guest author <a href="http://petersuhm.com/" target="_blank">Peter Suhm</a>. Peter is a web developer from the Land of the Danes. He is the creator of <a href="http://wptavern.com/wp-pusher-aims-to-provide-pain-free-deployment-of-wordpress-themes-and-plugins-from-github" target="_blank">WP Pusher</a> and a huge travel addict, bringing his work along with him as he goes.<br />
&nbsp;</p>
<hr />
<p>About two months ago, I released my first commercial WordPress product, <a href="https://wppusher.com/" target="_blank">WP Pusher</a>, a plugin that makes deploying themes and plugins really easy. WP Pusher was not meant to be &#8220;just a plugin&#8221;. It was supposed to be a SaaS product, and throughout it all, when I was building it, I always thought of it as a startup I was creating.</p>
<p>For &#8220;just a WordPress plugin&#8221;, I think it has been quite successful so far, and to a large extent, I believe that to be a result of my own perception of the whole thing. I think it was more successful because, even after I realized it was just going to be a plugin, I still treated it as a startup.</p>
<h2>What Is a Startup?</h2>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/office.jpeg" rel="prettyphoto[40528]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/office.jpeg?resize=1025%2C493" alt="office" class="aligncenter size-full wp-image-40552" /></a></p>
<p>In the fall of 2014, I was traveling around Southeast Asia, enjoying the digital nomad lifestyle, while making WP Pusher. I spent quite a bit of time in Chiang Mai, the capital of digital nomads, and everyone was talking about a guy named Pieter Levels, who did all kinds of cool things, all related to digital nomadism. One of these things was to take up the challenge of building a new startup every month for 12 months.</p>
<p>Hearing people talk about Pieter&#8217;s startup quest got me thinking about the term &#8220;startup&#8221;. Honestly, when I first heard about it, I did not think of the 12 startups as real startups &#8211; which Pieter obviously did. To me, creating a portfolio of 12 startups in such a short time seemed a bit silly. In my head, a real startup required more dedication and commitment than that.</p>
<p>In the meantime, some of Pieter&#8217;s startups have been really successful and the whole process has been really inspiring to follow. I now understand that my idea of a startup was missing some pieces. All of the 12 projects that Pieter created qualified as startups. Some of them were more successful than others, but he validated 12 ideas in a short time and the result is really impressive. And one thing, which is very important, is that Pieter treated all of the 12 projects as startups instead of just another side project (which is how many developers talk about their projects). Calling something a side project is an easy way of protecting yourself against your fear of failure.</p>
<p>If you ask Steve Blank about his definition of a startup, he will tell you that <a href="http://steveblank.com/2010/01/25/whats-a-startup-first-principles/" target="_blank">&#8220;a startup is an organization formed to search for a repeatable and scalable business model&#8221;</a>. If we break that up, “an organization” can mean anything. It can be you alone or it can be a team. “Repeatable” and “scalable” are two sides of the same coin.</p>
<p>Building a WordPress plugin and calling it a day is not enough. That is not a startup. Honestly, to me, “repeatable“ is the main factor. I am in it for the freedom &#8211; not the empire building. I want a business to be repeatable in the sense that I can teach someone else how to run it for me &#8211; hence, freedom. It does not have to be scalable in order to put food on my table or allow me to travel around the world &#8211; it just has to be profitable.</p>
<p>WordPress offers a giant market full of small niches and potential customers. There is no reason why something you are building for WordPress could not be as huge as any other software startup. The market share of the WordPress platform is <a href="http://w3techs.com/technologies/overview/content_management/all/" target="_blank">large enough</a>.</p>
<p>In relation to the Steve Blank quote, what could you do to make your WordPress plugin a startup instead of a side project? First of all, you need to think about the &#8220;organization&#8221;. Most likely, you are the programmer or the engineer behind your product. But do you know how to design a shiny, high-converting landing page? Do you have any clue about how to approach marketing or customer relations? What about the legal and financial aspects? Maybe you do. If you do not, you need to either be willing to learn or team up with someone who does. At the very minimum, you need to at least consider it.</p>
<p>How can you build a business around a WordPress plugin that is more &#8220;repeatable&#8221; and &#8220;scalable&#8221;? Well, you could do most of the things that other startups do. Here are a few questions to consider:</p>
<ul>
<li>Could you charge more or offer more expensive options?</li>
<li>Could you turn your plugin into a SaaS or find something that you could charge for on a recurring basis?</li>
<li>Could you sell additional add-ons or extensions for your plugin?</li>
<li>Could you offer a service in addition to your plugin?</li>
<li>Given you solve some kind of pain for your customers, could you copy your idea to other niches or customer segments?</li>
<li>Could you come up with ways to attract more customers on a recurring basis? (SEO, content marketing, advertising etc.)</li>
<li>Could you have someone else help you find new customers? (copywriters, affiliate partners etc.)</li>
</ul>
<p>You get it.</p>
<h2>Solving Your Own Problems vs. Solving Other People&#8217;s Problems</h2>
<p>A very important point I want to make relates to the business idea of your WordPress plugin. In a market like WordPress, programmers tend to be tempted to find solutions to their own problems &#8211; not necessarily other people&#8217;s problems. Finding a solution for a problem you have yourself is a good place to start and great for motivation, domain knowledge and so on, but it is not enough.</p>
<p>If you want it to be a business, you need to make sure that other people have the same problem and are willing to pay for it. Startups are not made to solve their own problems. The original business idea behind the startup might have been to solve a problem the founder had, but if the only customer in the startup is going to be the founder alone, it is not a very good business model. You need to figure out how you can make your product relevant to more people &#8211; not everyone of course, but more people than yourself.</p>
<p>As an example, WP Pusher solves a problem I had with clients. There were already solutions to this problem &#8211; both free and paid. Most of them required either Git installed or that I granted them access to my clients&#8217; servers. Given I am actually in control of, or at least have an influence over, most of the server environments of my clients, I could in theory have used one of these existing solutions.</p>
<p>However, I knew that was not the case for a lot of WordPress developers. I saw the possibility of solving my own problem as well as solving a problem I knew a lot of other developers had. Reading about Pieter&#8217;s 12 startups inspires me to build more products for WordPress. Solve more problems. Build more startups.</p>
<h2>Say It Out Loud</h2>
<p>When I thought WP Pusher was going to be a SaaS business, I thought of it as a startup. When I decided to change the business model and rebuild it all as a single plugin, it felt weird calling it a business &#8211; or even a startup. For a short time I think I phrased it as &#8220;just a project for WordPress&#8221;, when telling people about it.</p>
<p>Personally, I still like to think of it as a startup. I kept the landing page I built for the SaaS and I kept the blog I set up. I kept everything that I initially made when it was a &#8220;startup&#8221; I was working on. Today, I have made a conscious decision that it is in fact a startup &#8211; no matter how big or small it is.</p>
<p>WP Pusher has many characteristics of a startup. It solves a very obvious pain point that is easy to communicate. It has a simple business model in a very large market. And finally, it has a logo and it has a nice landing page. That is a startup right there.</p>
<p>What are you missing before you can confidently call your WordPress plugin a startup?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Mar 2015 21:28:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"Matt: Portland + Phoenix Press Publish Events";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44801";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://ma.tt/2015/03/portland-phoenix-press-publish-events/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:775:"<p>We&#8217;re organizing an exciting <a href="http://presspublish.events/">new conference series focused on blogging, called Press Publish</a>. The speaker list has some really awesome folks on it, and will include notable WordPress bloggers telling their stories as well as <a href="http://automattic.com/">Automattic</a> employees teaching tutorials and workshops. Plus, WordPress.com Happiness Engineers will be ready and waiting to help people one-on-one with their blogs.</p>
<p>The first two events are in <strong>Portland</strong> on March 28 and in <strong>Phoenix</strong> on April 18, and <a href="http://presspublish.events/register/?tix_coupon=MATTBLOG">if you register with this link in the next week or so you get a discount</a>, special for Ma.tt readers.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Mar 2015 04:58:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WPTavern: EDD 2.3 Introduces New Customer Management Interface and Performance Improvements";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40484";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://wptavern.com/edd-2-3-introduces-new-customer-management-interface-and-performance-improvements";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4339:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/EasyDigitalDownloadsFeaturedImage.png" rel="prettyphoto[40484]"><img class="aligncenter size-full wp-image-40496" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/EasyDigitalDownloadsFeaturedImage.png?resize=620%2C223" alt="EasyDigitalDownloadsFeaturedImage" /></a></p>
<p>Easy Digital Downloads 2.3 is <a title="https://easydigitaldownloads.com/blog/version-2-3-released/" href="https://easydigitaldownloads.com/blog/version-2-3-released/">available for download</a> and includes new features along with performance improvements. One of the highlights is the new customer management interface. The improved interface lets you quickly browse customer data in an intuitive fashion. There&#8217;s also some new API&#8217;s that allow developers to interact with customer data behind the scenes.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/EDD23CustomerManagmentInterface.png" rel="prettyphoto[40484]"><img class="size-full wp-image-40487" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/EDD23CustomerManagmentInterface.png?resize=1025%2C808" alt="New Customer Management Interface" /></a>New Customer Management Interface
<p>File download URLs are more secure, have better performance, and are more reliable. URLs now contain secure tokens and expiration dates to maintain the security of files. This decreases the likelihood of individuals being able to tamper with downloadable files. URLs are also shorter and easier to share.</p>
<p>EDD 2.3 significantly improves stat tracking. For example, when you add or remove Download products on an existing payment record, the earnings and sales for the affected products are now properly updated when the payment record is saved. Performance improvements to reports include:</p>
<ul>
<li>Tax reports are now much more efficient</li>
<li>A race condition related to the update process for Download earnings / sales has been resolved</li>
<li>Individual customer stats are now much more performant</li>
<li>The Sales / Earnings widget on the Dashboard now loads via Ajax to improve the first-load performance</li>
</ul>
<p>According <a title="https://twitter.com/chriscct7/status/575724923899023360" href="https://twitter.com/chriscct7/status/575724923899023360">to Chris Christoff</a>, core developer of EDD, the product has officially passed 10,000 commits made by 121 people since its inception on Github. Pippin Williamson, founder of EDD, states on Twitter that even though the release adds substantial features, the code base has shrunk significantly.</p>
<blockquote class="twitter-tweet" width="550"><p>Thanks to the keen eyes of <a href="https://twitter.com/andyfragen">@andyfragen</a>, it\'s been noticed that the EDD code base shrunk significantly with 2.3, even though we add a LOT</p>
<p>&mdash; Pippinsplugins (@pippinsplugins) <a href="https://twitter.com/pippinsplugins/status/575721400650043392">March 11, 2015</a></p></blockquote>
<p></p>
<p>EDD 2.3 has eight other notable improvements:</p>
<ul>
<li>Download products can now be added to the cart with multiple price IDs at one time</li>
<li>Better support for the <a href="https://wordpress.org/plugins/polylang/" target="_blank">Polylang</a> plugin has been added</li>
<li>PayPal Buy Now buttons no longer create pending payment records on each click</li>
<li>A new {ip_address} email tag has been added</li>
<li>Numerous new action hooks and filters have been added for developers</li>
<li>Numerous translation files have been added and several new languages as well</li>
<li>The display of items in the cart widget has been improved to properly show quantities</li>
<li>A large number of minor PHP issues have been resolved</li>
</ul>
<p>The full list of bugs and improvements is <a title="https://github.com/easydigitaldownloads/Easy-Digital-Downloads/issues?q=is%3Aissue+milestone%3A2.3+is%3Aclosed" href="https://github.com/easydigitaldownloads/Easy-Digital-Downloads/issues?q=is%3Aissue+milestone%3A2.3+is%3Aclosed">available on Github</a>. You can <a title="https://wordpress.org/plugins/easy-digital-downloads/" href="https://wordpress.org/plugins/easy-digital-downloads/">download 2.3</a> from the WordPress plugin directory or update from within WordPress by visiting the Updates screen.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Mar 2015 23:18:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WPTavern: WordPress Foundation Website Gets a Redesign";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40035";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wptavern.com/wordpress-foundation-website-gets-a-redesign";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3663:"<p>The <a href="http://wordpressfoundation.org/" target="_blank">WordPress Foundation</a> website is sporting a fresh coat of paint, based on the Twenty Fifteen default theme released with <a href="http://wptavern.com/wordpress-4-1-dinah-released" target="_blank">WordPress 4.1</a> last December. The foundation exists to further the mission of the open source project, most importantly by ensuring free access to the software for years to come. It also serves to protect the WordPress-related trademarks and educate the public about the software.</p>
<p>With that mission at its core, it&#8217;s fitting that the foundation selected Twenty Fifteen for the new look. Matt Mullenweg, founder of the organization, <a href="https://twitter.com/photomatt/status/573256190462984192" target="_blank">identified</a> Automattic employee <a href="https://twitter.com/NickHamze" target="_blank">Nick Hamze</a> as responsible for the foundation&#8217;s updated design.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/wordpress-foundation.png" rel="prettyphoto[40035]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/wordpress-foundation.png?resize=1025%2C703" alt="wordpress-foundation" class="aligncenter size-full wp-image-40473" /></a></p>
<p>When we offered a <a href="http://wptavern.com/first-look-at-designs-for-the-twenty-fifteen-default-wordpress-theme" target="_blank">first look at the design of Twenty Fifteen</a> prior to its release, readers made it clear that this theme would be more enthusiastically received than any other default theme in WordPress&#8217; recent history. Twenty Fifteen offers users a clean canvas that easily lends itself to customization.</p>
<p>Nick Hamze&#8217;s personal <a href="http://blog.nickhamze.com/" target="_blank">blog</a> is another beautiful example of a Twenty Fifteen customization in the wild.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/nick-hamze.png" rel="prettyphoto[40035]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/nick-hamze.png?resize=1025%2C688" alt="nick-hamze" class="aligncenter size-full wp-image-40474" /></a></p>
<p>WordCamps in particular are making excellent use of the default theme as a base for their event websites. <a href="http://maine.wordcamp.org/2015/" target="_blank">WordCamp Maine 2015</a> is a prime example of how designers are creatively adapting Twenty Fifteen:</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/wordcamp-maine.png" rel="prettyphoto[40035]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/wordcamp-maine.png?resize=1025%2C713" alt="wordcamp-maine" class="aligncenter size-full wp-image-40475" /></a></p>
<p><a href="http://london.wordcamp.org/2015/" target="_blank">WordCamp London 2015</a> organizers used the default theme to bring a grunge look to their site with the help of Google fonts and spray paint style backgrounds.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/wordcamp-london.png" rel="prettyphoto[40035]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/wordcamp-london.png?resize=1025%2C713" alt="wordcamp-london" class="aligncenter size-full wp-image-40477" /></a></p>
<p>Armed with a unique background image and a little bit of color inspiration, it&#8217;s easy for anyone to make their own totally unique version of Twenty Fifteen. Thanks to the options built into the customizer, you may not even need to create a child theme.</p>
<p>Where else have you seen <a href="https://wordpress.org/themes/twentyfifteen/" target="_blank">Twenty Fifteen</a> in the wild?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Mar 2015 22:44:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WPTavern: Akismet Improves User Privacy by Encrypting API Calls";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40459";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wptavern.com/akismet-improves-user-privacy-by-encrypting-api-calls";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2837:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/AkismetSSLFeaturedImage.png" rel="prettyphoto[40459]"><img class="size-full wp-image-40462" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/AkismetSSLFeaturedImage.png?resize=656%2C301" alt="Akismet SSL Featured Image" /></a>photo credit: <a href="http://www.flickr.com/photos/61423903@N06/7557181168">Secure Cloud Computing</a> &#8211; <a href="https://creativecommons.org/licenses/by/2.0/">(license)</a>
<p>Akismet 3.1 <a title="https://blog.akismet.com/2015/03/11/akismet-3-1-wordpress/" href="https://blog.akismet.com/2015/03/11/akismet-3-1-wordpress/">is available for download</a> and contains a bug fix that prevents it from inadvertently modifying a comment’s content during the spam filtering process. In addition to the bug fix, calls made to the Akismet API are now encrypted via SSL.</p>
<p>While it may not seem like much on the surface, encrypting communications between WordPress and Akismet is an important change that increases the privacy of those who leave comments on your site. Christopher Finke, who works on the Akismet development team, explains why:</p>
<blockquote><p>Akismet&#8217;s API is being offered over SSL for the same reason that all <a href="http://wordpress.com">wordpress.com</a> subdomains are <a title="https://en.blog.wordpress.com/2014/06/05/reset-the-net/" href="https://en.blog.wordpress.com/2014/06/05/reset-the-net/">now served over SSL by default</a>. Encrypting that connection decreases the chances of surveillance by a third-party. No matter what a commenter is writing about, sending their comment to be checked using SSL ensures that it will only be read by those who are meant to read it.</p></blockquote>
<p>The move is part of a larger effort to apply SSL across WordPress.com and WordPress.org. In late 2014, almost all of WordPress.org <a title="https://make.wordpress.org/meta/2014/09/23/wordpress-org-is-now-forced-ssl/" href="https://make.wordpress.org/meta/2014/09/23/wordpress-org-is-now-forced-ssl/">was transitioned</a> to load over SSL/HTTPS. As part of the security hardening process of WordPress 3.7, <a title="http://codex.wordpress.org/WordPress.org_API" href="http://codex.wordpress.org/WordPress.org_API">api.wordpress.org,</a> which handles theme, plugin, and core updates, was forced to use SSL if the webserver supports it.</p>
<p>If you&#8217;re not sure what SSL is or would like to learn how to implement it on your site, read the <a title="https://make.wordpress.org/support/user-manual/web-publishing/https-for-wordpress/" href="https://make.wordpress.org/support/user-manual/web-publishing/https-for-wordpress/">HTTPS section in the WordPress user manual</a>. It has an introduction to the protocol and provides tips on implementing, tweaking, and applying good practices</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Mar 2015 21:12:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:117:"WPTavern: Blind SQL Injection Vulnerability Discovered in WordPress SEO Plugin by Yoast: Immediate Update Recommended";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40433";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:126:"http://wptavern.com/blind-sql-injection-vulnerability-discovered-in-wordpress-seo-plugin-by-yoast-immediate-update-recommended";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4095:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/yoast.jpg" rel="prettyphoto[40433]"><img class="aligncenter size-full wp-image-40456" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/yoast.jpg?resize=1025%2C457" alt="yoast" /></a></p>
<p>A blind SQL injection vulnerability was discovered today in the popular <a href="https://wordpress.org/plugins/wordpress-seo/" target="_blank">WordPress SEO plugin by Yoast</a>. WPScanVulnerability Database <a href="https://wpvulndb.com/vulnerabilities/7841" target="_blank">issued an advisory</a> after responsibly disclosing the vulnerability to the plugin&#8217;s author:</p>
<blockquote><p>The latest version at the time of writing (1.7.3.3) has been found to be affected by two authenticated (admin, editor or author user) Blind SQL Injection vulnerabilities.</p>
<p>The authenticated Blind SQL Injection vulnerability can be found within the &#8216;admin/class-bulk-editor-list-table.php&#8217; file. The orderby and order GET parameters are not sufficiently sanitized before being used within a SQL query.</p></blockquote>
<p>Yoast was quick to respond with a patch and released version 1.7.4 with the following security fix:</p>
<blockquote><p>Fixed possible CSRF and blind SQL injection vulnerabilities in bulk editor. Added strict sanitation to order_by and order params. Added extra nonce checks on requests sending additional parameters. Minimal capability needed to access the bulk editor is now Editor. Thanks <a href="https://github.com/ethicalhack3r" target="_blank">Ryan Dewhurst</a> from WPScan for discovering and responsibly disclosing this issue.</p></blockquote>
<h3>Immediate Update Advised</h3>
<p>Users running the most recent version are advised to update immediately. If you&#8217;re using Jetpack on all your sites, you can quickly update them by visiting: <a href="https://wordpress.com/plugins/wordpress-seo" target="_blank">https://wordpress.com/plugins/wordpress-seo</a>. There you will see all the sites where you have the plugin installed and can update from your centralized dashboard.</p>
<p>Hosting companies are scrambling to add a fix to protect customers. The Pressable status blog sent out an <a href="http://status.pressable.com/2015/03/11/wordpress-seo-vulnerability/" target="_blank">advisory</a> on the vulnerability and is immediately updating installations where the plugin is active:</p>
<blockquote><p>Our systems have already begun updating this plugin across all impacted sites on our systems, and we expect this process to be completed shortly.</p></blockquote>
<p>SiteGround has added a <a href="https://www.siteground.com/blog/wordpress-seo-by-yoast-vulnerability/" target="_blank">temporary fix</a> to tide customers over in the meantime before they have the chance to update. The company added new security rules to its WAF (web application firewall), which will actively filter any possible incoming hacking attempts that try to exploit the vulnerability.</p>
<blockquote class="twitter-tweet" width="550"><p>Our security team has just added a fix to protect customers from a vulnerability in <a href="https://twitter.com/hashtag/WP?src=hash">#WP</a> SEO plugin by Yoast <a href="https://t.co/nP9qrJaO0x">https://t.co/nP9qrJaO0x</a></p>
<p>&mdash; SiteGround (@SiteGround) <a href="https://twitter.com/SiteGround/status/575701133550878720">March 11, 2015</a></p></blockquote>
<p></p>
<p><a href="https://wordpress.org/plugins/wordpress-seo/" target="_blank">WordPress SEO by Yoast</a> is active on more than one million websites. While many hosts are being proactive about getting plugin updates to customers, most of the plugin&#8217;s users will not be able to rely on their host to take care of the update. Keeping your site safe from the vulnerability is as easy as logging in and updating to the latest version.</p>
<p><em><strong>Update</strong></em> Joost de Valk <a title="https://yoast.com/wordpress-seo-security-release/" href="https://yoast.com/wordpress-seo-security-release/">published an update</a> discussing the vulnerabilities and what is fixed.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Mar 2015 18:13:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Akismet: Akismet 3.1 Plugin for WordPress Released";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1794";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://blog.akismet.com/2015/03/11/akismet-3-1-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1197:"<p>Version 3.1 of <a href="http://wordpress.org/plugins/akismet/">the Akismet plugin for WordPress</a> is now available.</p>
<p>As of version 3.1, all calls to the Akismet API are now made using SSL, increasing the confidentiality of your commenters&#8217; data as it travels over the wire.  Developers of other Akismet libraries are now free to use <code>https</code> URLs for Akismet API endpoints as well.</p>
<p>This update also includes a bugfix that prevents Akismet from inadvertently modifying a comment&#8217;s content during the spam filtering process.</p>
<p>To upgrade, visit the Updates page of your WordPress dashboard and follow the instructions. If you need to download the plugin zip file directly, links to all versions are available in <a href="http://wordpress.org/plugins/akismet/">the WordPress plugins directory</a>.</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1794/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1794/" /></a> <img alt="" border="0" src="http://pixel.wp.com/b.gif?host=blog.akismet.com&blog=116920&post=1794&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Mar 2015 17:00:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Christopher Finke";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Matt: Lessons from Jetpack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44701";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://ma.tt/2015/03/lessons-from-jetpack/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:375:"<blockquote><p>Personally I can say that it was the Jetpack features that helped provide the defaults that got me hooked on WordPress. If it weren’t for that, I wouldn’t be where I am today.</p></blockquote>
<p>Josh Pollock at Torque writes about <a href="http://torquemag.io/lessons-can-learn-jetpack-helped-wordpress-succeed/">Lessons we can learn from Jetpack</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Mar 2015 03:01:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: Mentionable Plugin Adds @mentions for WordPress Content with Inline Autocomplete";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=39424";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:99:"http://wptavern.com/mentionable-plugin-adds-mentions-for-wordpress-content-with-inline-autocomplete";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3037:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/01/links.jpg" rel="prettyphoto[39424]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/01/links.jpg?resize=1024%2C508" alt="photo credit: gordon2208 - cc" class="size-full wp-image-36986" /></a>photo credit: <a href="https://www.flickr.com/photos/gordon2208/4987669000/">gordon2208</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a>
<p>Finding and linking to previously published content on your site is a daily necessity for bloggers and content managers. Usually, you have to search the frontend of your site or search posts/pages in the admin to track down the content you&#8217;re trying to link.</p>
<p><a href="https://wordpress.org/plugins/mentionable/" target="_blank">Mentionable</a> is a handy tool, created by the folks at <a href="https://xwp.co/" target="_blank">XWP</a>, that saves a lot of time on internal linking. The plugin adds @mentions to the visual editor with autocomplete for any content published on the site, including posts, pages, media, and custom post types.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/mentionable.png" rel="prettyphoto[39424]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/mentionable.png?resize=843%2C438" alt="mentionable" class="aligncenter size-full wp-image-40405" /></a></p>
<p>Mentionable includes a settings panel for specifying the post types for which the plugin will be active. You can also select the post types that the auto-completion will match against. Users can further customize the plugin by replacing the mentionable tag with a custom <em>mentionable.php</em> template.</p>
<p>The support for custom post types means that users can call out recipes, books, movies, products, or posts from any registered content type as links within pages or posts. This makes it easy to link to the backstory for new content, put together quick reference lists, cross promote products, etc. &#8211; all without ever having to leave the post editor.</p>
<p>I tested the plugin and found that it works as advertised. When mentioning a post you don&#8217;t even have to start with the first word of the post title. The autocomplete will pick up any word found in a title, in case your memory of the exact title is foggy.</p>
<p>If you decide later on that you don&#8217;t want to use the plugin anymore, it won&#8217;t affect any of the links you created previously. Your content remains intact even after the plugin is deactivated and uninstalled.</p>
<p>A healthy amount of internal linking is often recommended for boosting your site&#8217;s SEO. According to Moz, <a href="http://moz.com/learn/seo/internal-link" target="_blank">internal links</a> are critical for establishing site architecture and spreading link juice. If you&#8217;re not in the habit of linking to your own content, the <a href="https://wordpress.org/plugins/mentionable/" target="_blank">Mentionable</a> plugin will help you do it with minimal effort.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Mar 2015 01:17:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WPTavern: Delicious Brains Publishes In-depth Guides on The WordPress Database";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40388";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://wptavern.com/delicious-brains-publishes-in-depth-guides-on-the-wordpress-database";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1896:"<p><a title="https://deliciousbrains.com/" href="https://deliciousbrains.com/">Delicious Brains</a>, the creators of <a title="https://wordpress.org/plugins/wp-migrate-db/" href="https://wordpress.org/plugins/wp-migrate-db/">WP Migrate DB</a>, <a title="https://deliciousbrains.com/tour-wordpress-database/" href="https://deliciousbrains.com/tour-wordpress-database/">published a guide</a> that walks developers through the WordPress database. The guide describes every database table and there associated columns within WordPress single site. It also features an <a title="http://codex.wordpress.org/Database_Description#Database_Diagram" href="http://codex.wordpress.org/Database_Description#Database_Diagram">entity relationship diagram</a> that explains the relationships between the various tables. Although the image was created for WordPress 3.8, it&#8217;s still accurate.</p>
<p>For those who want to learn the database structure of WordPress Multisite, check out their <a title="https://deliciousbrains.com/wordpress-multisite-database-tour/" href="https://deliciousbrains.com/wordpress-multisite-database-tour/">Multisite database tour</a> as there are some key database changes to take note of:</p>
<blockquote><p>When a WordPress site is <a href="http://codex.wordpress.org/Create_A_Network">converted to a Multisite install</a>, a “network” of subsites is created. The existing site is converted to the first subsite in the network. The database classes the network itself as a site (wp_site), and each subsite as a blog (wp_blogs).</p>
<p>Certain tables are used only by a subsite, and a new set of tables are created every time a site is added to the network. Each set of tables is differentiated by the blog_id for the subsite used in the table prefix. e.g. `wp_2_posts`.</p></blockquote>
<p>I encourage you to bookmark both guides as they&#8217;re excellent resources.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Mar 2015 21:58:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:116:"WPTavern: CodeGuard Survey Shows More Education is Needed on Backup Software, Services, and Strategies For WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40341";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:124:"http://wptavern.com/codeguard-survey-shows-more-education-is-needed-on-backup-software-services-and-strategies-for-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4426:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/CodeGuardSurveyResultsFeaturedImage.png" rel="prettyphoto[40341]"><img class="aligncenter size-large wp-image-40382" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/CodeGuardSurveyResultsFeaturedImage.png?resize=500%2C187" alt="CodeGuard Survey Results Featured Image" /></a></p>
<p><a title="https://www.codeguard.com/" href="https://www.codeguard.com/">CodeGuard</a>, a service that specializes in automated backups to the cloud, has published the results of its 2015 WordPress survey. The survey took place between February 18th-20th and was answered by 503 WordPress users. Backing up is an important part of maintaining a website, so it&#8217;s a bit shocking to see such high percentages of people who either don&#8217;t backup on a regular basis or who don&#8217;t think backup plans are important.</p>
<p>Out of 503 respondents:</p>
<ul>
<li>25% have received &#8220;very little training&#8221; in the use of WordPress</li>
<li>22% haven&#8217;t been trained at all in WordPress backup and have &#8220;no idea&#8221; how to do it</li>
<li>21% have seen the &#8220;white screen of death&#8221; multiple times, and &#8220;it&#8217;s horrible!&#8221;</li>
<li>69% have had a plugin fail after an update, and 24% have had it happen &#8220;many times&#8221;</li>
<li>63% have deleted files that were not backed up</li>
<li>22% said that a backup plugin seems &#8220;unimportant&#8221; to them</li>
<li>24% said &#8220;This site is my livelihood, I&#8217;d pay almost anything for a complete restore,&#8221; while 19% said they&#8217;d be willing to spend several thousand dollars, at least</li>
</ul>
<p>I&#8217;m surprised to see only 24% of respondents use a backup plugin at all considering there&#8217;s so many <a title="https://wordpress.org/plugins/search.php?q=backup" href="https://wordpress.org/plugins/search.php?q=backup">free options available</a>. There appears to be a correlation between those who have little to no WordPress training and the lack of education on how to establish a backup plan. I realize 503 WordPress users is not a large sample size, but the numbers indicate more education is needed on backup software, services, and strategies.</p>
<p>It&#8217;s also alarming to see 69% of respondents have had a plugin fail after an update and 24% of those have had it happen several times. This is further proof that WordPress is <a title="http://wptavern.com/its-time-for-wordpress-to-automatically-update-themes-plugins-and-core-by-default" href="http://wptavern.com/its-time-for-wordpress-to-automatically-update-themes-plugins-and-core-by-default">not ready to automatically update plugins</a> by default.</p>
<p>An important data point missing from the survey is how many of the respondents rely on automatic backups provided by their webhost. Not every user needs a plugin to manage backups and for a number of managed WordPress hosting companies, automatic backups are part of the package. In fact, most managed WordPress hosting providers discourage and disallow backup plugins from being used. An <a title="http://wpengine.com/support/disallowed-plugins/" href="http://wpengine.com/support/disallowed-plugins/">example is WP Engine</a>:</p>
<blockquote><p>In general, however, we discourage the use of backup plugins. They needlessly duplicate our built-in functionality, rely on a large amount of local storage and can store files in an insecure manner. Not only that, many of these plugins run their backup jobs at inopportune times. This can slow database connectivity with extra — and sometimes very large — MySQL queries and cause timeouts on larger sites.</p></blockquote>
<p>This infographic provided by CodeGuard visually shows the survey&#8217;s results. When browsing, I suggest replacing <em>WordPress users</em> with <em>respondents</em> as WordPress users sounds too broad. After reviewing the data, let me know if the results surprise you or if it corresponds to what you&#8217;re experiencing with clients.</p>
<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/CodeGuardInfographic.png" rel="prettyphoto[40341]"><img class="wp-image-40371 size-full" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/CodeGuardInfographic.png?resize=1025%2C4879" alt="CodeGuard Infographic Showing Survey Results" /></a>CodeGuard Infographic Showing Survey Results
<p>&nbsp;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Mar 2015 19:49:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"WPTavern: WordPress Antispam Bee Plugin Adds Option to Trust Commenters with a Gravatar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40344";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wptavern.com/wordpress-antispam-bee-plugin-adds-option-to-trust-commenters-with-a-gravatar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4082:"<a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/bee.jpg" rel="prettyphoto[40344]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/bee.jpg?resize=1025%2C467" alt="photo credit: Osmia pumila, M, Face, MD_2013-06-25.18.39.16 ZS PMax - (license)" class="size-full wp-image-40353" /></a>photo credit: <a href="http://www.flickr.com/photos/54563451@N08/9302552275">Osmia pumila, M, Face, MD_2013-06-25.18.39.16 ZS PMax</a> &#8211; <a href="https://creativecommons.org/licenses/by/2.0/">(license)</a>
<p>Version 2.6.5 of the popular <a href="https://wordpress.org/plugins/antispam-bee/" target="_blank">Antispam Bee</a> plugin is out today with a new feature that allows administrators to trust commenters with a <a href="https://en.gravatar.com/" target="_blank">Gravatar</a>. The idea for the function was suggested by Caspar Hübinger, a long-time user of the plugin.</p>
<p>&#8220;Have you ever seen a spam comment with a Gravatar image?  I haven’t,&#8221; Hübinger said in a <a href="http://glueckpress.com/6500/trust-the-gravatar/" target="_blank">post</a> introducing the new feature. &#8220;So I suggested to include an option in Antispam Bee to trust commenters with a Gravatar by default, and Sergej, creator of Antispam Bee, was kind enough to implement it.&#8221;</p>
<p>Although the plugin was mentioned by Matt Mullenweg during his Q&amp;A at WordCamp Europe 2014, English speakers have largely overlooked it in the past. Antispam Bee was created by German WordPress plugin developer <a href="http://wpcoder.de/" target="_blank">Sergej Müller</a> and its description page on WordPress.org is written in German. He has actively developed and maintained the plugin since 2009. It is currently used on 200,000+ installations of WordPress.</p>
<p>One might think that it would make sense to include an English copy of the description to gain a larger user base, but Müller elected to keep it in German due to the plugin&#8217;s incompatibilities. Antispam Bee is incompatible with many of the major commenting systems used by English speakers, including Disqus, Jetpack Comments, and AJAX Comment Form.</p>
<p>English speakers who use <a href="http://jetpack.me/support/comments/" target="_blank">Jetpack Comments</a> often use <a href="http://akismet.com/" target="_blank">Akismet</a>, since the two work together seamlessly. Akismet is far more well-known, since it comes packaged with WordPress by default. However, Antispam Bee has a solid set of features that make it a decent alternative:</p>
<ul>
<li>Ad-free</li>
<li>No storage of personal data</li>
<li>No registration required</li>
<li>Free for commercial projects</li>
<li>No adjustment required by theme templates</li>
<li>All functions can be controlled by the user</li>
<li>Statistics for the last 30 days displayed as a dashboard widget</li>
<li>Supports six languages: German, English, French, Russian, Dutch, and Slovenian</li>
</ul>
<p>The plugin also comes with 20 configurable options for customizing its spam-blocking features, including the ability to disable spam email notifications, block comments from certain countries, allow comments only in certain languages, delete after X days, and much more. These options allow you to tailor your anti-spam shield to lessen your moderation load.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/antispam-bee.jpg" rel="prettyphoto[40344]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/antispam-bee.jpg?resize=1025%2C714" alt="antispam-bee" class="aligncenter size-full wp-image-40377" /></a></p>
<p>If you&#8217;re intrigued by <a href="https://wordpress.org/plugins/antispam-bee/" target="_blank">Antispam Bee</a>&#8216;s latest feature that allows you to trust commenters who have a Gravatar, give the plugin a try the next time you&#8217;re reviewing spam-blocking solutions. The option is a creative use of WordPress&#8217; built-in support for Gravatar. Current users of the plugin can find the new setting in the admin under <strong>Settings > Antispam Bee</strong>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Mar 2015 19:06:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"WPTavern: WPupdatePHP Project Aims to Help WordPress Users Get on Newer Versions of PHP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40303";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wptavern.com/wpupdatephp-project-aims-to-help-wordpress-users-get-on-newer-versions-of-php";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4470:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/php.jpg" rel="prettyphoto[40303]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/php.jpg?resize=700%2C329" alt="photo credit: Feediza.com" class="size-full wp-image-40331" /></a>photo credit: <a href="http://feediza.com/">Feediza.com</a>
<p>Developers are anxious for WordPress to bump up the minimum PHP requirement for core, as it&#8217;s currently lingering at 5.2, which is no longer among the <a href="http://php.net/supported-versions.php" target="_blank">supported versions of PHP</a>. As of August 2014, PHP 5.3 no longer receives patches for security vulnerabilities.</p>
<p><a href="http://wptavern.com/wordpress-version-stats-updated-more-than-13-of-sites-are-running-wordpress-4-1" target="_blank">Recent updates to WordPress.org stats</a> indicate that 16.4% of WordPress sites are still running on PHP 5.2 and 38% on PHP 5.3. According to lead developer Andrew Nacin, bumping the minimum required version is not likely to happen soon, due to the sheer number of sites that would be negatively impacted.</p>
<p>&#8220;One-sixth of all sites running PHP 5.2 is still many millions of sites,&#8221; he said. &#8220;If we move the PHP minimum version too early, we risk stranding millions of installs on older versions of WordPress.&#8221; In the meantime, the WordPress project is researching the current state of PHP offerings available at popular hosts and will soon be urging them to update to more recent versions.</p>
<p>WordPress developer <a href="http://coenjacobs.me/" target="_blank">Coen Jacobs</a> believes that the effort to contact hosts will not be enough to help everyone. His new <a href="http://www.wpupdatephp.com/" target="_blank">WPupdatePHP</a> project was created to educate end users on outdated versions of PHP. The <a href="https://github.com/WPupdatePHP/wp-update-php" target="_blank">WPupdatePHP library</a> is a tool that developers can bundle into their plugins in order to require users to upgrade to PHP 5.4+ hosting. It is intended for use within new plugins, not for locking users out of existing ones.</p>
<p>If a user does not meet the minimum PHP version requirements when installing the plugin, he will be presented with an admin notice:</p>
<blockquote><p>Unfortunately, this plugin can not run on PHP versions older than [ specified version ]. Read more information about <a href="http://www.wpupdatephp.com/update/">how you can update</a>.</p></blockquote>
<p>The idea of the WPupdatePHP project is to enlist end users in putting pressure on hosts to <a href="http://www.wpupdatephp.com/update/" target="_blank">update their versions of PHP</a>. A future version of the library would add the ability for developers to make the PHP version a “soft requirement,” which would still display the notice but won’t stop the user from using the plugin.</p>
<p>&#8220;The core WordPress team can’t get every single hosting company to comply,&#8221; Jacobs said in a recent post titled <em><a href="http://coenjacobs.me/updating-php-everyones-responsibility/" target="_blank">Updating PHP is Everyone’s Responsibility</a></em>. &#8220;I admire their intentions, but in reality this is not going to help everybody.&#8221;</p>
<p>He predicts a need for the WPupdatePHP library even after WordPress bumps its minimum required PHP version. &#8220;PHP 5.4 is actually already nearing its EOL date and we’re still figuring out how to make PHP 5.2 and 5.3 platforms go away,&#8221; he said. In mid-September 2015, PHP 5.4 will not longer receive security fixes.</p>
<p>Jacobs believes that the changes that need to happen require more than a one-time campaign where the WordPress project successfully badgers hosts to update to PHP 5.4.</p>
<p>&#8220;In six months we’ll have this same issue all over again,&#8221; he said. &#8220;As soon as webhosting companies have finally finished off their PHP 5.2 and 5.3 environments, we can start this whole campaign all over again to get rid of PHP 5.4. And so on.&#8221;</p>
<p>If you are a WordPress developer interested in enlisting your plugin&#8217;s users to help push hosts to update PHP versions, check out <a href="https://github.com/WPupdatePHP/wp-update-php" target="_blank">WPupdatePHP on GitHub</a>.</p>
<p>&#8220;The end user is one of our most important, but underestimated, assets in this battle,&#8221; Jacobs said. &#8220;They have the strongest voice in this all.&#8221;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Mar 2015 22:24:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WPTavern: WordPress.com Adds oEmbed Support For CartoDB Maps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40265";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wptavern.com/wordpress-com-adds-oembed-support-for-cartodb-maps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1371:"<p>WordPress.com <a title="https://en.support.wordpress.com/cartodb-embeds/" href="https://en.support.wordpress.com/cartodb-embeds/">now supports oEmbeds</a> for<a title="http://cartodb.com/" href="http://cartodb.com/"> CartoDB,</a> a tool used to create and share interactive maps. Simply copy and paste a CartoDB map URL into the WordPress.com post editor and a live preview will display. Here&#8217;s an example of a map using the standard HTML embed code.</p>
<p></p>
<p>According to an announcement on the <a title="http://blog.cartodb.com/wordpress/" href="http://blog.cartodb.com/wordpress/">official CartoDB blog</a>, embed support has also been added to Jetpack. However, I discovered after testing that it&#8217;s not yet supported. I reached out to Jetpack&#8217;s development team to find out when it will be added, but they&#8217;re <a title="https://wordpress.org/support/topic/jetpack-staff-will-be-unavailable-until-march-16th" href="https://wordpress.org/support/topic/jetpack-staff-will-be-unavailable-until-march-16th">not available</a> until March 16th.</p>
<p>With more than 60 million users, CartoDB has an incredible opportunity to expand its reach by being accessible on a platform where over <a title="https://wordpress.com/activity/" href="https://wordpress.com/activity/">409 million people</a> view more than 17.6 billion pages each month.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Mar 2015 20:13:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:96:"WPTavern: Lovecraft: New Free WordPress Theme Combines Prominent Imagery with Strong Serif Fonts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40251";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:105:"http://wptavern.com/lovecraft-new-free-wordpress-theme-combines-prominent-imagery-with-strong-serif-fonts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3402:"<p>WordPress theme author <a href="http://www.andersnoren.se/" target="_blank">Anders Norén</a> is back to releasing themes after a brief hiatus over the winder holidays. <a href="https://wordpress.org/themes/lovecraft/" target="_blank">Lovecraft</a>, is his 10th theme to be approved on WordPress.org.</p>
<p>The Lovecraft design was inspired by the work of <a href="http://en.wikipedia.org/wiki/H._P._Lovecraft" target="_blank">H.P. Lovecraft</a>, an American horror fiction author known for his &#8220;weird realism&#8221; &#8211; the idea that reality is fundamentally weird and the human mind is incapable of realistically representing it.</p>
<p>Norén&#8217;s tribute to Lovecraft&#8217;s work is conveyed most clearly through the serif-heavy typography of the theme and a strong focus on the imagery assigned to each post. He selected Google Font&#8217;s <a href="http://www.google.com/fonts/specimen/Playfair+Display" target="_blank">Playfair Display</a> for page and post headers, accompanied by Georgia for the body text. The bright red links and red post meta complement the design&#8217;s literary theme.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/lovecraft.png" rel="prettyphoto[40251]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/lovecraft.png?resize=880%2C660" alt="lovecraft" class="aligncenter size-full wp-image-40267" /></a></p>
<p>The homepage showcases a full-width header image and each post replaces that image with its own featured image. These images, along with the rest of the theme, gracefully scale down for smaller devices.</p>
<p>Lovecraft, like many other recently released themes, adds additional features by offering support for <a href="http://jetpack.me/" target="_blank">Jetpack</a>, including the infinite scroll module and styles for tiled galleries.</p>
<p>Norén took every small detail into consideration when creating Lovecraft, as you can see with the blockquotes design, ordered lists, post media, and form styles on the <a href="http://andersnoren.se/themes/lovecraft/style-guide/" target="_blank">Style Guide</a> page.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/lovecraft-blockquote.jpg" rel="prettyphoto[40251]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/lovecraft-blockquote.jpg?resize=617%2C217" alt="lovecraft-blockquote" class="aligncenter size-full wp-image-40283" /></a></p>
<p>The theme allows you to select the accent color via the customizer. It also includes support for a custom logo, editor styles, and matching widgets for Flicker, recent posts, and recent comments with thumbnails. Pages have an additional template for full-width display. Check out the <a href="http://andersnoren.se/themes/lovecraft/" target="_blank">live demo</a> to see Lovecraft in action.</p>
<p>If you&#8217;re looking for a bold new theme for your blog and you appreciate strong serif fonts, Lovecraft is a thoughtfully-designed option. The theme is <a href="http://www.wordpress.org/themes/lovecraft" target="_blank">available for free</a> in the WordPress Theme Directory as of today. For more information on how Anders Norén finds continual inspiration for his free themes, check out our recent <a href="http://wptavern.com/a-chat-with-anders-noren-on-finding-inspiration-for-wordpress-theme-design" target="_blank">interview</a> with the designer.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Mar 2015 18:54:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Matt: NNT of Medicine";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44289";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:37:"http://ma.tt/2015/03/ntt-of-medicine/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:643:"<p><a href="http://www.wired.com/2014/10/number-needed-to-treat/">This Man&#8217;s Simple System Could Transform American Medicine</a>, about a quest to quantify the effects of medicine and treatment differently, which is really needed.</p>
<p>Update: Looks like it&#8217;s built on WordPress, too:</p>
<blockquote class="twitter-tweet" width="550"><p>.<a href="https://twitter.com/photomatt">@photomatt</a> Thanks for the link! I built the site with Dave Newman (powered by WordPress)!</p>
<p>&mdash; Graham Walker (@grahamwalker) <a href="https://twitter.com/grahamwalker/status/575069240140656641">March 9, 2015</a></p></blockquote>
<p></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Mar 2015 18:47:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: bbPress 2.5.5 Released, Patches Three Potential Security Vulnerabilities";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40253";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://wptavern.com/bbpress-2-5-5-released-patches-three-potential-security-vulnerabilities";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:907:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/bbpress.png" rel="prettyphoto[40253]"><img class="aligncenter size-full wp-image-24338" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/06/bbpress.png?resize=1025%2C378" alt="bbpress" /></a></p>
<p>bbPress 2.5.5 is <a title="https://bbpress.org/blog/2015/03/bbpress-2-5-5-security-release/" href="https://bbpress.org/blog/2015/03/bbpress-2-5-5-security-release/">available for download</a>. This release fixes three potential security vulnerabilities reported by <a title="https://profiles.wordpress.org/jdgrimes" href="https://profiles.wordpress.org/jdgrimes">J.D. Grimes</a> and was pushed out within nearly 24 hours of being notified. Users should update as soon as possible as all previous 2.x versions are vulnerable. The patches have also been applied to the 2.6 development branch that will soon have a beta release.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Mar 2015 17:24:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Matt: 25k DMCA Win";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44791";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:34:"http://ma.tt/2015/03/25k-dmca-win/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:566:"<blockquote><p>WordPress [actually Automattic] has scored an important victory in court against a man who abused the DMCA to censor an article of a critical journalist. The court agreed that the takedown request was illegitimate and awarded WordPress roughly $25,000 in damages and attorneys fees.</p></blockquote>
<p>Yes! Good laws become bad when people abuse them. Here&#8217;s the source: <a href="http://torrentfreak.com/wordpress-wins-25000-from-dmca-takedown-abuser-150305/">WordPress Wins $25,000 From DMCA Takedown Abuser</a> (s/WordPress/Automattic/).</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 08 Mar 2015 17:55:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"Matt: Psychology of a Small Playlist";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44757";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://ma.tt/2015/03/psychology-of-a-small-playlist/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:240:"<p>Joseph Mosby experiments with my trick of listening to a song on repeat to get work done, <a href="http://josephmosby.com/2015/02/15/the-psychology-of-a-small-playlist-on-repeat.html">and digs a bit into the psychology behind it</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 08 Mar 2015 07:10:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WPTavern: Automattic and Oliver Hotham Win Court Battle Against DMCA Takedown Abuser";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40222";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:94:"http://wptavern.com/automattic-and-oliver-hotham-win-court-battle-against-dmca-takedown-abuser";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3721:"<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/AutomatticCourtFeaturedImage.png" rel="prettyphoto[40222]"><img class="size-full wp-image-40224" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/AutomatticCourtFeaturedImage.png?resize=642%2C299" alt="Automattic Court Featured Image" /></a>photo credit: <a href="http://www.flickr.com/photos/46274125@N00/1558886731">Former Supreme Court, Singapore</a> &#8211; <a href="https://creativecommons.org/licenses/by/2.0/">(license)</a>
<p>In August of 2013, <a title="http://www.theguardian.com/technology/2013/aug/13/wordpress-straight-pride-uk" href="http://www.theguardian.com/technology/2013/aug/13/wordpress-straight-pride-uk">Automattic was criticized</a> for its role in taking down <a title="https://oliverhotham.wordpress.com/2013/08/11/the-sordid-tale-of-how-i-was-censored-by-straight-pride-uk/" href="https://oliverhotham.wordpress.com/2013/08/11/the-sordid-tale-of-how-i-was-censored-by-straight-pride-uk/">Oliver Hotham&#8217;s website</a> after the Straight Pride UK group filed a DMCA takedown notice with WordPress.com. In the Guardian article, WordPress.com admitted that the takedown notice was an abuse of the law. In November of 2013, <a title="http://en.blog.wordpress.com/2013/11/21/striking-back-against-censorship/" href="http://en.blog.wordpress.com/2013/11/21/striking-back-against-censorship/">Automattic announced</a> that it teamed up with Hotham in <a title="http://en.blog.files.wordpress.com/2013/11/2013-11-21-final-hotham-complaint.pdf" href="http://en.blog.files.wordpress.com/2013/11/2013-11-21-final-hotham-complaint.pdf">two</a> separate <a title="http://en.blog.files.wordpress.com/2013/11/2013-11-21-final-retraction-watch-complaint.pdf" href="http://en.blog.files.wordpress.com/2013/11/2013-11-21-final-retraction-watch-complaint.pdf">lawsuits</a>.</p>
<p>The lawsuits were filed in federal court under Section 512(f) of the DMCA. Section 512(f) is the provision that allows users to hold people accountable when they make false infringement accusations.</p>
<p>Torrentfreak reports that <a title="http://torrentfreak.com/wordpress-wins-25000-from-dmca-takedown-abuser-150305/" href="http://torrentfreak.com/wordpress-wins-25000-from-dmca-takedown-abuser-150305/">Automattic has won the case</a> with a $25K settlement. According to court documents, United States Magistrate Judge Joseph Spero <a title="http://ia601008.us.archive.org/20/items/gov.uscourts.cand.272130/gov.uscourts.cand.272130.31.0.pdf" href="http://ia601008.us.archive.org/20/items/gov.uscourts.cand.272130/gov.uscourts.cand.272130.31.0.pdf">wrote a report</a> and recommendation in favor of Automattic and Hotham. The <a title="http://torrentfreak.com/images/wp-steiner.pdf" href="http://torrentfreak.com/images/wp-steiner.pdf">courts agreed with his report</a> and recommendation. Since the defendant chose to default, the courts saw no reason to require further expenditure of resources and awarded the victory to Automattic.</p>
<p>The settlement is split between three parties: Automattic&#8217;s employee time, attorneys, and Hotham.</p>
<blockquote><p>It is Ordered and Adjudged that defendant Nick Steiner pay damages in the amount of $960.00 for Hotham’s work and time, $1,860.00 for time spent by Automattic’s employees, and $22,264.00 for Automattic’s attorney’s fees, for a total award of $25,084.00.</p></blockquote>
<p>There are two things I take away from the victory. First, it sets a precedent that Automattic can and will fight against those who abuse the <a title="http://automattic.com/dmca-notice/" href="http://automattic.com/dmca-notice/">DMCA takedown procedure</a>. Second, attorneys are expensive.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 07 Mar 2015 04:44:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Matt: Standalone Cameras";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44780";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://ma.tt/2015/03/standalone-cameras/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:172:"<p>Om Malik on the decline of cameras as gadgets, <a href="http://om.co/2015/03/06/standalone-camera-shot-dead-by-iphone/">Standalone camera: Shot (Dead) By iPhone</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 07 Mar 2015 02:08:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WPTavern: New Plugin Adds Openname Avatars to WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=39992";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://wptavern.com/new-plugin-adds-openname-avatars-to-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4497:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/openname.jpg" rel="prettyphoto[39992]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/openname.jpg?resize=720%2C299" alt="openname" class="aligncenter size-full wp-image-40208" /></a></p>
<p>In November 2014, Onename <a href="http://blog.onename.io/decentralized-auth-identity-open-source/" target="_blank">announced</a> that it would be extending its Openname protocol to support decentralized authentication. The company also <a href="https://github.com/openname" target="_blank">open sourced the protocol and directory software</a> so that developers can build their own infrastructure with it.</p>
<blockquote><p>We believe the future of identity will be decentralized, and for any identity system to be truly decentralized, no entity can have a monopoly over registering users or displaying their profiles. Anyone should be able to claim a username and fill out their profiles either using a provider/registrar of their choice or on their own without any third party.</p></blockquote>
<p>The <a href="https://openname.org/" target="_blank">Openname</a> decentralized identity and naming system is built on the Blockchain. It makes it possible for anyone to create an online identity, which can then be used to make Bitcoin transactions. The company&#8217;s long-term goal is to pioneer a decentralized authentication protocol:</p>
<blockquote><p>What we need is a password-less authentication process that doesn&#8217;t require any particular third party; an open, decentralized auth protocol that lets users conveniently sign in and be in control of the data they release to apps and where they store it.</p>
<p>Openname Auth is our work-in-progress proposal for decentralized, password-less authentication in which users login by simply entering a username (their openname) and approving an auth request on their desktop or mobile device.</p></blockquote>
<p>OneName <a href="http://venturebeat.com/2014/11/14/y-combinator-backed-onename-raises-1-5m-open-sources-its-bitcoin-identity-directory/" target="_blank">raised $1.5 million in funding</a> to continue developing the platform as part of its quest to <a href="http://blog.onename.io/evolution-of-the-internet/" target="_blank">return the web to its decentralized roots</a>.</p>
<h3>Openname Avatars for WordPress</h3>
<p>WordPress core supports <a href="https://en.gravatar.com/" target="_blank">Gravatar</a> by default for providing blog and comment author avatars. Thanks to the new <a href="https://wordpress.org/plugins/openname/" target="_blank">Opennname plugin for WordPress</a>, site administrators can now offer users the option to associate a Openname avatars with an account on self-hosted sites.</p>
<p>In order to test the plugin, you&#8217;ll need to first sign up for an <a href="https://openname.org/" target="_blank">Openname</a> account (which requires an account at Onename or Namecoin).</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/openname-profile.jpg" rel="prettyphoto[39992]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/openname-profile.jpg?resize=1025%2C307" alt="openname-profile" class="aligncenter size-full wp-image-40190" /></a></p>
<p>After you install the Openname plugin on your WordPress site, any registered user will be able to elect to use his Openname avatar by visiting /wp-admin/profile.php. Once you add your Openname, the plugin will keep your WordPress avatar in sync (with a short delay) with your Openname Avatar.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/openname-settings.jpg" rel="prettyphoto[39992]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/openname-settings.jpg?resize=720%2C264" alt="openname-settings" class="aligncenter size-full wp-image-40191" /></a></p>
<p>The Openname plugin was created by <a href="https://www.larrysalibra.com/" target="_blank">Larry Salibra</a>, founder and CEO of <a href="https://www.pay4bugs.com/" target="_blank">Pay4Bugs</a>. I tested it and found it to work as advertised.</p>
<p>In the future, once the Openname Auth is more developed, it would be awesome if Salibra added this to his WordPress plugin. Onename might do well to create its own official plugin for this. Given that WordPress currently powers 23% of the world&#8217;s websites, an official Openname authentication plugin might bring wider adoption for its decentralized identity system.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Mar 2015 23:30:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"WPTavern: WordPress Publishes Security White Paper";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40096";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wptavern.com/wordpress-publishes-security-white-paper";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3694:"<a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/security.jpg" rel="prettyphoto[40096]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/security.jpg?resize=1024%2C514" alt="photo credit: Lock - (license)" class="size-full wp-image-40187" /></a>photo credit: <a href="http://www.flickr.com/photos/58441544@N00/2660230441">Lock</a> &#8211; <a href="https://creativecommons.org/licenses/by/2.0/">(license)</a>
<p>As WordPress currently powers 23% of the web, the platform&#8217;s security is constantly under scrutiny. WordPress has long been a favorite target of hackers and spammers who want to get the most return on their efforts. Since the the platform powers millions of websites, a critical vulnerability with a popular plugin or WordPress core can affect a large chunk of the web in a short amount of time.</p>
<p>WordPress published a <a href="https://wordpress.org/about/security/" target="_blank">security white paper</a> this week to help the public learn more about the core software security. Many consultants have had the experience of clients who are considering WordPress but are wondering if it&#8217;s secure. This document was created both for decision makers who are evaluating WordPress and developers who are building on top of the software.</p>
<p>The document is available as a <a href="https://github.com/WordPress/Security-White-Paper/blob/master/WordPressSecurityWhitePaper.pdf?raw=true" target="_blank">PDF</a>, and here&#8217;s what you&#8217;ll find inside:</p>
<blockquote><p>This document is an analysis and explanation of the WordPress core software development and its related security processes, as well as an examination of the inherent security built directly into the software.</p></blockquote>
<p>The white paper gives an introduction to the core leadership team, the WordPress Security Team, how a release cycle works, and responsible disclosure of vulnerabilities. The second half of the document covers common security vulnerabilities and how WordPress protects itself against those potential risks.</p>
<p>Just like WordPress itself, the security white paper is open to contribution. Anyone can submit a pull request on the <a href="https://github.com/WordPress/Security-White-Paper" target="_blank">WordPress repository</a>.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/wordpress-security-whitepaper.png" rel="prettyphoto[40096]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/wordpress-security-whitepaper.png?resize=1025%2C753" alt="wordpress-security-whitepaper" class="aligncenter size-full wp-image-40178" /></a></p>
<p>The security white paper is in need of translations in order to be more accessible to WordPress&#8217; global audience. If you can assist with a particular translation, the repository has simple instructions for how to submit it on GitHub.</p>
<blockquote><p>To translate the white paper, please create a sub-directory of the project, giving it the correct ISO639 code (for example, pt for Portuguese), and submit a pull request.</p></blockquote>
<p>WordPress consultants will find this white paper to be an excellent resource to refer to during sales negotiations. If you&#8217;re a developer just getting started learning about WordPress&#8217; inherent security, the document is provides a solid overview.</p>
<p>Hackers who are looking to receive bounty for finding security vulnerabilities can find <a href="https://hackerone.com/automattic" target="_blank">Automattic on HackerOne</a>. The company regularly rewards hackers with bounty for security bugs discovered with WordPress.com, which is powered by the core WordPress software.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Mar 2015 20:11:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"WPTavern: Version One of The WordPress History Book is Ready For Review";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40148";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://wptavern.com/version-one-of-the-wordpress-history-book-is-ready-for-review";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4283:"<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/WordPressHistoryBookFeaturedImage.png" rel="prettyphoto[40148]"><img class="aligncenter size-full wp-image-40153" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2015/03/WordPressHistoryBookFeaturedImage.png?resize=657%2C231" alt="WordPress History Book Featured Image" /></a></p>
<p>During the <a title="http://wordpress.tv/2013/07/29/matt-mullenweg-state-of-the-word-2013/" href="http://wordpress.tv/2013/07/29/matt-mullenweg-state-of-the-word-2013/">2013 State of the Word</a> presentation at WordCamp San Francisco, Matt Mullenweg announced a new project called <a title="https://github.com/WordPress/book" href="https://github.com/WordPress/book">WordPress The Book</a>. After nearly two years of writing, Siobhan McKeown <a title="https://twitter.com/SiobhanPMcKeown/status/573544639170478081" href="https://twitter.com/SiobhanPMcKeown/status/573544639170478081">has announced</a> that version one is ready for review. She also states that the book will be produced in just over a month and that now&#8217;s the time to give feedback.</p>
<blockquote class="twitter-tweet" width="550"><p>Finished V1 of the WordPress book: <a href="https://t.co/MC59LjeyFH">https://t.co/MC59LjeyFH</a> We\'ll be producing it in just over a month so if you have feedback now\'s the time</p>
<p>&mdash; Siobhan McKeown (@SiobhanPMcKeown) <a href="https://twitter.com/SiobhanPMcKeown/status/573544639170478081">March 5, 2015</a></p></blockquote>
<p></p>
<p>While you can download the book, I recommend browsing and reading it on Github so you don&#8217;t have to worry about opening files with the .MD extension. It&#8217;s also easier to submit pull requests to correct typos or grammatical errors. The book is <a title="https://github.com/WordPress/book/tree/master/Content" href="https://github.com/WordPress/book/tree/master/Content">divided into six parts</a> that contain a few chapters each.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/WordPressBookChapters.png" rel="prettyphoto[40148]"><img class="size-full wp-image-40152" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/WordPressBookChapters.png?resize=1025%2C432" alt="Chapters Of The WordPress History Book" /></a>Chapters Of The WordPress History Book
<p>If you come across any errors while reading the book, you can submit corrections by creating a pull request or an issue on the tracker. Here are a few things to look out for as you read:</p>
<ul>
<li>Factual errors: notes about factual errors are welcome. All suggestions for changes should be evidenced with links that back up any claims. Any facts that cannot be corroborated will not be included.</li>
<li>Clarity: any paragraphs or sections that you feel are not clear. This would be of particular help in sections that are technical in nature.</li>
<li>Omissions: anything that you feel has been omitted or not sufficiently covered. Note that this is a lengthy piece of writing and many issues have to be condensed to ensure that it is a manageable and interesting read. Suggestions about omissions should be accompanied with information about why it should be included, and backed up with evidence as to their importance.</li>
<li>Images: if you have any images that you feel would complement the text, we&#8217;d love to have them.</li>
</ul>
<p>McKeown is also looking for help writing haikus. Ideally, she&#8217;d like one for the book&#8217;s opening and one for each section. It will be published in two forms, a digital edition for the web and an e-book. McKeown also hinted at the possibility of printing physical copies, &#8220;We&#8217;re investigating different print options, so the feasibility of doing a print run or of offering print on demand.&#8221;</p>
<p>I&#8217;ve read a few chapters of the book already and it&#8217;s like a trip down memory lane. It&#8217;s interesting to read some of the historical moments of the project&#8217;s history, especially the years of GPL debates. Whether you&#8217;re brand new to WordPress and want to learn its history or you&#8217;re a veteran who needs a refresher, this book delivers. Please help McKeown by proofreading the first version and help make it the best WordPress history book possible.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Mar 2015 17:00:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"Dougal Campbell: WordPress › About » Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"http://dougal.gunters.org/?p=80603";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://dougal.gunters.org/blog/2015/03/06/wordpress-about-security/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1059:"<p><i>&#8220;This document is an analysis and explanation of the WordPress core software development and its related security processes, as well as an examination of the inherent security built directly into the software. Decision makers evaluating WordPress as a content management system or web application framework should use this document in their analysis and decition-making, and for developers to refer to it to familiarize themselves with the security components and best practices of the software.&#8221;</i></p>
<p><a href="https://wordpress.org/about/security/">WordPress › About » Security</a></p>
<p>Original Article: <a rel="nofollow" href="http://dougal.gunters.org/blog/2015/03/06/wordpress-about-security/">WordPress › About » Security</a><br />
<a rel="nofollow" href="http://dougal.gunters.org">Dougal Campbell&#039;s geek ramblings - WordPress, web development, and world domination.</a></p>
<div class="yarpp-related-rss yarpp-related-none">
<img src="http://yarpp.org/pixels/5db43ee24c4f1e1d0e45d08cc91b0130" alt="YARPP" />
</div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Mar 2015 15:36:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Dougal Campbell";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WPTavern: Insight Into WordPress Communities Around The World";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40138";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wptavern.com/insight-into-wordpress-communities-around-the-world";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3508:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/KinstaWordPressCommunitiesFeaturedImage.png" rel="prettyphoto[40138]"><img class="aligncenter size-full wp-image-40141" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/KinstaWordPressCommunitiesFeaturedImage.png?resize=727%2C338" alt="KInsta WordPress Communities Featured Image" /></a></p>
<p>One of the greatest things about WordPress is its diverse community throughout the world. <a title="https://kinsta.com/" href="https://kinsta.com/">Kinsta</a> has published a <a title="https://kinsta.com/learn/wordpress-communities-around-the-world/" href="https://kinsta.com/learn/wordpress-communities-around-the-world/">fantastic and inspirational post</a> that looks at up and coming WordPress communities in 5 continents and 17 countries.</p>
<p>My favorite story is Juanfra Aldasoro, co-organizer of WordCamp Buenos Aires, describing how the WordPress community in Argentina was organized. In 2007, Buenos Aires hosted the first WordCamp outside the US. Despite hosting a few more WordCamps, the community lacked organization. Aldasoro explains how celebrating WordPress&#8217; 10th anniversary brought the right group of people together:</p>
<blockquote><p>When WordPress turned 10, in May of 2013, thanks to a banner in the Codex site we created a celebration meetup. More than 20 people showed up, and the good thing was that we were a bunch of geeks on the same track. We had the people but we were lacking an organization. The ones interested in having an organized community kept in touch, we formed WordPress Argentina (<a href="https://twitter.com/wpargentina" target="_blank">@wpargentina</a>) and during 2014 we started to hold more formal monthly meetups.</p></blockquote>
<p>One of the things I noticed is that several of the people <a title="https://kinsta.com/learn/wordpress-communities-around-the-world/" href="https://kinsta.com/learn/wordpress-communities-around-the-world/">featured in the article</a> use Facebook groups for communication. Although a number of US based WordPress meetups use <a title="http://www.meetup.com/" href="http://www.meetup.com/">Meetup.com</a>, in other countries, Facebook appears to be the dominant way to communicate and organize members.</p>
<p>Meetups are grassroots efforts that help WordPress reach every corner of the globe. As Matt Mullenweg said during his 2014 <a title="http://wordpress.tv/2014/10/26/matt-mullenweg-the-state-of-the-word-2014/" href="http://wordpress.tv/2014/10/26/matt-mullenweg-the-state-of-the-word-2014/">State of The Word presentation</a>, &#8220;Organizing a meetup is one of the hardest things to do in terms of contributing to WordPress. Every single month, you have to come up with new stuff.&#8221; Those who help maintain community as a pillar of WordPress&#8217; success are helping to maintain its growth and popularity.</p>
<p>It&#8217;s exciting to think about the enormous amount of WordPress education, contributions, and learning that takes place across the world everyday, thanks in large part to people like those featured in the article. It&#8217;s wonderful to see so many WordPress communities around the world growing in size to the point of  having their own WordCamps.</p>
<p>If you&#8217;re having trouble organizing a WordPress meetup in your area, let us know in the comments. Thousands of people across the world access the Tavern on a daily basis and we might be able to help connect you to others in your area.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Mar 2015 05:16:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Matt: Kanye on Color";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44745";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:36:"http://ma.tt/2015/03/kanye-on-color/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:955:"<p><a href="http://ma.tt/2015/03/pink-and-blue/">Speaking of color masculinity</a>, here&#8217;s Kanye on creativity, society, and color from <a href="http://www.thefader.com/2012/11/29/kanye-west-im-amazing">his 2008 FADER interview</a>:</p>
<blockquote><p>I feel like all the words are in you, you’re just blocking yourself, you’re blocking your creativity. Society has put up so many boundaries, so many limitations on what’s right and wrong that it’s almost impossible to get a pure thought out. It’s like a little kid, a little boy, looking at colors, and no one told him what colors are good, before somebody tells you you shouldn’t like pink because that’s for girls, or you’d instantly become a gay two-year-old. Why would anyone pick blue over pink? Pink is obviously a better color. Everyone’s born confident, and everything’s taken away from you. So many people try to put their personality on someone else.</p></blockquote>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Mar 2015 04:19:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"WPTavern: WPWeekly Episode 182 – John James Jacoby Talks BuddyPress, bbPress, and GlotPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=40127&preview_id=40127";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wptavern.com/wpweekly-episode-182-john-james-jacoby-talks-buddypress-bbpress-and-glotpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2988:"<p><a title="http://jjj.me/" href="http://jjj.me/">John James Jacoby</a> is nearly halfway through his <a title="http://wptavern.com/buddypress-bbpress-and-glotpress-development-campaign-is-now-fully-funded" href="http://wptavern.com/buddypress-bbpress-and-glotpress-development-campaign-is-now-fully-funded">six month development cycle</a> on <a title="https://buddypress.org/" href="https://buddypress.org/">BuddyPress</a>, <a title="https://bbpress.org/" href="https://bbpress.org/">bbPress</a>, and <a title="http://blog.glotpress.org/" href="http://blog.glotpress.org/">GlotPress</a>. So, <a title="http://marcuscouch.com/" href="http://marcuscouch.com/">Marcus Couch</a> and I invited him on the show to give us an update on how things are progressing. On average, WordPress Weekly is an hour-long. This episode however, is two hours and nine minutes, but is filled with deep conversations surrounding each project.</p>
<p>In this episode, we learn the history of BuddyPress and how its connection to WordPress MU (WordPress Multisite), influenced the project&#8217;s direction. Jacoby explains what GlotPress is and why its a cornerstone of the WordPress project. We discuss the future of comments on the web and the role bbPress can play in turning things around. Last but not least, we discuss whether Jacoby&#8217;s successful crowdfunding campaign has opened the door for others who need funding to work on open source projects.</p>
<h2>Plugins Picked By Marcus:</h2>
<p><a title="https://wordpress.org/plugins/buddypress-identicons/" href="https://wordpress.org/plugins/buddypress-identicons/">BuddyPress Identicons</a> automatically replaces default avatars with GitHub-style identicons. Each member&#8217;s identicon is likely to be unique, because it&#8217;s generated from a hash of their username.</p>
<p><a title="https://wordpress.org/plugins/buddypress-cover-photo/" href="https://wordpress.org/plugins/buddypress-cover-photo/">BuddyPress Cover Photo</a> allows users to upload a cover photo to their profile.</p>
<p><a title="https://wordpress.org/plugins/friends-for-bbpress/" href="https://wordpress.org/plugins/friends-for-bbpress/">Friends For bbPress</a> allows users to add friends in bbPress forums. This plugin creates a section on each user’s profile page that contains their friends.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, March 11th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #182:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Mar 2015 01:22:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"WPTavern: Wocker: Create a Docker-Based WordPress Development Environment in 3 Seconds";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40090";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:95:"http://wptavern.com/wocker-create-a-docker-based-wordpress-development-environment-in-3-seconds";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5731:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/docker-wordpress.jpg" rel="prettyphoto[40090]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/docker-wordpress.jpg?resize=1025%2C494" alt="docker-wordpress" class="aligncenter size-full wp-image-40098" /></a></p>
<p>If you haven&#8217;t caught on to the <a href="https://www.docker.com/" target="_blank">Docker</a> craze, it might be time to see what it&#8217;s all about. Fans of the open source container technology appreciate that it&#8217;s lightweight, super fast to boot up, and easy to share containers through the <a href="https://registry.hub.docker.com/" target="_blank">Docker Hub</a>.</p>
<p>Docker standardizes an app platform and its dependencies so you can hand the box over to another party without worrying about conflicting dependencies or differences between machines. While virtual machines can be rather weighty with an application plus an entire guest operating system, Docker is much lighter, containing just the application and its dependencies.</p>
<h3>Introducing Wocker</h3>
<p><a href="http://www.vagrantup.com/blog/vagrant-1-6.html" target="_blank">Vagrant 1.6.0</a>, released last May, introduced support for Docker-based development environments, enabling Vagrant to manage them within Docker-powered Linux containers, instead of virtual machines.</p>
<p>WordPress developers who want to incorporate Docker into their workflow now have a new tool at their disposal. <a href="http://wckr.github.io/" target="_blank">Wocker</a> is a Docker-based rapid development environment of WordPress.</p>
<p>If you already have Vagrant, VirtualBox, and the vagrant-hostsupdater plugin installed, then getting started with Wocker takes next to no time. Simply clone the Wocker repository:</p>
<p><code>$ git clone https://github.com/wckr/wocker.git &#038;&#038; cd wocker</code></p>
<p>Then run <code>vagrant up</code>.  You can now navigate to your Wocker development site at: <a href="http://wocker.dev/" target="blank">http://wocker.dev/</a>. Here you&#8217;ll find the latest version of WordPress installed with the default theme active.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/wocker.png" rel="prettyphoto[40090]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/wocker.png?resize=1025%2C650" alt="wocker" class="aligncenter size-full wp-image-40093" /></a></p>
<p>Running a new Wocker container takes just three seconds:</p>
<p><code>core@wocker ~ $ wocker run --name wp</code></p>
<p>The tasks of creating a new container, restarting a stopped container, or shutting down, can all be done in a matter of seconds with <a href="http://wckr.github.io/" target="_blank">Wocker commands</a>.</p>
<h3>Kite Koga on Creating Wocker</h3>
<p>Japanese WordPress developer <a href="https://twitter.com/ixkaito" target="_blank">Kite Koga</a> created Wocker to speed up his own development. Koga is also the organizer of the upcoming <a href="https://www.facebook.com/WordCampKansai2015" target="_blank">WordCamp Kansai 2015</a>.</p>
<p>&#8220;I used to use MAMP and VCCW for developing on WordPress,&#8221; Koga said. &#8220;MAMP is simple and easy but I have to download or copy WordPress core and create a database every time. <a href="http://vccw.cc/" target="_blank">VCCW</a> is a great tool, and I still use it now and then. It has a lot of options and functions but takes awhile to provision.&#8221;</p>
<p>Koga also experimented with using <a href="https://github.com/Varying-Vagrant-Vagrants/VVV" target="_blank">VVV</a> before creating Wocker. &#8220;Maybe VVV is good for developing WordPress core, but I feel it&#8217;s not fit for developing on WordPress. It takes too long to provision every time,&#8221; he said.</p>
<p>&#8220;Ultimately, I found that Docker was a good choice for me,&#8221; Koga said. &#8220;Once I have a Docker image, it takes only three seconds for every new WordPress container. However, Docker is a little tricky, and the command line is complex. Therefore, I made the Wocker command line to run containers and sync files with local more easily.&#8221;</p>
<p>Wocker is intentionally simple and limited to just a handful of options, as Koga&#8217;s primary objective was to make it super fast to create a new WordPress development environment. One drawback is that you cannot run two or more containers at the same time, but it takes just seconds to switch between containers.</p>
<p>Koga summarized the main reasons that he opted to use Vagrant to manage Docker deployments:</p>
<ol>
<li>I could write some provision scripts in the Vagrantfile, so users only have to do `$ vagrant up`</li>
<li>It was easier to map hostnames to IP addresses.</li>
<li>Vagrant with CoreOS was simpler to manage Docker images and containers than boot2docker.</li>
<li>To sync files between local machine, virtual machine, and the Docker container was tricky, so I made Wocker commands to make it easier.</li>
</ol>
<p>If you want to test out Wocker and find that it&#8217;s not for you, it&#8217;s easy and fast to uninstall. Simply run <code>$ vagrant destroy</code> to remove the Wocker folder, and your local machine will always be clean.</p>
<p>I tested Wocker and found that it was insanely fast to create new containers (as well as restart existing ones), a task for which I would require an extra utility (such as <a href="http://wptavern.com/variable-vvv-a-new-vvv-site-creation-wizard-for-wordpress" target="_blank">Variable VVV</a>) to perform with VVV. If you find VVV to be too slow and want to check out an alternative, <a href="http://wckr.github.io/" target="_blank">Wocker</a> provides a faster way to set up simple development environments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Mar 2015 00:52:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: WordCamp Europe Now Taking Applications for 2016 Host City";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40057";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://wptavern.com/wordcamp-europe-now-taking-applications-for-2016-host-city";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4150:"<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/wceu-volunteers.jpg" rel="prettyphoto[40057]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/wceu-volunteers.jpg?resize=1025%2C485" alt="wceu-volunteers" class="aligncenter size-full wp-image-31631" /></a></p>
<p>Organizing an event the size of <a href="http://europe.wordcamp.org/2015/" target="_blank">WordCamp Europe</a> is a year-round endeavor. The 2015 event is just four months away, speaker applications are closed, and the organization team is already asking for applications for the next host city. So far, the camp has been held in Leiden and Sofia, and will come to Seville in June.</p>
<p>Applying to host WordCamp Europe is similar to applying to be an Olympic city. Local WordPress communities in potential host cities must submit applications, including a budget and a convincing plan. Organizers scrutinize the applications for the following factors:</p>
<ul>
<li>Preparation of the budget and venue research</li>
<li>Strength of the local WordPress community</li>
<li>The merits of the new location, as compared to the previous year</li>
<li>Affordability for attendees</li>
<li>Potential travel difficulties</li>
</ul>
<p>This year <a href="http://wptavern.com/seville-spain-to-host-wordcamp-europe-2015" target="_blank">Seville, Spain was selected as the host city</a> after a short bidding process. WordCamp Central requested the event be scheduled earlier in the year to avoid calendar conflicts. This was an unusual turn of events but organizers are committed to re-instituting a public bidding process for all future events.</p>
<h3>WordCamp Europe to Pilot New Organizer Mentorship Program</h3>
<p>For months in advance, an all-star lineup of WordCamp organizers from around Europe put their heads together, sharing their experiences to plan the best event possible.</p>
<p>&#8220;Organizing WordCamp Europe is both a pleasure and a challenge,&#8221; co-organizer Petya Raykovska told the Tavern. &#8220;What’s great about it is that you get to work with experienced WordCamp organizers from across Europe. Each organizer brings their own knowledge and perspective to the organizing team which makes it a fantastic opportunity to learn and grow.&#8221;</p>
<p>The event has traditionally highlighted the diversity of the European WordPress community and its <a href="http://wptavern.com/wordpress-beyond-boundaries-a-recap-of-wordcamp-europe-2014" target="_blank">attendees&#8217; eagerness to connect beyond boundaries</a>.</p>
<p>&#8220;It’s a challenge because each of us has our own way of doing things and we have to learn how to listen to each other and compromise,&#8221; Raykovska said. &#8220;And, of course, there are all of those idioms that don’t cross language and cultural barriers!&#8221;</p>
<p>New WordCamp Europe organizers should be equipped with a solid grasp of diplomacy and the ability to work with others across cultural differences.</p>
<p>This year the current organization team plans to experiment with a mentorship program that would prepare the next crop of organizers to take the helm in 2016.</p>
<p>&#8220;We&#8217;re introducing a new process that we hope will help not only find the best team for next year, but will also be a pilot for a mentorship program for future WordCamp Europe (or any large 600+ people WordPress event) events,&#8221; Raykovska said.</p>
<p>&#8220;So what we want to do in 2015 is choose the team for 2016 and get them to work with us for the 2015 edition, so they can get to know what it takes, get introduced to the processes, work closely with the existing team and monitor what&#8217;s required of the local team.&#8221;</p>
<p>Current organizers are prioritizing mentoring new additions in order to create a seamless transition from one organizational team to the next. Instead of learning the ropes at the last minute, new organizers will have the opportunity to see how it works without all of the pressure.</p>
<p>&#8220;We believe it will be highly beneficial for them and will ensure smooth sailing for next year&#8217;s organisation,&#8221; Raykovska said.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Mar 2015 19:32:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:100:"WPTavern: New Theme Development Company Makes First Sale Minutes After Being Approved on ThemeForest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=40045";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:110:"http://wptavern.com/new-theme-development-company-makes-first-sale-minutes-after-being-approved-on-themeforest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4372:"<p><a title="http://warriorsofcode.com/" href="http://warriorsofcode.com/">Warriors Of Code</a> is a new WordPress theme development shop in Australia. An employee who goes by the name <a title="http://www.reddit.com/user/genesisfan" href="http://www.reddit.com/user/genesisfan">Genesisfan</a> on Reddit, <a title="http://www.reddit.com/r/Wordpress/comments/2xs8l2/just_had_our_first_wordpress_theme_accepted_at/" href="http://www.reddit.com/r/Wordpress/comments/2xs8l2/just_had_our_first_wordpress_theme_accepted_at/">published a post </a>explaining how the company recently had its first theme accepted on ThemeForest and was willing to answer questions others had about the experience. According to the post, he spent the better part of six months with a designer he hired while working a full-time job developing <a title="http://themeforest.net/item/broadsword-a-wordpress-theme-to-share-stories/full_screen_preview/10514496" href="http://themeforest.net/item/broadsword-a-wordpress-theme-to-share-stories/full_screen_preview/10514496">Broadsword</a>.</p>
<a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/BroadSword.png" rel="prettyphoto[40045]"><img class="size-full wp-image-40046" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2015/03/BroadSword.png?resize=1025%2C496" alt="BroadSword Single Page View" /></a>BroadSword Single Page View
<p>When asked what he thought of the ThemeForest submission and review process, he responded, &#8220;We were pleasantly surprised with how quickly they turned around our review, and the level of detail they provided in their soft rejection. Aside from some technicalities that we&#8217;d missed (being more specific about what features we supported), the biggest issue was that we were missing some data validation in our files. Make sure you use the esc_ and sanitize_ functions provided by WordPress!&#8221;</p>
<p>Once the issues were addressed, ThemeForest approved the submission and the team made its first sale within minutes of it going live. When asked what makes their theme different in the marketplace, he responded, &#8220;We kept the theme options to a minimum. We were both pretty tired of themes that include a thousand options and tend to be more like frameworks than standalone themes.&#8221;</p>
<p>Based on <a title="http://wptavern.com/envato-continues-to-rake-in-the-cash-from-wordpress-themes-packaged-as-complete-website-solutions" href="http://wptavern.com/envato-continues-to-rake-in-the-cash-from-wordpress-themes-packaged-as-complete-website-solutions">stats that highlight</a> how well ThemeForest is doing, it&#8217;s not surprising that Warriors of code made their first sale within minutes of going live. However, the company used social media to its advantage, so it&#8217;s possible one their followers purchased the theme based on tweets. In fact, the company explains how they handled promotion:</p>
<blockquote><p>Regarding promotion, we&#8217;ve been tweeting it out and liking the facebook page we&#8217;ve set up and luckily, it&#8217;s now trending on ThemeForest. It helps that I&#8217;m on the east coast of Canada and my partner is in Sydney, Australia, so we&#8217;re able to pretty much cover comment replies quickly at any time of the day. I think that goes a long way to helping promote a positive vibe about the theme.</p></blockquote>
<p>After 24 hours, the company has six sales at $43 each. It&#8217;s not a huge amount, but it&#8217;s a start. The big takeaways is that ThemeForest reviews are catching insecure coding practices and making the first sale is a quick endeavor, especially if you already have a social media presence. The company <a title="http://www.reddit.com/r/Wordpress/comments/2xs8l2/just_had_our_first_wordpress_theme_accepted_at/" href="http://www.reddit.com/r/Wordpress/comments/2xs8l2/just_had_our_first_wordpress_theme_accepted_at/">answers several other questions</a> related to the experience.</p>
<p>We know that in this instance, ThemeForest did its job to discover insecure coding practices during reviews. It&#8217;s also refreshing to hear from an up and coming theme company that they&#8217;re tired of theme options. I haven&#8217;t used their product so I can&#8217;t confirm if its claims are true, but it&#8217;s a step in the right direction to see other ThemeForest sellers make such statements in public.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Mar 2015 07:33:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Matt: WIRED Re-launch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=44764";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:37:"http://ma.tt/2015/03/wired-re-launch/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2726:"<p>There&#8217;s the smart publishers, and then there&#8217;s the <a href="http://ma.tt/2015/02/developer-employment-act/">ones going out of business</a>. WIRED is one of the smart ones, and just launched an awesome redesign on WordPress. <a href="http://www.wired.com/2015/03/our-new-site/">From their editor-in-chief</a>:</p>
<blockquote><p>Back in 1994 we launched Hotwired, the first site with original editorial content created for the web. It was a digital home for reporting on the future of science, business, design, and technology. You’ve come to trust us over the past two decades, but our growth online has sometimes come too quickly and with some pain. When I took over as editor in chief in 2012, WIRED had an archive of more than 100,000 stories. That’s good! But they were spread out over more than a dozen different databases, sections, and homepages tenuously connected by virtual duct tape and chewing gum. The cleanup process—onerous and without a shred of glamour—took almost 15 months. But finally, last year, our engineers rolled out a newly unified site architecture built atop a single streamlined WordPress installation. And you didn’t notice a hiccup. Maybe you saw that pages loaded a touch faster. Stories looked more WIRED.</p></blockquote>
<p>The story of <a href="http://www.wired.com/2015/03/wired-dot-com-from-the-devs/">the engineering behind it from Kathleen Vignos is also cool</a>:</p>
<blockquote><p>The redesign gives us the third incarnation of our Curator application, which started years ago as a separate Groovy on Grails application maintained by a single Java developer. Curator once consumed articles from 35 different blogs for curation on our homepage. When we migrated our 17 active WordPress blogs into one WordPress install, we also rewrote Curator in Cake PHP to match our WordPress PHP backend. After this, anyone on our team could maintain Curator—but the architecture remained the same and lived outside of WordPress. Using this version of Curator, our web producer team manually constructed the homepage throughout each day as various stories were ready to be promoted.</p>
<p>Our new and improved Curator is now a custom WordPress plugin—and it’s artificially intelligent! This allows our homepage and section landing pages to be both automated and curated at the same time. Stories flow through automagically based on editorial criteria, but editors can take control of the flow by locking stories in certain slots in our card system. This means our homepage and section landing pages are constantly changing with new stories all day long.</p></blockquote>
<p>Curator sounds cool, as does the coming &#8220;longform feature article builder.&#8221;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Mar 2015 02:36:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Wed, 18 Mar 2015 04:40:59 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"186469";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Wed, 18 Mar 2015 04:30:15 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 249";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20150226012146";}', 'no') ; 
INSERT INTO `wp_options` VALUES (329, '_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1426696859', 'no') ; 
INSERT INTO `wp_options` VALUES (330, '_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9', '1426653659', 'no') ; 
INSERT INTO `wp_options` VALUES (331, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1426696861', 'no') ; 
INSERT INTO `wp_options` VALUES (332, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:117:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"https://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 18 Mar 2015 04:18:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:30:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"15@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"https://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"8321@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast&#039;s WordPress SEO plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2141@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29860@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"https://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"23862@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:28:"Your WordPress, Streamlined.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"1169@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 12 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"18101@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"753@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Google Analytics by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Sep 2007 12:15:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2316@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:124:"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"132@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Arne Brachhold";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"bbPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"https://wordpress.org/plugins/bbpress/#post-14709";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 13 Dec 2009 00:05:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"14709@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:50:"bbPress is forum software, made the WordPress way.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"John James Jacoby";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"21738@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"The easiest, most effective way to secure WordPress in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"MailChimp for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"https://wordpress.org/plugins/mailchimp-for-wp/#post-54377";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 10 Jun 2013 17:32:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"54377@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:138:"The best MailChimp plugin to get more email subscribers. Easily add MailChimp sign-up forms and sign-up checkboxes to your WordPress site.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Danny van Kooten";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29832@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"ManageWP Worker";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"https://wordpress.org/plugins/worker/#post-24528";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Feb 2011 13:06:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"24528@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:103:"ManageWP is the ultimate WordPress productivity tool, allowing you to efficiently manage your websites.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Vladimir Prelovac";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Contact Form";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"https://wordpress.org/plugins/contact-form-plugin/#post-26890";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 May 2011 07:34:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"26890@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:43:"Add Contact Form to your WordPress website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"https://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"5468@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:67:"Make your WordPress website mobile-friendly with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"NextGEN Facebook - Advanced Social SEO for Facebook, Google+, Pinterest, Twitter &amp; More";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"https://wordpress.org/plugins/nextgen-facebook/#post-40409";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Jul 2012 20:13:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"40409@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"Display your content in the best possible way on Facebook, Google+, Twitter, Pinterest, etc. - no matter how your webpage is shared!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"JS Morisset";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"WP Statistics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/wp-statistics/#post-25318";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 20 Mar 2011 09:03:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"25318@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:44:"Complete statistics for your WordPress site.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Mostafa Soufi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Advanced Custom Fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/advanced-custom-fields/#post-25254";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Mar 2011 04:07:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"25254@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:68:"Customise WordPress with powerful, professional and intuitive fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"elliotcondon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2082@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Google Analytics Dashboard for WP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 17:07:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"50539@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Displays Google Analytics reports and real-time statistics in your WordPress Dashboard. Inserts the latest tracking code in every page of your site.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alin Marcu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WP Super Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/wp-super-cache/#post-2572";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Nov 2007 11:40:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2572@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:73:"A very fast caching engine for WordPress that produces static html files.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Donncha O Caoimh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"Page Links To";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/page-links-to/#post-216";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:53:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"216@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"Lets you make a WordPress page (or other content type) link to an external URL of your choosing, instead of its WordPress URL.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Mark Jaquith";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"NextScripts: Social Networks Auto-Poster";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"https://wordpress.org/plugins/social-networks-auto-poster-facebook-twitter-g/#post-35439";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Mar 2012 00:28:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"35439@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:149:"Automatically re-publishes blogposts to Facebook, Twitter, Google+, Pinterest, LinkedIn, Blogger, Tumblr, Delicious, Plurk, etc profiles and/or pages";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"NextScripts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/w3-total-cache/#post-12073";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 29 Jul 2009 18:46:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"12073@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"Easy Web Performance Optimization (WPO) using caching: browser, page, object, database, minify and content delivery network support.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"Newsletter";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/plugins/newsletter/#post-10777";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 May 2009 15:50:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"10777@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:96:"Add a real newsletter to your blog. In seconds. For free. With unlimited emails and subscribers.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Stefano Lissa";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Meta Slider";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/ml-slider/#post-49521";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Feb 2013 16:56:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"49521@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:145:"Easy to use WordPress slider plugin. Create SEO optimised responsive slideshows with Nivo Slider, Flex Slider, Coin Slider and Responsive Slides.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Matcha Labs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"UpdraftPlus Backup and Restoration";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/updraftplus/#post-38058";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 May 2012 15:14:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"38058@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Backup and restoration made easy. Complete backups; manual or scheduled (backup to S3, Dropbox, Google Drive, Rackspace, FTP, SFTP, email + others).";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"David Anderson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Antispam Bee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/antispam-bee/#post-8484";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Jan 2009 08:43:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"8484@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:113:"„... another popular solution to fight spam is Antispam Bee“ – Matt Mullenweg, Q&#38;A WordCamp Europe 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"stalkerX";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:46:"https://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:12:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Wed, 18 Mar 2015 04:41:00 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:25:"strict-transport-security";s:11:"max-age=360";s:7:"expires";s:29:"Wed, 18 Mar 2015 04:53:47 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Wed, 18 Mar 2015 04:18:47 +0000";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20150226012146";}', 'no') ; 
INSERT INTO `wp_options` VALUES (333, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1426696861', 'no') ; 
INSERT INTO `wp_options` VALUES (334, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1426653661', 'no') ; 
INSERT INTO `wp_options` VALUES (335, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1426696861', 'no') ; 
INSERT INTO `wp_options` VALUES (336, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/\'>WordPress 4.2 Beta 1</a> <span class="rss-date">2015년 3월 12일</span><div class="rssSummary">WordPress 4.2 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.2, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/an-inside-look-at-versionpress-crowdfunding-campaign\'>WPTavern: An Inside Look at VersionPress’ Crowdfunding Campaign</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/tidy-repo-launches-wordpress-plugin-recommendation-service\'>WPTavern: Tidy Repo Launches WordPress Plugin Recommendation Service</a></li><li><a class=\'rsswidget\' href=\'http://ma.tt/2015/03/remote-work-popularity/\'>Matt: Remote Work Popularity</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>인기 플러그인:</span> <a href=\'https://wordpress.org/plugins/mailchimp-for-wp/\' class=\'dashboard-news-plugin-link\'>MailChimp for WordPress</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=mailchimp-for-wp&amp;_wpnonce=d51f88097c&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'MailChimp for WordPress\'>설치</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (385, '_site_transient_timeout_theme_roots', '1426684792', 'yes') ; 
INSERT INTO `wp_options` VALUES (386, '_site_transient_theme_roots', 'a:5:{s:18:"arcade-basic-child";s:7:"/themes";s:12:"arcade-basic";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (414, '_site_transient_timeout_available_translations', '1426694231', 'yes') ; 
INSERT INTO `wp_options` VALUES (415, '_site_transient_available_translations', 'a:52:{s:2:"ar";a:8:{s:8:"language";s:2:"ar";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-17 19:01:24";s:12:"english_name";s:6:"Arabic";s:11:"native_name";s:14:"العربية";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.1/ar.zip";s:3:"iso";a:2:{i:1;s:2:"ar";i:2;s:3:"ara";}s:7:"strings";a:1:{s:8:"continue";s:16:"المتابعة";}}s:2:"az";a:8:{s:8:"language";s:2:"az";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-27 15:23:28";s:12:"english_name";s:11:"Azerbaijani";s:11:"native_name";s:16:"Azərbaycan dili";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.1/az.zip";s:3:"iso";a:2:{i:1;s:2:"az";i:2;s:3:"aze";}s:7:"strings";a:1:{s:8:"continue";s:5:"Davam";}}s:5:"bg_BG";a:8:{s:8:"language";s:5:"bg_BG";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-18 11:10:33";s:12:"english_name";s:9:"Bulgarian";s:11:"native_name";s:18:"Български";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/bg_BG.zip";s:3:"iso";a:2:{i:1;s:2:"bg";i:2;s:3:"bul";}s:7:"strings";a:1:{s:8:"continue";s:22:"Продължение";}}s:5:"bs_BA";a:8:{s:8:"language";s:5:"bs_BA";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-08 17:39:56";s:12:"english_name";s:7:"Bosnian";s:11:"native_name";s:8:"Bosanski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/bs_BA.zip";s:3:"iso";a:2:{i:1;s:2:"bs";i:2;s:3:"bos";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:2:"ca";a:8:{s:8:"language";s:2:"ca";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-26 03:38:28";s:12:"english_name";s:7:"Catalan";s:11:"native_name";s:7:"Català";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.1/ca.zip";s:3:"iso";a:2:{i:1;s:2:"ca";i:2;s:3:"cat";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"cy";a:8:{s:8:"language";s:2:"cy";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-03 13:54:58";s:12:"english_name";s:5:"Welsh";s:11:"native_name";s:7:"Cymraeg";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.1/cy.zip";s:3:"iso";a:2:{i:1;s:2:"cy";i:2;s:3:"cym";}s:7:"strings";a:1:{s:8:"continue";s:6:"Parhau";}}s:5:"da_DK";a:8:{s:8:"language";s:5:"da_DK";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-18 22:27:33";s:12:"english_name";s:6:"Danish";s:11:"native_name";s:5:"Dansk";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/da_DK.zip";s:3:"iso";a:2:{i:1;s:2:"da";i:2;s:3:"dan";}s:7:"strings";a:1:{s:8:"continue";s:12:"Forts&#230;t";}}s:5:"de_CH";a:8:{s:8:"language";s:5:"de_CH";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-04 12:59:40";s:12:"english_name";s:20:"German (Switzerland)";s:11:"native_name";s:17:"Deutsch (Schweiz)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/de_CH.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:5:"de_DE";a:8:{s:8:"language";s:5:"de_DE";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-17 11:02:14";s:12:"english_name";s:6:"German";s:11:"native_name";s:7:"Deutsch";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/de_DE.zip";s:3:"iso";a:1:{i:1;s:2:"de";}s:7:"strings";a:1:{s:8:"continue";s:10:"Fortfahren";}}s:2:"el";a:8:{s:8:"language";s:2:"el";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-05 22:03:06";s:12:"english_name";s:5:"Greek";s:11:"native_name";s:16:"Ελληνικά";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.1/el.zip";s:3:"iso";a:2:{i:1;s:2:"el";i:2;s:3:"ell";}s:7:"strings";a:1:{s:8:"continue";s:16:"Συνέχεια";}}s:5:"en_GB";a:8:{s:8:"language";s:5:"en_GB";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-17 20:53:36";s:12:"english_name";s:12:"English (UK)";s:11:"native_name";s:12:"English (UK)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/en_GB.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_AU";a:8:{s:8:"language";s:5:"en_AU";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-05 09:59:30";s:12:"english_name";s:19:"English (Australia)";s:11:"native_name";s:19:"English (Australia)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/en_AU.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:5:"en_CA";a:8:{s:8:"language";s:5:"en_CA";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-28 01:01:02";s:12:"english_name";s:16:"English (Canada)";s:11:"native_name";s:16:"English (Canada)";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/en_CA.zip";s:3:"iso";a:3:{i:1;s:2:"en";i:2;s:3:"eng";i:3;s:3:"eng";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continue";}}s:2:"eo";a:8:{s:8:"language";s:2:"eo";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-18 13:11:32";s:12:"english_name";s:9:"Esperanto";s:11:"native_name";s:9:"Esperanto";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.1/eo.zip";s:3:"iso";a:2:{i:1;s:2:"eo";i:2;s:3:"epo";}s:7:"strings";a:1:{s:8:"continue";s:8:"Daŭrigi";}}s:5:"es_MX";a:8:{s:8:"language";s:5:"es_MX";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-05 15:18:10";s:12:"english_name";s:16:"Spanish (Mexico)";s:11:"native_name";s:19:"Español de México";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/es_MX.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_PE";a:8:{s:8:"language";s:5:"es_PE";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-17 02:52:28";s:12:"english_name";s:14:"Spanish (Peru)";s:11:"native_name";s:17:"Español de Perú";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/es_PE.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_ES";a:8:{s:8:"language";s:5:"es_ES";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-25 14:34:19";s:12:"english_name";s:15:"Spanish (Spain)";s:11:"native_name";s:8:"Español";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/es_ES.zip";s:3:"iso";a:1:{i:1;s:2:"es";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"es_CL";a:8:{s:8:"language";s:5:"es_CL";s:7:"version";s:3:"4.0";s:7:"updated";s:19:"2014-09-04 19:47:01";s:12:"english_name";s:15:"Spanish (Chile)";s:11:"native_name";s:17:"Español de Chile";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.0/es_CL.zip";s:3:"iso";a:2:{i:1;s:2:"es";i:2;s:3:"spa";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:2:"eu";a:8:{s:8:"language";s:2:"eu";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-09 12:20:08";s:12:"english_name";s:6:"Basque";s:11:"native_name";s:7:"Euskara";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.1/eu.zip";s:3:"iso";a:2:{i:1;s:2:"eu";i:2;s:3:"eus";}s:7:"strings";a:1:{s:8:"continue";s:8:"Jarraitu";}}s:5:"fa_IR";a:8:{s:8:"language";s:5:"fa_IR";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-23 14:29:09";s:12:"english_name";s:7:"Persian";s:11:"native_name";s:10:"فارسی";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/fa_IR.zip";s:3:"iso";a:2:{i:1;s:2:"fa";i:2;s:3:"fas";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:2:"fi";a:8:{s:8:"language";s:2:"fi";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-18 08:12:21";s:12:"english_name";s:7:"Finnish";s:11:"native_name";s:5:"Suomi";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.1/fi.zip";s:3:"iso";a:2:{i:1;s:2:"fi";i:2;s:3:"fin";}s:7:"strings";a:1:{s:8:"continue";s:5:"Jatka";}}s:5:"fr_FR";a:8:{s:8:"language";s:5:"fr_FR";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-12 17:29:55";s:12:"english_name";s:15:"French (France)";s:11:"native_name";s:9:"Français";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/fr_FR.zip";s:3:"iso";a:1:{i:1;s:2:"fr";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuer";}}s:2:"gd";a:8:{s:8:"language";s:2:"gd";s:7:"version";s:3:"4.0";s:7:"updated";s:19:"2014-09-05 17:37:43";s:12:"english_name";s:15:"Scottish Gaelic";s:11:"native_name";s:9:"Gàidhlig";s:7:"package";s:59:"https://downloads.wordpress.org/translation/core/4.0/gd.zip";s:3:"iso";a:3:{i:1;s:2:"gd";i:2;s:3:"gla";i:3;s:3:"gla";}s:7:"strings";a:1:{s:8:"continue";s:15:"Lean air adhart";}}s:5:"gl_ES";a:8:{s:8:"language";s:5:"gl_ES";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-17 18:37:43";s:12:"english_name";s:8:"Galician";s:11:"native_name";s:6:"Galego";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/gl_ES.zip";s:3:"iso";a:2:{i:1;s:2:"gl";i:2;s:3:"glg";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:3:"haz";a:8:{s:8:"language";s:3:"haz";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-12 01:05:09";s:12:"english_name";s:8:"Hazaragi";s:11:"native_name";s:15:"هزاره گی";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.1.1/haz.zip";s:3:"iso";a:2:{i:1;s:3:"haz";i:2;s:3:"haz";}s:7:"strings";a:1:{s:8:"continue";s:10:"ادامه";}}s:5:"he_IL";a:8:{s:8:"language";s:5:"he_IL";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-03 17:11:23";s:12:"english_name";s:6:"Hebrew";s:11:"native_name";s:16:"עִבְרִית";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/he_IL.zip";s:3:"iso";a:1:{i:1;s:2:"he";}s:7:"strings";a:1:{s:8:"continue";s:12:"להמשיך";}}s:2:"hr";a:8:{s:8:"language";s:2:"hr";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-20 16:50:00";s:12:"english_name";s:8:"Croatian";s:11:"native_name";s:8:"Hrvatski";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.1/hr.zip";s:3:"iso";a:2:{i:1;s:2:"hr";i:2;s:3:"hrv";}s:7:"strings";a:1:{s:8:"continue";s:7:"Nastavi";}}s:5:"hu_HU";a:8:{s:8:"language";s:5:"hu_HU";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-15 20:01:36";s:12:"english_name";s:9:"Hungarian";s:11:"native_name";s:6:"Magyar";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/hu_HU.zip";s:3:"iso";a:2:{i:1;s:2:"hu";i:2;s:3:"hun";}s:7:"strings";a:1:{s:8:"continue";s:7:"Tovább";}}s:5:"id_ID";a:8:{s:8:"language";s:5:"id_ID";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-17 21:42:45";s:12:"english_name";s:10:"Indonesian";s:11:"native_name";s:16:"Bahasa Indonesia";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/id_ID.zip";s:3:"iso";a:2:{i:1;s:2:"id";i:2;s:3:"ind";}s:7:"strings";a:1:{s:8:"continue";s:9:"Lanjutkan";}}s:5:"is_IS";a:8:{s:8:"language";s:5:"is_IS";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-15 22:23:37";s:12:"english_name";s:9:"Icelandic";s:11:"native_name";s:9:"Íslenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/is_IS.zip";s:3:"iso";a:2:{i:1;s:2:"is";i:2;s:3:"isl";}s:7:"strings";a:1:{s:8:"continue";s:6:"Áfram";}}s:5:"it_IT";a:8:{s:8:"language";s:5:"it_IT";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-02 13:41:23";s:12:"english_name";s:7:"Italian";s:11:"native_name";s:8:"Italiano";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/it_IT.zip";s:3:"iso";a:2:{i:1;s:2:"it";i:2;s:3:"ita";}s:7:"strings";a:1:{s:8:"continue";s:8:"Continua";}}s:2:"ja";a:8:{s:8:"language";s:2:"ja";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-29 10:53:40";s:12:"english_name";s:8:"Japanese";s:11:"native_name";s:9:"日本語";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.1/ja.zip";s:3:"iso";a:1:{i:1;s:2:"ja";}s:7:"strings";a:1:{s:8:"continue";s:9:"続ける";}}s:5:"ko_KR";a:8:{s:8:"language";s:5:"ko_KR";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-21 03:05:42";s:12:"english_name";s:6:"Korean";s:11:"native_name";s:9:"한국어";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/ko_KR.zip";s:3:"iso";a:2:{i:1;s:2:"ko";i:2;s:3:"kor";}s:7:"strings";a:1:{s:8:"continue";s:6:"계속";}}s:5:"lt_LT";a:8:{s:8:"language";s:5:"lt_LT";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-08 00:36:50";s:12:"english_name";s:10:"Lithuanian";s:11:"native_name";s:15:"Lietuvių kalba";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/lt_LT.zip";s:3:"iso";a:2:{i:1;s:2:"lt";i:2;s:3:"lit";}s:7:"strings";a:1:{s:8:"continue";s:6:"Tęsti";}}s:5:"my_MM";a:8:{s:8:"language";s:5:"my_MM";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-23 10:05:46";s:12:"english_name";s:7:"Burmese";s:11:"native_name";s:15:"ဗမာစာ";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/my_MM.zip";s:3:"iso";a:2:{i:1;s:2:"my";i:2;s:3:"mya";}s:7:"strings";a:1:{s:8:"continue";s:54:"ဆက်လက်လုပ်ေဆာင်ပါ။";}}s:5:"nb_NO";a:8:{s:8:"language";s:5:"nb_NO";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-18 11:09:37";s:12:"english_name";s:19:"Norwegian (Bokmål)";s:11:"native_name";s:13:"Norsk bokmål";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/nb_NO.zip";s:3:"iso";a:2:{i:1;s:2:"nb";i:2;s:3:"nob";}s:7:"strings";a:1:{s:8:"continue";s:8:"Fortsett";}}s:5:"nl_NL";a:8:{s:8:"language";s:5:"nl_NL";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-18 13:44:24";s:12:"english_name";s:5:"Dutch";s:11:"native_name";s:10:"Nederlands";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/nl_NL.zip";s:3:"iso";a:2:{i:1;s:2:"nl";i:2;s:3:"nld";}s:7:"strings";a:1:{s:8:"continue";s:8:"Doorgaan";}}s:5:"pl_PL";a:8:{s:8:"language";s:5:"pl_PL";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-16 15:47:22";s:12:"english_name";s:6:"Polish";s:11:"native_name";s:6:"Polski";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/pl_PL.zip";s:3:"iso";a:2:{i:1;s:2:"pl";i:2;s:3:"pol";}s:7:"strings";a:1:{s:8:"continue";s:9:"Kontynuuj";}}s:2:"ps";a:8:{s:8:"language";s:2:"ps";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-16 23:53:10";s:12:"english_name";s:6:"Pashto";s:11:"native_name";s:8:"پښتو";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.1/ps.zip";s:3:"iso";a:1:{i:1;s:2:"ps";}s:7:"strings";a:1:{s:8:"continue";s:8:"دوام";}}s:5:"pt_BR";a:8:{s:8:"language";s:5:"pt_BR";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-19 19:37:03";s:12:"english_name";s:19:"Portuguese (Brazil)";s:11:"native_name";s:20:"Português do Brasil";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/pt_BR.zip";s:3:"iso";a:2:{i:1;s:2:"pt";i:2;s:3:"por";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"pt_PT";a:8:{s:8:"language";s:5:"pt_PT";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-25 20:46:09";s:12:"english_name";s:21:"Portuguese (Portugal)";s:11:"native_name";s:10:"Português";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/pt_PT.zip";s:3:"iso";a:1:{i:1;s:2:"pt";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuar";}}s:5:"ro_RO";a:8:{s:8:"language";s:5:"ro_RO";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-17 15:30:47";s:12:"english_name";s:8:"Romanian";s:11:"native_name";s:8:"Română";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/ro_RO.zip";s:3:"iso";a:2:{i:1;s:2:"ro";i:2;s:3:"ron";}s:7:"strings";a:1:{s:8:"continue";s:9:"Continuă";}}s:5:"ru_RU";a:8:{s:8:"language";s:5:"ru_RU";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-17 18:16:58";s:12:"english_name";s:7:"Russian";s:11:"native_name";s:14:"Русский";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/ru_RU.zip";s:3:"iso";a:2:{i:1;s:2:"ru";i:2;s:3:"rus";}s:7:"strings";a:1:{s:8:"continue";s:20:"Продолжить";}}s:5:"sk_SK";a:8:{s:8:"language";s:5:"sk_SK";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-02 18:38:35";s:12:"english_name";s:6:"Slovak";s:11:"native_name";s:11:"Slovenčina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/sk_SK.zip";s:3:"iso";a:2:{i:1;s:2:"sk";i:2;s:3:"slk";}s:7:"strings";a:1:{s:8:"continue";s:12:"Pokračovať";}}s:5:"sl_SI";a:8:{s:8:"language";s:5:"sl_SI";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-13 22:38:48";s:12:"english_name";s:9:"Slovenian";s:11:"native_name";s:13:"Slovenščina";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/sl_SI.zip";s:3:"iso";a:2:{i:1;s:2:"sl";i:2;s:3:"slv";}s:7:"strings";a:1:{s:8:"continue";s:10:"Nadaljujte";}}s:5:"sr_RS";a:8:{s:8:"language";s:5:"sr_RS";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-03-17 18:59:19";s:12:"english_name";s:7:"Serbian";s:11:"native_name";s:23:"Српски језик";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/sr_RS.zip";s:3:"iso";a:2:{i:1;s:2:"sr";i:2;s:3:"srp";}s:7:"strings";a:1:{s:8:"continue";s:14:"Настави";}}s:5:"sv_SE";a:8:{s:8:"language";s:5:"sv_SE";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-29 09:41:07";s:12:"english_name";s:7:"Swedish";s:11:"native_name";s:7:"Svenska";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/sv_SE.zip";s:3:"iso";a:2:{i:1;s:2:"sv";i:2;s:3:"swe";}s:7:"strings";a:1:{s:8:"continue";s:9:"Fortsätt";}}s:2:"th";a:8:{s:8:"language";s:2:"th";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-26 04:10:43";s:12:"english_name";s:4:"Thai";s:11:"native_name";s:9:"ไทย";s:7:"package";s:61:"https://downloads.wordpress.org/translation/core/4.1.1/th.zip";s:3:"iso";a:2:{i:1;s:2:"th";i:2;s:3:"tha";}s:7:"strings";a:1:{s:8:"continue";s:15:"ต่อไป";}}s:5:"tr_TR";a:8:{s:8:"language";s:5:"tr_TR";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-01-19 08:42:08";s:12:"english_name";s:7:"Turkish";s:11:"native_name";s:8:"Türkçe";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/tr_TR.zip";s:3:"iso";a:2:{i:1;s:2:"tr";i:2;s:3:"tur";}s:7:"strings";a:1:{s:8:"continue";s:5:"Devam";}}s:5:"ug_CN";a:8:{s:8:"language";s:5:"ug_CN";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-19 05:33:04";s:12:"english_name";s:6:"Uighur";s:11:"native_name";s:9:"Uyƣurqə";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/ug_CN.zip";s:3:"iso";a:2:{i:1;s:2:"ug";i:2;s:3:"uig";}s:7:"strings";a:1:{s:8:"continue";s:26:"داۋاملاشتۇرۇش";}}s:5:"zh_TW";a:8:{s:8:"language";s:5:"zh_TW";s:7:"version";s:5:"4.1.1";s:7:"updated";s:19:"2015-02-19 08:39:08";s:12:"english_name";s:16:"Chinese (Taiwan)";s:11:"native_name";s:12:"繁體中文";s:7:"package";s:64:"https://downloads.wordpress.org/translation/core/4.1.1/zh_TW.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"繼續";}}s:5:"zh_CN";a:8:{s:8:"language";s:5:"zh_CN";s:7:"version";s:3:"4.1";s:7:"updated";s:19:"2014-12-26 02:21:02";s:12:"english_name";s:15:"Chinese (China)";s:11:"native_name";s:12:"简体中文";s:7:"package";s:62:"https://downloads.wordpress.org/translation/core/4.1/zh_CN.zip";s:3:"iso";a:2:{i:1;s:2:"zh";i:2;s:3:"zho";}s:7:"strings";a:1:{s:8:"continue";s:6:"继续";}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (429, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:65:"https://downloads.wordpress.org/release/ko_KR/wordpress-4.1.1.zip";s:6:"locale";s:5:"ko_KR";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:65:"https://downloads.wordpress.org/release/ko_KR/wordpress-4.1.1.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.1.1";s:7:"version";s:5:"4.1.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1426683462;s:15:"version_checked";s:5:"4.1.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (430, '_site_transient_update_plugins', 'O:8:"stdClass":5:{s:12:"last_checked";i:1426683962;s:7:"checked";a:15:{s:19:"akismet/akismet.php";s:5:"3.1.1";s:35:"backupwordpress/backupwordpress.php";s:5:"3.2.0";s:37:"login-customizer/login-customizer.php";s:5:"1.0.1";s:47:"dubu_dashboard_widget/dubu_dashboard_widget.php";s:3:"1.0";s:23:"dubu_feed/dubu_feed.php";s:5:"1.0.1";s:27:"dubu_filter/dubu_filter.php";s:5:"1.0.1";s:27:"dubu_notice/dubu_notice.php";s:5:"1.0.1";s:25:"dubu_power/dubu_power.php";s:5:"1.0.1";s:27:"dubu_tester/dubu_tester.php";s:5:"1.0.1";s:29:"dubu_tweeter/dubu_tweeter.php";s:5:"1.0.1";s:27:"dubu_widget/dubu_widget.php";s:5:"1.0.1";s:33:"tweet-old-post/tweet-old-post.php";s:5:"7.0.1";s:23:"statpress/statpress.php";s:5:"1.4.3";s:41:"wordpress-importer/wordpress-importer.php";s:5:"0.6.1";s:32:"wp-google-fonts/google-fonts.php";s:6:"v3.1.1";}s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:7:{s:19:"akismet/akismet.php";O:8:"stdClass":6:{s:2:"id";s:2:"15";s:4:"slug";s:7:"akismet";s:6:"plugin";s:19:"akismet/akismet.php";s:11:"new_version";s:5:"3.1.1";s:3:"url";s:38:"https://wordpress.org/plugins/akismet/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/akismet.3.1.1.zip";}s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":6:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:6:"plugin";s:35:"backupwordpress/backupwordpress.php";s:11:"new_version";s:5:"3.2.0";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.3.2.0.zip";}s:37:"login-customizer/login-customizer.php";O:8:"stdClass":6:{s:2:"id";s:5:"55995";s:4:"slug";s:16:"login-customizer";s:6:"plugin";s:37:"login-customizer/login-customizer.php";s:11:"new_version";s:5:"1.0.1";s:3:"url";s:47:"https://wordpress.org/plugins/login-customizer/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/login-customizer.zip";}s:33:"tweet-old-post/tweet-old-post.php";O:8:"stdClass":6:{s:2:"id";s:5:"11661";s:4:"slug";s:14:"tweet-old-post";s:6:"plugin";s:33:"tweet-old-post/tweet-old-post.php";s:11:"new_version";s:5:"7.0.1";s:3:"url";s:45:"https://wordpress.org/plugins/tweet-old-post/";s:7:"package";s:57:"https://downloads.wordpress.org/plugin/tweet-old-post.zip";}s:23:"statpress/statpress.php";O:8:"stdClass":6:{s:2:"id";s:4:"1032";s:4:"slug";s:9:"statpress";s:6:"plugin";s:23:"statpress/statpress.php";s:11:"new_version";s:5:"1.4.3";s:3:"url";s:40:"https://wordpress.org/plugins/statpress/";s:7:"package";s:52:"https://downloads.wordpress.org/plugin/statpress.zip";}s:41:"wordpress-importer/wordpress-importer.php";O:8:"stdClass":6:{s:2:"id";s:5:"14975";s:4:"slug";s:18:"wordpress-importer";s:6:"plugin";s:41:"wordpress-importer/wordpress-importer.php";s:11:"new_version";s:5:"0.6.1";s:3:"url";s:49:"https://wordpress.org/plugins/wordpress-importer/";s:7:"package";s:67:"https://downloads.wordpress.org/plugin/wordpress-importer.0.6.1.zip";}s:32:"wp-google-fonts/google-fonts.php";O:8:"stdClass":6:{s:2:"id";s:5:"15001";s:4:"slug";s:15:"wp-google-fonts";s:6:"plugin";s:32:"wp-google-fonts/google-fonts.php";s:11:"new_version";s:6:"v3.1.1";s:3:"url";s:46:"https://wordpress.org/plugins/wp-google-fonts/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/wp-google-fonts.zip";}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (431, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1426683464;s:7:"checked";a:5:{s:18:"arcade-basic-child";s:5:"1.0.5";s:12:"arcade-basic";s:5:"1.0.5";s:13:"twentyfifteen";s:3:"1.0";s:14:"twentyfourteen";s:3:"1.3";s:14:"twentythirteen";s:3:"1.4";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (563, '_transient_doing_cron', '1426687202.0715711116790771484375', 'yes') ; 
INSERT INTO `wp_options` VALUES (564, 'rewrite_rules', 'a:89:{s:9:"notice/?$";s:31:"index.php?post_type=dubu_notice";s:39:"notice/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=dubu_notice&feed=$matches[1]";s:34:"notice/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=dubu_notice&feed=$matches[1]";s:26:"notice/page/([0-9]{1,})/?$";s:49:"index.php?post_type=dubu_notice&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:34:"notice/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"notice/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"notice/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"notice/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"notice/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"notice/([^/]+)/trackback/?$";s:38:"index.php?dubu_notice=$matches[1]&tb=1";s:47:"notice/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?dubu_notice=$matches[1]&feed=$matches[2]";s:42:"notice/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?dubu_notice=$matches[1]&feed=$matches[2]";s:35:"notice/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?dubu_notice=$matches[1]&paged=$matches[2]";s:42:"notice/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?dubu_notice=$matches[1]&cpage=$matches[2]";s:27:"notice/([^/]+)(/[0-9]+)?/?$";s:50:"index.php?dubu_notice=$matches[1]&page=$matches[2]";s:23:"notice/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:33:"notice/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:53:"notice/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"notice/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:48:"notice/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=8&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 18. March 2015 14:00 UTC
# Hostname: localhost
# Database: `wordplus`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (108 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 1, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (2, 1, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (3, 1, '_menu_item_object_id', '1') ; 
INSERT INTO `wp_postmeta` VALUES (4, 1, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (5, 1, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (6, 1, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (7, 1, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (8, 1, '_menu_item_url', 'http://localhost:8888') ; 
INSERT INTO `wp_postmeta` VALUES (9, 2, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (10, 2, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (11, 2, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (12, 2, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (13, 2, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (14, 2, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (15, 2, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (16, 2, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (17, 3, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (18, 3, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (19, 3, '_menu_item_object_id', '3') ; 
INSERT INTO `wp_postmeta` VALUES (20, 3, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (21, 3, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (22, 3, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (23, 3, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (24, 3, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (25, 4, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (26, 4, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (27, 4, '_menu_item_object_id', '4') ; 
INSERT INTO `wp_postmeta` VALUES (28, 4, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (29, 4, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (30, 4, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (31, 4, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (32, 4, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (33, 5, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (34, 5, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (35, 5, '_menu_item_object_id', '5') ; 
INSERT INTO `wp_postmeta` VALUES (36, 5, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (37, 5, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (38, 5, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (39, 5, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (40, 5, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (41, 6, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (42, 6, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (43, 6, '_menu_item_object_id', '6') ; 
INSERT INTO `wp_postmeta` VALUES (44, 6, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (45, 6, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (46, 6, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (47, 6, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (48, 6, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (51, 8, '_wp_page_template', 'page-templates/template-post-block.php') ; 
INSERT INTO `wp_postmeta` VALUES (52, 8, '_edit_lock', '1426258331:1') ; 
INSERT INTO `wp_postmeta` VALUES (53, 7, '_edit_lock', '1426403557:1') ; 
INSERT INTO `wp_postmeta` VALUES (54, 7, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (57, 12, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (58, 12, '_edit_lock', '1426400997:1') ; 
INSERT INTO `wp_postmeta` VALUES (59, 12, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (60, 14, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (61, 14, '_edit_lock', '1426401009:1') ; 
INSERT INTO `wp_postmeta` VALUES (62, 14, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (63, 16, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (64, 16, '_edit_lock', '1426401025:1') ; 
INSERT INTO `wp_postmeta` VALUES (65, 16, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (66, 18, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (67, 18, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (68, 18, '_menu_item_object_id', '12') ; 
INSERT INTO `wp_postmeta` VALUES (69, 18, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (70, 18, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (71, 18, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (72, 18, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (73, 18, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (75, 19, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (76, 19, '_menu_item_menu_item_parent', '18') ; 
INSERT INTO `wp_postmeta` VALUES (77, 19, '_menu_item_object_id', '16') ; 
INSERT INTO `wp_postmeta` VALUES (78, 19, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (79, 19, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (80, 19, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (81, 19, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (82, 19, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (84, 20, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (85, 20, '_menu_item_menu_item_parent', '18') ; 
INSERT INTO `wp_postmeta` VALUES (86, 20, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (87, 20, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (88, 20, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (89, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (90, 20, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (91, 20, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (97, 21, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (98, 21, '_edit_lock', '1426572942:1') ; 
INSERT INTO `wp_postmeta` VALUES (99, 23, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (100, 23, '_edit_lock', '1426403397:1') ; 
INSERT INTO `wp_postmeta` VALUES (107, 25, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (108, 25, '_edit_lock', '1426403662:1') ; 
INSERT INTO `wp_postmeta` VALUES (109, 26, '_wp_attached_file', '2015/03/Lamborghini-Veneno-awesome1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (110, 26, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:625;s:4:"file";s:39:"2015/03/Lamborghini-Veneno-awesome1.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"Lamborghini-Veneno-awesome1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:39:"Lamborghini-Veneno-awesome1-300x183.jpg";s:5:"width";i:300;s:6:"height";i:183;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:40:"Lamborghini-Veneno-awesome1-1024x625.jpg";s:5:"width";i:1024;s:6:"height";i:625;s:9:"mime-type";s:10:"image/jpeg";}s:4:"half";a:4:{s:4:"file";s:39:"Lamborghini-Veneno-awesome1-570x220.jpg";s:5:"width";i:570;s:6:"height";i:220;s:9:"mime-type";s:10:"image/jpeg";}s:9:"square100";a:4:{s:4:"file";s:39:"Lamborghini-Veneno-awesome1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (113, 28, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (114, 28, '_edit_lock', '1426403918:1') ; 
INSERT INTO `wp_postmeta` VALUES (115, 29, '_wp_attached_file', '2015/03/screenshot-2015-03-02-11.50.521.png') ; 
INSERT INTO `wp_postmeta` VALUES (116, 29, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:474;s:6:"height";i:307;s:4:"file";s:43:"2015/03/screenshot-2015-03-02-11.50.521.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:43:"screenshot-2015-03-02-11.50.521-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:43:"screenshot-2015-03-02-11.50.521-300x194.png";s:5:"width";i:300;s:6:"height";i:194;s:9:"mime-type";s:9:"image/png";}s:4:"half";a:4:{s:4:"file";s:43:"screenshot-2015-03-02-11.50.521-474x220.png";s:5:"width";i:474;s:6:"height";i:220;s:9:"mime-type";s:9:"image/png";}s:9:"square100";a:4:{s:4:"file";s:43:"screenshot-2015-03-02-11.50.521-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}') ; 
INSERT INTO `wp_postmeta` VALUES (119, 31, '_menu_item_type', 'taxonomy') ; 
INSERT INTO `wp_postmeta` VALUES (120, 31, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (121, 31, '_menu_item_object_id', '1') ; 
INSERT INTO `wp_postmeta` VALUES (122, 31, '_menu_item_object', 'category') ; 
INSERT INTO `wp_postmeta` VALUES (123, 31, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (124, 31, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (125, 31, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (126, 31, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (138, 50, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (139, 50, '_edit_lock', '1426686668:1') ; 
INSERT INTO `wp_postmeta` VALUES (140, 50, 'dubu_notice_top_priority', '') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 18. March 2015 14:00 UTC
# Hostname: localhost
# Database: `wordplus`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (50 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2015-03-12 14:42:10', '2015-03-12 05:42:10', '', 'HOME', '', 'publish', 'open', 'open', '', 'home', '', '', '2015-03-15 16:17:45', '2015-03-15 07:17:45', '', 0, 'http://localhost:8888/?p=1', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2015-03-12 14:42:10', '2015-03-12 05:42:10', ' ', '', '', 'publish', 'open', 'open', '', '2', '', '', '2015-03-15 16:17:45', '2015-03-15 07:17:45', '', 0, 'http://localhost:8888/?p=2', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (3, 1, '2015-03-12 14:42:10', '2015-03-12 05:42:10', ' ', '', '', 'publish', 'open', 'open', '', '3', '', '', '2015-03-15 16:17:45', '2015-03-15 07:17:45', '', 0, 'http://localhost:8888/?p=3', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2015-03-12 14:42:11', '2015-03-12 05:42:11', ' ', '', '', 'publish', 'open', 'open', '', '4', '', '', '2015-03-15 16:17:46', '2015-03-15 07:17:46', '', 0, 'http://localhost:8888/?p=4', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2015-03-12 14:42:11', '2015-03-12 05:42:11', ' ', '', '', 'publish', 'open', 'open', '', '5', '', '', '2015-03-15 16:17:46', '2015-03-15 07:17:46', '', 0, 'http://localhost:8888/?p=5', 5, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2015-03-12 14:42:11', '2015-03-12 05:42:11', ' ', '', '', 'publish', 'open', 'open', '', '6', '', '', '2015-03-15 16:17:46', '2015-03-15 07:17:46', '', 0, 'http://localhost:8888/?p=6', 6, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2015-03-12 14:42:11', '2015-03-12 05:42:11', '<code>이것을 첫번째 글입니다. 감사합니다!!</code>', '첫번째 글', '', 'publish', 'open', 'open', '', '%ec%b2%ab%eb%b2%88%ec%a7%b8-%ea%b8%80', '', '', '2015-03-15 16:12:37', '2015-03-15 07:12:37', '', 0, 'http://localhost:8888/?p=7', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2015-03-12 14:42:11', '2015-03-12 05:42:11', '이것을 첫번째 페이지입니다. 감사합니다!!', 'NEWS', '', 'publish', 'open', 'open', '', 'news', '', '', '2015-03-12 14:42:11', '2015-03-12 05:42:11', '', 0, 'http://localhost:8888/?page_id=8', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2015-03-12 14:42:18', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-12 14:42:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?p=9', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2015-03-14 12:15:33', '2015-03-14 03:15:33', '<code>이것을 첫번째 글입니다. 감사합니다!!</code>', '첫번째 글', '', 'inherit', 'open', 'open', '', '7-revision-v1', '', '', '2015-03-14 12:15:33', '2015-03-14 03:15:33', '', 7, 'http://localhost:8888/?p=10', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2015-03-15 15:31:43', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-15 15:31:43', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?page_id=11', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2015-03-15 15:32:19', '2015-03-15 06:32:19', 'fdsffsfdsf', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2015-03-15 15:32:19', '2015-03-15 06:32:19', '', 0, 'http://localhost:8888/?page_id=12', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2015-03-15 15:32:19', '2015-03-15 06:32:19', 'fdsffsfdsf', 'About', '', 'inherit', 'open', 'open', '', '12-revision-v1', '', '', '2015-03-15 15:32:19', '2015-03-15 06:32:19', '', 12, 'http://localhost:8888/?p=13', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2015-03-15 15:32:31', '2015-03-15 06:32:31', 'fdsfsdfdfds', 'Members', '', 'publish', 'open', 'open', '', 'members', '', '', '2015-03-15 15:32:31', '2015-03-15 06:32:31', '', 12, 'http://localhost:8888/?page_id=14', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2015-03-15 15:32:31', '2015-03-15 06:32:31', 'fdsfsdfdfds', 'Members', '', 'inherit', 'open', 'open', '', '14-revision-v1', '', '', '2015-03-15 15:32:31', '2015-03-15 06:32:31', '', 14, 'http://localhost:8888/?p=15', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (16, 1, '2015-03-15 15:32:42', '2015-03-15 06:32:42', 'fdsfsdffdfds', 'Location', '', 'publish', 'open', 'open', '', 'location', '', '', '2015-03-15 15:32:42', '2015-03-15 06:32:42', '', 12, 'http://localhost:8888/?page_id=16', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2015-03-15 15:32:42', '2015-03-15 06:32:42', 'fdsfsdffdfds', 'Location', '', 'inherit', 'open', 'open', '', '16-revision-v1', '', '', '2015-03-15 15:32:42', '2015-03-15 06:32:42', '', 16, 'http://localhost:8888/?p=17', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (18, 1, '2015-03-15 15:33:04', '2015-03-15 06:33:04', ' ', '', '', 'publish', 'open', 'open', '', '18', '', '', '2015-03-15 16:17:46', '2015-03-15 07:17:46', '', 0, 'http://localhost:8888/?p=18', 7, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (19, 1, '2015-03-15 15:33:27', '2015-03-15 06:33:27', ' ', '', '', 'publish', 'open', 'open', '', '19', '', '', '2015-03-15 16:17:46', '2015-03-15 07:17:46', '', 12, 'http://localhost:8888/?p=19', 8, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2015-03-15 15:33:27', '2015-03-15 06:33:27', ' ', '', '', 'publish', 'open', 'open', '', '20', '', '', '2015-03-15 16:17:46', '2015-03-15 07:17:46', '', 12, 'http://localhost:8888/?p=20', 9, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2015-03-16 15:50:18', '2015-03-16 06:50:18', '<code>ㅍㅊㅌㅍㅊㅌㅍㅌㅊㅍㅊㅌㅍㅊㅌㅍㅊㅌㅍㅊㅌ</code>', 'ㅌㅊㅌㅊㅍㅇㅍㅇㅌㅍ', '', 'publish', 'open', 'open', '', '%e3%85%8c%e3%85%8a%e3%85%8c%e3%85%8a%e3%85%8d%e3%85%87%e3%85%8d%e3%85%87%e3%85%8c%e3%85%8d', '', '', '2015-03-17 15:18:03', '2015-03-17 06:18:03', '', 0, 'http://localhost:8888/?p=21', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2015-03-15 15:50:37', '2015-03-15 06:50:37', 'ㅍㅊㅌㅍㅊㅌㅍㅌㅊㅍㅊㅌㅍㅊㅌㅍㅊㅌㅍㅊㅌ', 'ㅌㅊㅌㅊㅍㅇㅍㅇㅌㅍ', '', 'inherit', 'open', 'open', '', '21-revision-v1', '', '', '2015-03-15 15:50:37', '2015-03-15 06:50:37', '', 21, 'http://localhost:8888/?p=22', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (23, 1, '2015-03-15 16:11:50', '2015-03-15 07:11:50', 'ㄹㅇㄴㄹㅇㄴㄹㅇㄴㅇㄹㄴㄹㅇㄴ', '너무 좋아요!!', '', 'publish', 'open', 'open', '', '%eb%84%88%eb%ac%b4-%ec%a2%8b%ec%95%84%ec%9a%94', '', '', '2015-03-17 16:27:00', '2015-03-17 07:27:00', '', 0, 'http://localhost:8888/?p=23', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2015-03-15 16:11:50', '2015-03-15 07:11:50', 'ㄹㅇㄴㄹㅇㄴㄹㅇㄴㅇㄹㄴㄹㅇㄴ', '너무 좋아요!!', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2015-03-15 16:11:50', '2015-03-15 07:11:50', '', 23, 'http://localhost:8888/?p=24', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2015-03-15 16:16:42', '2015-03-15 07:16:42', 'ㅇㄴㄹㅇㄴㅇㄴㄹ<a href="http://localhost:8888/wp-content/uploads/2015/03/Lamborghini-Veneno-awesome1.jpg"><img class="alignnone size-medium wp-image-26" src="http://localhost:8888/wp-content/uploads/2015/03/Lamborghini-Veneno-awesome1-300x183.jpg" alt="Lamborghini-Veneno-awesome1" width="300" height="183" /></a>', '이미지1', '', 'publish', 'open', 'open', '', '%ec%9d%b4%eb%af%b8%ec%a7%801', '', '', '2015-03-17 16:27:00', '2015-03-17 07:27:00', '', 0, 'http://localhost:8888/?p=25', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2015-03-15 16:16:33', '2015-03-15 07:16:33', '', 'Lamborghini-Veneno-awesome1', '', 'inherit', 'open', 'open', '', 'lamborghini-veneno-awesome1', '', '', '2015-03-15 16:16:33', '2015-03-15 07:16:33', '', 25, 'http://localhost:8888/wp-content/uploads/2015/03/Lamborghini-Veneno-awesome1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2015-03-15 16:16:42', '2015-03-15 07:16:42', 'ㅇㄴㄹㅇㄴㅇㄴㄹ<a href="http://localhost:8888/wp-content/uploads/2015/03/Lamborghini-Veneno-awesome1.jpg"><img class="alignnone size-medium wp-image-26" src="http://localhost:8888/wp-content/uploads/2015/03/Lamborghini-Veneno-awesome1-300x183.jpg" alt="Lamborghini-Veneno-awesome1" width="300" height="183" /></a>', '이미지1', '', 'inherit', 'open', 'open', '', '25-revision-v1', '', '', '2015-03-15 16:16:42', '2015-03-15 07:16:42', '', 25, 'http://localhost:8888/?p=27', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2015-03-15 16:17:14', '2015-03-15 07:17:14', 'ㅎㅇㄹㅎㄹㅎㅇㄹㅎ<a href="http://localhost:8888/wp-content/uploads/2015/03/screenshot-2015-03-02-11.50.521.png"><img class="alignnone size-medium wp-image-29" src="http://localhost:8888/wp-content/uploads/2015/03/screenshot-2015-03-02-11.50.521-300x194.png" alt="screenshot 2015-03-02 11.50.52" width="300" height="194" /></a>', 'ㅎㄹㅇㅎㅇㄹㅎㅇㄹ', '', 'publish', 'open', 'open', '', '%e3%85%8e%e3%84%b9%e3%85%87%e3%85%8e%e3%85%87%e3%84%b9%e3%85%8e%e3%85%87%e3%84%b9', '', '', '2015-03-15 16:18:36', '2015-03-15 07:18:36', '', 0, 'http://localhost:8888/?p=28', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (29, 1, '2015-03-15 16:17:10', '2015-03-15 07:17:10', '', 'screenshot 2015-03-02 11.50.52', '', 'inherit', 'open', 'open', '', 'screenshot-2015-03-02-11-50-52', '', '', '2015-03-15 16:17:10', '2015-03-15 07:17:10', '', 28, 'http://localhost:8888/wp-content/uploads/2015/03/screenshot-2015-03-02-11.50.521.png', 0, 'attachment', 'image/png', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2015-03-15 16:17:14', '2015-03-15 07:17:14', 'ㅎㅇㄹㅎㄹㅎㅇㄹㅎ<a href="http://localhost:8888/wp-content/uploads/2015/03/screenshot-2015-03-02-11.50.521.png"><img class="alignnone size-medium wp-image-29" src="http://localhost:8888/wp-content/uploads/2015/03/screenshot-2015-03-02-11.50.521-300x194.png" alt="screenshot 2015-03-02 11.50.52" width="300" height="194" /></a>', 'ㅎㄹㅇㅎㅇㄹㅎㅇㄹ', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2015-03-15 16:17:14', '2015-03-15 07:17:14', '', 28, 'http://localhost:8888/?p=30', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2015-03-15 16:17:46', '2015-03-15 07:17:46', '기타 카테고리입니다.', '', '', 'publish', 'open', 'open', '', '31', '', '', '2015-03-15 16:17:46', '2015-03-15 07:17:46', '', 0, 'http://localhost:8888/?p=31', 10, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2015-03-17 15:18:03', '2015-03-17 06:18:03', '<code>ㅍㅊㅌㅍㅊㅌㅍㅌㅊㅍㅊㅌㅍㅊㅌㅍㅊㅌㅍㅊㅌ</code>', 'ㅌㅊㅌㅊㅍㅇㅍㅇㅌㅍ', '', 'inherit', 'open', 'open', '', '21-revision-v1', '', '', '2015-03-17 15:18:03', '2015-03-17 06:18:03', '', 21, 'http://localhost:8888/?p=32', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (33, 1, '2015-03-18 21:53:58', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 21:53:58', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=dubu_notice&p=33', 0, 'dubu_notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (34, 1, '2015-03-18 21:56:24', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 21:56:24', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=dubu_notice&p=34', 0, 'dubu_notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (35, 1, '2015-03-18 21:59:19', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 21:59:19', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=dubu_notice&p=35', 0, 'dubu_notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (36, 1, '2015-03-18 22:00:02', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:00:02', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=dubu_notice&p=36', 0, 'dubu_notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (37, 1, '2015-03-18 22:05:53', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:05:53', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=dubu_notice&p=37', 0, 'dubu_notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (38, 1, '2015-03-18 22:09:43', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:09:43', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=notice&p=38', 0, 'notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (39, 1, '2015-03-18 22:11:11', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:11:11', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=notice&p=39', 0, 'notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (40, 1, '2015-03-18 22:11:20', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:11:20', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=notice&p=40', 0, 'notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2015-03-18 22:11:38', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:11:38', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=notice&p=41', 0, 'notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (42, 1, '2015-03-18 22:17:30', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:17:30', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=notice&p=42', 0, 'notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (43, 1, '2015-03-18 22:17:55', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:17:55', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=notice&p=43', 0, 'notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (44, 1, '2015-03-18 22:41:57', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:41:57', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=dubu_notice&p=44', 0, 'dubu_notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (45, 1, '2015-03-18 22:42:08', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:42:08', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=dubu_notice&p=45', 0, 'dubu_notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (46, 1, '2015-03-18 22:42:50', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:42:50', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=dubu_notice&p=46', 0, 'dubu_notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (47, 1, '2015-03-18 22:43:02', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:43:02', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=dubu_notice&p=47', 0, 'dubu_notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (48, 1, '2015-03-18 22:43:13', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:43:13', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=dubu_notice&p=48', 0, 'dubu_notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2015-03-18 22:45:12', '0000-00-00 00:00:00', '', '자동 임시글', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-03-18 22:45:12', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/?post_type=dubu_notice&p=49', 0, 'dubu_notice', '', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2015-03-18 22:48:27', '2015-03-18 13:48:27', '예의범절을 지킵시다!!', '첫번째 공지사항입니다.', '', 'publish', 'closed', 'closed', '', '%ec%b2%ab%eb%b2%88%ec%a7%b8-%ea%b3%b5%ec%a7%80%ec%82%ac%ed%95%ad%ec%9e%85%eb%8b%88%eb%8b%a4', '', '', '2015-03-18 22:48:27', '2015-03-18 13:48:27', '', 0, 'http://localhost:8888/?post_type=dubu_notice&#038;p=50', 0, 'dubu_notice', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 18. March 2015 14:00 UTC
# Hostname: localhost
# Database: `wordplus`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_statpress`
# --------------------------------------------------------


#
# Delete any existing table `wp_statpress`
#

DROP TABLE IF EXISTS `wp_statpress`;


#
# Table structure of table `wp_statpress`
#

CREATE TABLE `wp_statpress` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `date` char(8) DEFAULT NULL,
  `time` char(8) DEFAULT NULL,
  `ip` char(15) DEFAULT NULL,
  `urlrequested` varchar(250) DEFAULT NULL,
  `agent` varchar(250) DEFAULT NULL,
  `referrer` varchar(250) DEFAULT NULL,
  `search` varchar(250) DEFAULT NULL,
  `nation` varchar(2) DEFAULT NULL,
  `os` varchar(30) DEFAULT NULL,
  `browser` varchar(32) DEFAULT NULL,
  `searchengine` varchar(16) DEFAULT NULL,
  `spider` varchar(32) DEFAULT NULL,
  `feed` varchar(8) DEFAULT NULL,
  `user` varchar(16) DEFAULT NULL,
  `timestamp` varchar(10) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_statpress (0 records)
#

#
# End of data contents of table wp_statpress
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 18. March 2015 14:00 UTC
# Hostname: localhost
# Database: `wordplus`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_statpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (18 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (3, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (4, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (6, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (18, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (19, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (20, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (21, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (23, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (23, 8, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (25, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (25, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (25, 9, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (28, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (31, 7, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 18. March 2015 14:00 UTC
# Hostname: localhost
# Database: `wordplus`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_statpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (9 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '기타 카테고리입니다.', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'category', '상품 카테고리입니다.', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'category', '뉴스 카테고리입니다.', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'category', '블로그 카테고리입니다.', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'category', '문의 카테고리입니다.', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (6, 6, 'category', '회사소개 카테고리입니다.', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (7, 7, 'nav_menu', '', 0, 10) ; 
INSERT INTO `wp_term_taxonomy` VALUES (8, 8, 'post_format', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (9, 9, 'post_format', '', 0, 1) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 18. March 2015 14:00 UTC
# Hostname: localhost
# Database: `wordplus`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_statpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (9 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'ETC', 'slug_etc', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'PRODUCT', 'slug_product', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'NEWS', 'slug_news', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'BLOG', 'slug_blog', 0) ; 
INSERT INTO `wp_terms` VALUES (5, 'CONTACT', 'slug_contact', 0) ; 
INSERT INTO `wp_terms` VALUES (6, 'ABOUTUS', 'slug_about', 0) ; 
INSERT INTO `wp_terms` VALUES (7, 'main_menu', 'main_menu', 0) ; 
INSERT INTO `wp_terms` VALUES (8, 'post-format-status', 'post-format-status', 0) ; 
INSERT INTO `wp_terms` VALUES (9, 'post-format-image', 'post-format-image', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 18. March 2015 14:00 UTC
# Hostname: localhost
# Database: `wordplus`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_statpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (26 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'nickname', 'wordplus') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'session_tokens', 'a:1:{s:64:"7e687ed250572d0a5061fadf3e597bb3adf63b5d270c9d6dddccf8c1cc0d1989";a:4:{s:10:"expiration";i:1426734246;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:36.0) Gecko/20100101 Firefox/36.0";s:5:"login";i:1426561446;}}') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_user-settings', 'libraryContent=browse&editor=html&posts_list_mode=list') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'wp_user-settings-time', '1426577229') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'wp_dashboard_quick_press_last_post_id', '9') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'show_welcome_panel', '0') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'closedpostboxes_dashboard', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'metaboxhidden_dashboard', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'meta-box-order_dashboard', 'a:4:{s:6:"normal";s:21:"dashboard_custom_feed";s:4:"side";s:38:"my-dashboard-widget,dashboard_activity";s:7:"column3";s:0:"";s:7:"column4";s:0:"";}') ; 
INSERT INTO `wp_usermeta` VALUES (21, 1, 'nav_menu_recently_edited', '7') ; 
INSERT INTO `wp_usermeta` VALUES (22, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (23, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}') ; 
INSERT INTO `wp_usermeta` VALUES (24, 1, 'manageedit-postcolumnshidden', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_usermeta` VALUES (25, 1, 'closedpostboxes_dubu_notice', 'a:0:{}') ; 
INSERT INTO `wp_usermeta` VALUES (26, 1, 'metaboxhidden_dubu_notice', 'a:0:{}') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:8888 MySQL database backup
#
# Generated: Wednesday 18. March 2015 14:00 UTC
# Hostname: localhost
# Database: `wordplus`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_statpress`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'wordplus', '$P$BXpjhuaxVqMCnUpMK54lPN9qVBLO1U/', 'wordplus', 'sonar511@gmail.com', '', '2015-03-12 05:42:10', '', 0, 'wordplus') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

