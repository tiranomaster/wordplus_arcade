워드프레스 한글화 통합팩 (2014.09.06 자)


워드프레스 4.0 한국어 Updated!
*ko.wordpress.org 에서 언어파일의 번역을 100%  지원하는 관계로 
워드프레스 한글화작업은 중단하고 한글워드프레스 정식판으로 대체합니다.
앞으로는 제가 번역하던 플러그인들의 업데이트만 중점적으로 해서 통합해서 배포하겠습니다.

Addthis 3.5.10
Akismet 3.0.2
All in One SEO Pack 2.2.3.1 한국어 Updated!
Contact-form-7 4.0.1 한국어 Updated!
Wordpress Download Monitor 3.3.6.2 한국어
Easy Adsense Lite 7.43 한국어 Updated!
Google XML Sitemaps 4.0.7.1 한국어
My-Category-Order 3.3.2 한국어
NextGEN FlashViewer 1.3 한국어
NextGEN Gallery 2.0.66.29 한국어 Updated!
OZH Admin Dropdown menu 3.6.9 한국어 Updated!
Plus One 1.0.3 한국어
Really-Simple-CAPTCHA 1.8
Remove Title Attributes 1.0 한국어
Rvg Optimize Database 2.9 한국어 Updated!
TinyMCE Advanced 4.1.1 Updated!
Tiny Spoiler 0.2
WP-Popular-Posts 3.1.1 한국어 Updated!
WP-Cumulus 1.23 한국어
Wordpress Database Backup 2.2.4 한국어
WP-Footnote 4.2.2
WP-PageNavi 2.86 한국어 Updated!
wp-reply-notify 1.1 한국어
WP-slimstat-ex 2.0 한국어
WP Super Cache 1.4.2
WP-Syntax 1.0
WPtouch 3.5.4 한국어 Updated!
WP-Whisper-Comment 0.1 한국어
yet-another-related-posts-plugin 4.2.4 한국어 Updated!
Genie 0.0.6
WP TTXML Importer 2.5 한국어


워드프레스 테마들 (통합팩에는 twentten,twentyeleven,twentytwelve,twentythirteen,twentyfourteen만 포함됨)
twentyten 1.7 한국어 Updated!
twentyeleven 1.9 한국어 Updated!
twentytwelve 1.5 한국어 Updated!
twentythirteen 1.3 한국어 Updated!
tewntyfourteen 1.2 한국어 Updated!
Inanis Glass 1.3.6 한국어 
inove 1.4.6 한국어
pixeled 1.8
Fusion 3.1 한국어
Monochrome 4.2 한국어
Pyrmont 2.0.7 한국어
Thematic 1.0.2.1 한국어
Piano Black 3.2 한국어
Neutral 2.2 한국어
Cubic 1.2 한국어
Flat 3.0 한국어
Flat Black 1.0 한국어


워드프레스 밑 언어파일 수정안:

워프 수정안&자동 업그레이드 후 수동 업데이트 방법 자세히 보기

알림: 수동으로 대시보드에 통합팩 RSS를 넣으시려면 대시보드의
"워드프레스 개발 블로그" 설정으로 들어가서 RSS 주소에 다음 주소를 입력:
http://innis.kr/wordpress/?feed=rss2&cat=3/
그리고 제목, 글수 등을 설정하시고 저장하시면 동일하게 작동합니다.

워드프레스 4.0 언어파일:
wordpress\wp-content\languages 폴더에 압축풀어서 넣어주시면 됩니다.

워드프레스 자동업그레이드 후 수동 업데이트 방법
제가 블로그를 업그레이드하는 방법은 워드프레스의 자동업그레이드로 합니다.
통합팩은 영문버전 워드프레스 업그레이드 알림이 동작하는데요.
이 방법을 하실 경우에는 몇가지를 수동적으로 해주셔야 합니다.
통합팩은 영문 워드프레스 업그레이드를 기준으로 하는데
그에 따른 소스의 수정부분이 있습니다.

워드프레스의 자동업그레이드를 선택한 후 수동적으로 해야될 것들은:

1. 자동 업그레이드를 통한 워드프레스 업그레이드

2. 통합팩 파일의 다음 파일들을 덮어쓰기(경로 주의)
\wordpress 의 wp-load.php
\wordpress 의 wp-config-sample.php
\wordpress\wp-includes 의 update.php
\wordpress\wp-admin\includes 의 dashboard.php

3. akismet 플러그인은 워프에 기본포함인데 이 설명이 영문으로 나오니까요.
akismet.php도 덮어쓰기해주시면 플러그인 설명이 한글로 뜹니다.

4. 그리고 글의 워프수정안 보시면 버전에 맞는 한글 언어파일 업데이트본을
따로 압축해서 놔뒀는데요. 그것을 \wordpress\contents\language\ 폴더에
덮어쓰기 해주시면 최신으로 적용됩니다.

5. Tinymce 편집기에서 한글 입력의 문제가 있다면
(첫 글자가 한글일 때 두 글자이상 안써짐, 다음 문단으로 넘어가거나 
글쓰는 도중 삭제 또는 한 글자만 써짐 등등)
통합팩에서 최상위 폴더에 있는 wp-tinymce.js 파일을
\wordpress\wp-includes\js\tinymce\ 에 덮어씌워주시기 바랍니다.
자바스크립트 에러창이 뜨는 문제는 있지만 문제는 해결됩니다.

위의 방법대로만 하시면 굳이 통합팩을 받아서 덮어쓰기안하셔도
매번 자동 업그레이드를 통해서 워드프레스를 업그레이드하시고
저 부분만 건드려주시면 똑같이 적용됩니다~_~


워드프레스 플러그인 수정안:

플러그인 수정안 자세히 보기
All in One SEO Pack 2.2.3 플러그인 수정:
- 2.2.3 에서 2.2.3.1 로 업그레이드
- 언어파일 업데이트

Contact-form-7 3.9.3 플러그인 수정:
- 3.9.3 에서 4.0.1 로 업그레이드
- 언어파일 업데이트

Easy Adsense Lite 7.42 플러그인 수정:
- 7.42 에서 7.43 으로 업그레이드
- 언어파일 업데이트

NextGEN Gallery 2.0.66.27 플러그인 수정:
- 2.0.66.27 에서 2.0.66.29 로 업그레이드
- 언어파일 업데이트

OZH Admin Dropdown menu 3.6.8 플러그인 수정:
- 3.6.8 에서 3.6.9 로 업그레이드
- 언어파일 업데이트

Rvg Optimize Database 2.8.3 플러그인 수정:
- 2.8.3 에서 2.9 로 업그레이드
- 언어파일 업데이트

TinyMCE Advanced 4.1 플러그인 수정:
- 4.1 에서 4.1.1 로 업그레이드

WP-Popular-Posts 3.0.3 플러그인 수정:
- 3.0.3 에서 3.1.1 로 업그레이드
- 언어파일 업데이트

WP-PageNavi 2.85 플러그인 수정:
- 2.85 에서 2.86 으로 업그레이드
- 언어파일 업데이트

WPtouch 3.4.9 플러그인 수정:
- 3.4.9 에서 3.5.4 로 업그레이드
- 언어파일 업데이트

yet-another-related-posts-plugin 4.2.2 플러그인 수정
- 4.2.2 에서 4.2.4 로 업그레이드
- 언어파일 업데이트

이전 버전에서 제거되었거나 추가된 사항 자세히 보기
-

