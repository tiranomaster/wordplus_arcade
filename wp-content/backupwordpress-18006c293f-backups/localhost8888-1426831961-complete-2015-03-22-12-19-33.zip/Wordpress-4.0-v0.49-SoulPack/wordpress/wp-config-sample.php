<?php
/** 
 * 워드프레스의 기본 설정 방법 입니다.
 *
 * 이 파일은 다음과 같은 설정이 되있습니다: MYSQL 설정, 테이블 Prefix,
 * Secret Keys, 워드프레스 언어, 그리고 ABSPATH 입니다. 더 많은 정보는 
 * 이곳을 {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php}  방문하세요. 귀하의 웹호스트로부터 MYSQL 설정을 얻을 수 있습니다.
 *
 * 이 파일은 설치 중에 wp-config.php 스크립트 제작에 쓰입니다.
 * 귀하는 웹사이트에서 사용할 필요는 없으며, 이 파일을 "wp-config.php" 에 복사하고 
 * 값을 채우시면 됩니다.
 *
 * @워드프레스 패키지
 */

// ** MySQL 설정 - 귀하는 웹호스트로부터 이 정보를 얻을 수 있습니다. ** //
/** 워드프레스를 위한 데이터베이스 이름 */
define('DB_NAME', 'database_name_here');

/** MySQL 데이터베이스 사용자 이름 */
define('DB_USER', 'username_here');

/** MySQL 데이터베이스 비밀번호 */
define('DB_PASSWORD', 'password_here');

/** MySQL 호스트 이름 */
define('DB_HOST', 'localhost');

/** 데이터베이스 테이블 제작을 위해 쓰이는 캐릭터셋 */
define('DB_CHARSET', 'utf8');

/** 데이터베이스 조합 타입. 확신없이 바꾸지마세요. */
define('DB_COLLATE', '');

/**#@+
 * 인증 고유 키.
 *
 * 다른 고유한 문구로 바꾸세요!
 * 이곳에서 {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service} 바꾸실 수 있습니다.
 * 기존의 모든 쿠키를 언제든지 무효화시키기 위해 변경할 수 있습니다. 모든 사용자들을 강제적으로 다시 로그인하게 합니다.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'put your unique phrase here');
define('SECURE_AUTH_KEY',  'put your unique phrase here');
define('LOGGED_IN_KEY',    'put your unique phrase here');
define('NONCE_KEY',        'put your unique phrase here');
define('AUTH_SALT',        'put your unique phrase here');
define('SECURE_AUTH_SALT', 'put your unique phrase here');
define('LOGGED_IN_SALT',   'put your unique phrase here');
define('NONCE_SALT',       'put your unique phrase here');

/**#@-*/

/**
 * 워드프레스 데이터베이스 테이블 Prefix.
 *
 *  만약 각각의 고유 prefix를 주신다면 귀하는 하나의 데이터베이스에 여러개를 설치하실 수 있습니다. 
 *  오직 숫자, 글자, _ 만 사용하세요!
 */
$table_prefix  = 'wp_';

/**
 * 워드프레스 언어 선택, 기본은 영어입니다.(현재 ko_KR -한국어-).
 *
 * 워드프레스의 언어를 변경하세요. wp-content/languages 안에 MO file이 있어야합니다.
 * 예를 들어, de.mo가 wp-content/languages 에 설치되 있고 WPLANG을 'de' 로 설정하신다면
 * 독일어를 지원하게 됩니다.
 */
define ('WPLANG', 'ko_KR');

/**
 * 개발자 전용: 워드프레스 디버깅 모드.
 *
 * True 로 변경하여 개발하는 중에 알림 표시를 활성화하게 됩니다.
 * 플러그인과 테마 개발자들에게 그들의 개발 환경에서
 * WP_DEBUG의 사용을 강력히 추천합니다
 */
define('WP_DEBUG', false);

/**
 *워드프레스 멀티사이트 기능.
 *
 *워드프레스 뮤의 기능이 워드프레스로 합쳐지면서 생긴 기능입니다.
 *True 로 변경하면 워드프레스 도구 메뉴에 네트워크 메뉴가 생성됩니다.
 */
define('WP_ALLOW_MULTISITE', false);

/* 이제 끝입니다. 그만 편집하시고 즐거운 블로깅하세요! */

/** 워드프레스의 워드프레스 디렉토리 절대 경로. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** 워드프레스 vars 와 included files 을 설정합니다. */
require_once(ABSPATH . 'wp-settings.php');
